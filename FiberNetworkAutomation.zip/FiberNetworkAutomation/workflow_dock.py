"""workflow_dock — a guided 'what do I do next?' panel for non-technical users.

A dockable checklist of the FT design pipeline. Each step has a Run button that
opens the algorithm; finished steps tick automatically. Completion is remembered
per QGIS project. Includes a one-click 'Validate' that runs quick QA checks and,
when something's wrong, lets the user click a problem to zoom+highlight it.
"""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                                 QPushButton, QListWidget, QListWidgetItem,
                                 QTreeWidget, QTreeWidgetItem, QFrame)

try:
    from qgis.gui import QgsDockWidget as _DockBase
except Exception:  # very old QGIS
    from qgis.PyQt.QtWidgets import QDockWidget as _DockBase


FT_STEPS = [
    ('1', 'Label Poles',          'fibernetwork:ft_label_poles'),
    ('2', 'Distribution Cable',   'fibernetwork:ft_label_distribution_cable'),
    ('3', 'Secondary Cable',      'fibernetwork:ft_label_secondary_cable'),
    ('4', 'Enclosure',            'fibernetwork:ft_label_enclosure'),
    ('4b', 'STS Splitters',       'fibernetwork:ft_label_sts_splitters'),
    ('5', 'Generate PON Zones',   'fibernetwork:ft_generate_pon_zones'),
    ('6', 'Apply PON Order',      'fibernetwork:ft_apply_pon_order'),
    ('7', 'Pole Thickness',       'fibernetwork:ft_pole_thickness'),
]


class WorkflowDock(_DockBase):
    def __init__(self, iface):
        super().__init__('Velocity Nexus — Workflow', iface.mainWindow())
        self.iface = iface
        self.setObjectName('VFWorkflowDock')
        self.setAllowedAreas(Qt.RightDockWidgetArea | Qt.LeftDockWidgetArea)
        self._build()
        self._load_progress()

    # ── UI ────────────────────────────────────────────────────────────────
    def _build(self):
        root = QWidget()
        self.setWidget(root)
        lay = QVBoxLayout(root)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(8)

        try:
            from .branding import vf_style
            self.setStyleSheet(vf_style.DIALOG_QSS)
            lay.addWidget(vf_style.make_header('Workflow', root))
        except Exception:
            try:
                from branding import vf_style
                self.setStyleSheet(vf_style.DIALOG_QSS)
                lay.addWidget(vf_style.make_header('Workflow', root))
            except Exception:
                pass

        lay.addWidget(QLabel('Run the FT design steps in order. '
                             'Tick = done (saved with the project).'))
        self.list = QListWidget()
        for code, name, alg in FT_STEPS:
            it = QListWidgetItem(f'FT{code}  ·  {name}')
            it.setCheckState(Qt.Unchecked)
            it.setData(Qt.UserRole, alg)
            it.setData(Qt.UserRole + 1, code)
            self.list.addItem(it)
        self.list.itemChanged.connect(self._save_progress)
        lay.addWidget(self.list, 1)

        row = QHBoxLayout()
        self.next_btn = QPushButton('▶  Run next step')
        self.runall_btn = QPushButton('⚡ Run all')
        row.addWidget(self.next_btn)
        row.addWidget(self.runall_btn)
        lay.addLayout(row)
        self.next_btn.clicked.connect(self._run_next)
        self.runall_btn.clicked.connect(self._run_all)

        sep = QFrame(); sep.setFrameShape(QFrame.HLine)
        lay.addWidget(sep)

        lay.addWidget(QLabel('Quality check:'))
        self.validate_btn = QPushButton('✅  Validate project')
        self.validate_btn.clicked.connect(self._validate)
        lay.addWidget(self.validate_btn)
        self.results = QTreeWidget()
        self.results.setHeaderLabels(['Issue', 'Count'])
        self.results.itemDoubleClicked.connect(self._zoom_to_issue)
        lay.addWidget(self.results, 1)

    # ── progress persistence (per project) ─────────────────────────────────
    def _save_progress(self, *args):
        from qgis.core import QgsProject
        done = [self.list.item(i).data(Qt.UserRole + 1)
                for i in range(self.list.count())
                if self.list.item(i).checkState() == Qt.Checked]
        QgsProject.instance().writeEntry('VelocityFibre', 'ft_done', ','.join(done))

    def _load_progress(self):
        from qgis.core import QgsProject
        raw, _ = QgsProject.instance().readEntry('VelocityFibre', 'ft_done', '')
        done = set(filter(None, (raw or '').split(',')))
        for i in range(self.list.count()):
            it = self.list.item(i)
            it.setCheckState(Qt.Checked if it.data(Qt.UserRole + 1) in done else Qt.Unchecked)

    # ── run steps ──────────────────────────────────────────────────────────
    def _run_one(self, item):
        import processing
        alg = item.data(Qt.UserRole)
        try:
            processing.execAlgorithmDialog(alg, {})
            item.setCheckState(Qt.Checked)
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Nexus', f'{alg}: {e}')

    def _run_next(self):
        for i in range(self.list.count()):
            it = self.list.item(i)
            if it.checkState() != Qt.Checked:
                self.list.setCurrentItem(it)
                self._run_one(it)
                return
        self.iface.messageBar().pushInfo('Velocity Nexus', 'All steps already done ✓')

    def _run_all(self):
        # Defer to the plugin's themed Run-All (with progress dialog).
        try:
            import qgis.utils as qu
            qu.plugins['FiberNetworkAutomation']._run_ft_pipeline()
            for i in range(self.list.count()):
                self.list.item(i).setCheckState(Qt.Checked)
        except Exception as e:
            self.iface.messageBar().pushWarning('Velocity Nexus', str(e))

    # ── validation ─────────────────────────────────────────────────────────
    def _validate(self):
        from qgis.core import QgsProject
        self.results.clear()
        self._issue_index = {}
        proj = QgsProject.instance()
        groups = {}

        def add(group, label, fid, layer_name):
            groups.setdefault(group, []).append((label, fid, layer_name))

        for lyr in proj.mapLayers().values():
            if not hasattr(lyr, 'getFeatures'):
                continue
            name = lyr.name()
            # null / invalid geometries
            for f in lyr.getFeatures():
                g = f.geometry()
                if g is None or g.isEmpty():
                    add('Null/empty geometry', f'{name} (fid {f.id()})', f.id(), name)
                elif not g.isGeosValid():
                    add('Invalid geometry', f'{name} (fid {f.id()})', f.id(), name)
            # PON range
            if name.lower().startswith('pon'):
                idx = lyr.fields().indexOf('pon_no')
                if idx != -1:
                    for f in lyr.getFeatures():
                        v = f['pon_no']
                        if v not in (None, '') and (int(v) < 235 or int(v) > 300):
                            add('PON out of range 235–300', f'{name}: {v}', f.id(), name)

        if not groups:
            QTreeWidgetItem(self.results, ['✓ No problems found', ''])
            self.iface.messageBar().pushSuccess('Velocity Nexus', 'Validation passed ✓')
            return
        total = 0
        for group, items in sorted(groups.items()):
            parent = QTreeWidgetItem(self.results, [group, str(len(items))])
            total += len(items)
            for label, fid, layer_name in items[:200]:
                child = QTreeWidgetItem(parent, [label, ''])
                child.setData(0, Qt.UserRole, (layer_name, fid))
            parent.setExpanded(False)
        self.iface.messageBar().pushWarning(
            'Velocity Nexus', f'Validation found {total} issue(s) — double-click one to zoom to it.')

    def _zoom_to_issue(self, item, _col):
        data = item.data(0, Qt.UserRole)
        if not data:
            return
        layer_name, fid = data
        from qgis.core import QgsProject
        lyrs = QgsProject.instance().mapLayersByName(layer_name)
        if not lyrs:
            return
        lyr = lyrs[0]
        lyr.removeSelection()
        lyr.select(fid)
        try:
            self.iface.setActiveLayer(lyr)
            self.iface.actionZoomToSelected().trigger()
            self.iface.mapCanvas().flashFeatureIds(lyr, [fid])
        except Exception:
            pass


_INSTANCE = None


def open_dock(iface):
    """Create (or re-show) the workflow dock."""
    global _INSTANCE
    from qgis.PyQt.QtCore import Qt as _Qt
    try:
        if _INSTANCE is not None:
            _INSTANCE.show(); _INSTANCE.raise_()
            return _INSTANCE
    except RuntimeError:
        _INSTANCE = None
    _INSTANCE = WorkflowDock(iface)
    iface.addDockWidget(_Qt.RightDockWidgetArea, _INSTANCE)
    _INSTANCE.show(); _INSTANCE.raise_()
    return _INSTANCE
