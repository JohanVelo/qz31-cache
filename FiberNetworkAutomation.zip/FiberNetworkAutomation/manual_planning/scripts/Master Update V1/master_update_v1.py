import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# MASTER UPDATE V1 — "UPDATE BUTTON"
#
# Labels only NULL/unlabelled features. Safe to re-run anytime.
# New features are labeled in FID order (bottom of attribute
# table) continuing sequentially from the last existing label.
#
# ── HOW TO CONFIGURE FOR EACH PROJECT ───────────────────────
#
#   Single project (no phases):
#       SR            = 'XXX'      ← your area code
#       PREV_LAST_POLE = 'A000'    ← starts fresh from A001
#
#   Multi-phase project (e.g. Mohadin):
#       Phase 2 (continuing from Phase 1 last pole F399):
#           SR            = 'MOA'
#           PREV_LAST_POLE = 'F399'   ← PH2 starts at G001
#       Phase 3 (after Phase 2 finishes):
#           Update PREV_LAST_POLE to whatever PH2's last pole is
#           e.g. PREV_LAST_POLE = 'H450'  ← PH3 starts at H451
#
# ── ORDER OF OPERATIONS ─────────────────────────────────────
#   1. poles             — sequential labels  (G001, G002 …)
#   2. Enclosure         — label from nearest pole
#   3. Enclosures Connectorised — same
#   4. Enclosures Splice — label from nearest pole
#   5. Distribution Cable — label from start/end pole vertices
#   6. Span              — label from start/end pole vertices
#   7. ONT               — copies DR number from nearest HC
#
# To run from QGIS Python Console:
#   exec(open(r'C:\Users\jjsch\OneDrive - blitzfibre.com\Documents\CLAUDE\Master Update V1\master_update_v1.py').read())
# ============================================================

from qgis.core import (
    QgsProject, QgsSpatialIndex, QgsPointXY, QgsDistanceArea, QgsGeometry
)

# ── PROJECT CONFIGURATION ────────────────────────────────────
SR = 'MOA'

# Last pole label from the PREVIOUS phase (or 'A000' for fresh).
# Script finds the highest existing label in the layer first —
# this fallback only applies when the layer has NO labels at all.
#   Mohadin PH1 ended at F399  → PH2 starts at G001
#   Mohadin PH2 ends at ???    → update this for PH3
PREV_LAST_POLE = 'F399'

STATIC = {
    'cmpownr':  'VelocityFibre',
    'subplace': '676007',
    'mainplce': '676007',
    'mun':      'JB Marks Local Municipality',
    'stackref': 'MOA',
    'crtdby':   'Johan Scholtz',
}

# ── LAYER NAMES ──────────────────────────────────────────────
POLES_LAYER     = 'poles v1'
ENC_LAYER       = 'Enclosure v1'
CON_LAYER       = 'Enclosures Connectorised v1'
SPL_LAYER       = 'Enclosures Splice v1'
DIST_LAYER      = 'Distribution Cable v1'
SPAN_LAYER      = 'Span v1'
ONT_LAYER       = 'ONT v1'
HC_LAYER        = 'Home Connection v1'
PON_LAYER       = 'PON v1'
ZONE_LAYER      = 'Zones v1'
PRIM_LAYER      = 'Primary Cable v1'
SEC_LAYER       = 'Secondary Cable v1'
DROP_LAYER      = 'Drop Cable v1'
SPARE_LAYER     = 'Spare Drop Cable v1'
FTS_LAYER       = 'FTS Splitters v1'
STS_LAYER       = 'STS Splitters v1'

# ── Span cable type lookup ───────────────────────────────────
# Maps cable layer name → (cable_id_in_label, subtyp, spec, dim1, cblcpty, ntwrkptn)
CABLE_LAYERS_SPAN = {
    PRIM_LAYER:  ('PF', 'ADSS',      'SM/G657A1', '7.5mm',  '96F',  'Feeder'),
    SEC_LAYER:   ('SF', 'Mini-ADSS', 'SM/G657A1', '5,6mm',  '48F',  'Distribution'),
    DIST_LAYER:  ('DF', 'Mini-ADSS', 'SM/G657A1', '5,6mm',  '24F',  'Distribution'),
}

# ── Enclosure Splice spec by cable fibre count ───────────────
SPEC_BY_CAPACITY = [
    (72,  {'spec_1': 'UMJ', 'dim1': 'L250*W231*D164mm', 'cblcpty1': '72F'}),
    (144, {'spec_1': 'CMJ', 'dim1': 'L290*W231*D164mm', 'cblcpty1': '144F'}),
    (999, {'spec_1': 'MMJ', 'dim1': 'L380*W231*D164mm', 'cblcpty1': '288F'}),
]

# ── ONT fixed attrs ──────────────────────────────────────────
ONT_ATTRS = {
    'type_1':    'Home Connection',
    'subtyp_1':  'ONT',
    'spec_1':    'Nokia ONT G-2425G-A',
    'dim1':      'H113*W170*D30mm',
    'dim2':      '-',
    'cblcpty1':  '1F',
    'conntr1':   'SC/APC',
    'olt_add':   '-',
    'apctmpnm':  '["Final_L2_Service_Template"]',
    'apc_arg':   '{}',
    'srvc_nme':  'Final_L2_Service_Template',
    'oltrx':     '-27.2',
    'ontrx':     '-23.4',
}

# ── Helpers ──────────────────────────────────────────────────

def alphanum_to_parts(s):
    """Split 'H302' into ('H', 302)"""
    import re
    m = re.match(r'^([A-Z]+)(\d+)$', s.strip())
    if m:
        return m.group(1), int(m.group(2))
    return None, None

def increment_alphanum(letter, num, pad=3):
    """Increment e.g. H302 → H303; Z999 → AA001"""
    num += 1
    if num > 999:
        num = 1
        # Increment letter(s): Z→AA, AZ→BA, ZZ→AAA etc.
        chars = list(letter)
        carry = True
        i = len(chars) - 1
        while carry and i >= 0:
            if chars[i] == 'Z':
                chars[i] = 'A'
                i -= 1
            else:
                chars[i] = chr(ord(chars[i]) + 1)
                carry = False
        if carry:
            chars = ['A'] + chars
        letter = ''.join(chars)
    return letter, num

def next_pole_labels(last_label, count):
    """Return list of `count` sequential labels after last_label"""
    letter, num = alphanum_to_parts(last_label)
    if letter is None:
        return []
    labels = []
    for _ in range(count):
        letter, num = increment_alphanum(letter, num)
        labels.append(f'{letter}{num:03d}')
    return labels

def parse_fibre_count(s):
    try:
        return int(str(s).upper().replace('F', '').strip())
    except Exception:        return 0

def spec_from_fibre_count(count):
    for max_c, attrs in SPEC_BY_CAPACITY:
        if count <= max_c:
            return attrs
    return SPEC_BY_CAPACITY[-1][1]

def get_all_layers():
    layers = {}
    for lyr in QgsProject.instance().mapLayers().values():
        layers[lyr.name()] = lyr
    return layers


# ── Get all layers ───────────────────────────────────────────
print("=" * 65)
print("  MASTER UPDATE V1 — START")
print("=" * 65)

all_layers = get_all_layers()

def get_layer(name):
    lyr = all_layers.get(name)
    if not lyr:
        print(f"  WARNING: Layer not found: {name}")
    return lyr

poles_layer = get_layer(POLES_LAYER)
enc_layer   = get_layer(ENC_LAYER)
con_layer   = get_layer(CON_LAYER)
spl_layer   = get_layer(SPL_LAYER)
dist_layer  = get_layer(DIST_LAYER)
span_layer  = get_layer(SPAN_LAYER)
ont_layer   = get_layer(ONT_LAYER)
hc_layer    = get_layer(HC_LAYER)
pon_layer   = get_layer(PON_LAYER)
zone_layer  = get_layer(ZONE_LAYER)
prim_layer  = get_layer(PRIM_LAYER)
sec_layer   = get_layer(SEC_LAYER)

iface.mapCanvas().setRenderFlag(False)

# ── Distance calculator ──────────────────────────────────────
d = QgsDistanceArea()
if poles_layer:
    d.setSourceCrs(poles_layer.crs(), QgsProject.instance().transformContext())
d.setEllipsoid(QgsProject.instance().ellipsoid())

# ────────────────────────────────────────────────────────────
# STEP 1: poles — fill NULL labels
# ────────────────────────────────────────────────────────────
print("\n[1/13] poles — filling NULL labels...")
poles_updated = 0

if poles_layer:
    # Find highest existing label
    all_labels = []
    null_pole_fids = []
    for f in poles_layer.getFeatures():
        lbl = f['Label']
        if lbl and str(lbl).strip() and str(lbl).upper() not in ('NULL', 'NONE', ''):
            # Extract alphanumeric part (e.g. MOA.P.H302 → H302)
            parts = str(lbl).split('.')
            all_labels.append(parts[-1])
        else:
            null_pole_fids.append(f.id())

    if null_pole_fids:
        # Sort labels to find last
        def sort_key(s):
            lt, nm = alphanum_to_parts(s)
            if lt is None:
                return ('', 0)
            return (lt, nm)
        all_labels.sort(key=sort_key)
        last_label = all_labels[-1] if all_labels else PREV_LAST_POLE
        new_labels = next_pole_labels(last_label, len(null_pole_fids))

        # Sort null fids for deterministic ordering
        null_pole_fids.sort()

        dp = poles_layer.dataProvider()
        changes = {}
        label_idx   = poles_layer.fields().indexOf('Label')
        type1_idx   = poles_layer.fields().indexOf('type_1')
        subtype1_idx= poles_layer.fields().indexOf('subtype_1')
        spec1_idx   = poles_layer.fields().indexOf('spec_1')
        dim1_idx    = poles_layer.fields().indexOf('dim1')
        dim2_idx    = poles_layer.fields().indexOf('dim2')
        compown_idx = poles_layer.fields().indexOf('companyown')
        status_idx  = poles_layer.fields().indexOf('status')
        mainpl_idx  = poles_layer.fields().indexOf('mainplace')
        mun_idx     = poles_layer.fields().indexOf('municipal')
        stack_idx   = poles_layer.fields().indexOf('stack')
        createdby_idx = poles_layer.fields().indexOf('createdby')
        subplace_idx= poles_layer.fields().indexOf('subplace')
        poletype_idx= poles_layer.fields().indexOf('Pole Type')

        for fid, alphanum in zip(null_pole_fids, new_labels):
            full_label = f'{SR}.P.{alphanum}'
            row = {}
            def si(idx, val):
                if idx != -1 and val is not None:
                    row[idx] = val
            si(label_idx,    full_label)
            si(poletype_idx, 'Aerial')
            si(type1_idx,    'Pole')
            si(subtype1_idx, 'Creosote')
            si(spec1_idx,    'H4SANS754')
            si(dim1_idx,     '7m')
            si(dim2_idx,     '120-140mm')
            si(compown_idx,  'VelocityFibre')
            si(status_idx,   'Permission not granted')
            si(mainpl_idx,   '676007')
            si(mun_idx,      'JB Marks Local Municipality')
            si(stack_idx,    'MOA')
            si(createdby_idx,'Johan Scholtz')
            si(subplace_idx, '676007')
            changes[fid] = row

        dp.changeAttributeValues(changes)
        poles_layer.reload()
        poles_updated = len(null_pole_fids)
        print(f"  Assigned {poles_updated} new pole labels: {new_labels[0]} → {new_labels[-1]}")
    else:
        print(f"  No NULL pole labels found.")
else:
    print("  SKIP — poles not found")

# Rebuild pole spatial index after update
pole_index = None
pole_feats = {}
if poles_layer:
    pole_index = QgsSpatialIndex(poles_layer.getFeatures())
    pole_feats = {f.id(): f for f in poles_layer.getFeatures()}

# ── Shared helpers ───────────────────────────────────────────
def get_pole_alphanum(point):
    if not pole_index:
        return None
    candidates = pole_index.nearestNeighbor(point, 1)
    if not candidates:
        return None
    lbl = str(pole_feats[candidates[0]]['Label'])
    return lbl.split('.')[-1] if '.' in lbl else lbl

def get_pon_zone(geom, pon_index, pon_feats, zone_index, zone_feats):
    pon_no = zone_no = None
    if pon_index:
        for fid in pon_index.intersects(geom.boundingBox()):
            if pon_feats[fid].geometry().contains(geom):
                pon_no = pon_feats[fid]['pon_no']
                break
    if zone_index:
        for fid in zone_index.intersects(geom.boundingBox()):
            if zone_feats[fid].geometry().intersects(geom):
                zone_no = zone_feats[fid]['zone_no']
                break
    return pon_no, zone_no

# Build PON/Zone indexes once
pon_index = pon_feats_d = zone_index = zone_feats_d = None
if pon_layer:
    pon_index = QgsSpatialIndex(pon_layer.getFeatures())
    pon_feats_d = {f.id(): f for f in pon_layer.getFeatures()}
if zone_layer:
    zone_index = QgsSpatialIndex(zone_layer.getFeatures())
    zone_feats_d = {f.id(): f for f in zone_layer.getFeatures()}

# ────────────────────────────────────────────────────────────
# STEP 2: Enclosure — fill NULL labels
# ────────────────────────────────────────────────────────────
print("\n[2/13] Enclosure — filling NULL labels...")
enc_updated = 0

if enc_layer:
    # Build Connectorised reference for subtype detection
    con_wkt_set = set()
    con_index_local = None
    con_feats_local = {}
    if con_layer:
        con_index_local = QgsSpatialIndex(con_layer.getFeatures())
        con_feats_local = {f.id(): f for f in con_layer.getFeatures()}
        for f in con_layer.getFeatures():
            g = f.geometry()
            if g:
                con_wkt_set.add(g.asWkt())

    MATCH_TOL = 0.5

    def is_connectorised(geom):
        if not con_layer:
            return True
        if geom.asWkt() in con_wkt_set:
            return True
        pt = geom.asPoint()
        pxy = QgsPointXY(pt.x(), pt.y())
        candidates = con_index_local.nearestNeighbor(pxy, 1)
        if candidates:
            nearest_pt = con_feats_local[candidates[0]].geometry().asPoint()
            dist = d.measureLine(pxy, QgsPointXY(nearest_pt.x(), nearest_pt.y()))
            if dist <= MATCH_TOL:
                return True
        return False

    SUBTYPE_ATTRS = {
        'Connectorised': {
            'type': 'Enclosure', 'subtyp': 'Connectorised',
            'spec': 'ODCFD0', 'dim1': 'L220*W120*H73mm',
            'cblcpty': '24F', 'conntr': '6*LC/Duplex',
        },
        'Splice': {
            'type': 'Enclosure', 'subtyp': 'Splice',
            'spec': 'UMJ', 'dim1': 'L250*W231*D164mm',
            'cblcpty': '72F', 'conntr': None,
        },
    }

    def fidx_enc(name):
        return enc_layer.fields().indexOf(name)

    dp = enc_layer.dataProvider()
    changes = {}

    enc_lbl_fld = 'label_1' if enc_layer.fields().indexOf('label_1') != -1 else 'label'
    for feat in enc_layer.getFeatures():
        lbl = feat[enc_lbl_fld]
        if lbl and str(lbl).strip() and 'NULL' not in str(lbl).upper():
            continue  # Already labelled

        geom = feat.geometry()
        if not geom or geom.isNull():
            continue

        pt = geom.asPoint()
        pxy = QgsPointXY(pt.x(), pt.y())

        pole_alphanum = get_pole_alphanum(pxy)
        if not pole_alphanum:
            continue
        label = f'{SR}.DIS.DM.P.{pole_alphanum}'

        subtype = 'Connectorised' if is_connectorised(geom) else 'Splice'
        attrs = SUBTYPE_ATTRS[subtype]

        pon_no, zone_no = get_pon_zone(geom, pon_index, pon_feats_d, zone_index, zone_feats_d)

        row = {}
        def set_f(name, val):
            idx = fidx_enc(name)
            if idx != -1 and val is not None:
                row[idx] = val

        set_f(enc_lbl_fld, label)
        set_f('lat',   round(pt.y(), 6))
        set_f('lon',   round(pt.x(), 7))
        if pon_no  is not None: set_f('pon_no',  pon_no)
        if zone_no is not None: set_f('zone_no', zone_no)
        for field, val in STATIC.items():
            set_f(field, val)
        for field, val in attrs.items():
            set_f(field, val)

        changes[feat.id()] = row
        enc_updated += 1

    if changes:
        dp.changeAttributeValues(changes)
        enc_layer.reload()
    print(f"  Updated {enc_updated} features")
else:
    print("  SKIP — Enclosure not found")

# ────────────────────────────────────────────────────────────
# STEP 3: Enclosures Connectorised — fill NULL labels
# ────────────────────────────────────────────────────────────
print("\n[3/13] Enclosures Connectorised — filling NULL labels...")
con_updated = 0

if con_layer:
    TYPE_ATTRS_CON = {
        'type': 'Enclosure', 'subtyp': 'Connectorised',
        'spec': 'ODCFD0', 'dim1': 'L220*W120*H73mm',
        'cblcpty': '24F', 'conntr': '6*LC/Duplex',
    }

    def fidx_con(name):
        return con_layer.fields().indexOf(name)

    dp = con_layer.dataProvider()
    changes = {}

    con_lbl_fld = 'label_1' if con_layer.fields().indexOf('label_1') != -1 else 'label'
    for feat in con_layer.getFeatures():
        lbl = feat[con_lbl_fld]
        if lbl and str(lbl).strip() and 'NULL' not in str(lbl).upper():
            continue

        geom = feat.geometry()
        if not geom or geom.isNull():
            continue

        pt = geom.asPoint()
        pxy = QgsPointXY(pt.x(), pt.y())

        pole_alphanum = get_pole_alphanum(pxy)
        if not pole_alphanum:
            continue
        label = f'{SR}.DIS.DM.P.{pole_alphanum}'

        pon_no, zone_no = get_pon_zone(geom, pon_index, pon_feats_d, zone_index, zone_feats_d)

        row = {}
        def set_f(name, val):
            idx = fidx_con(name)
            if idx != -1 and val is not None:
                row[idx] = val

        set_f(con_lbl_fld, label)
        set_f('lat',   round(pt.y(), 6))
        set_f('lon',   round(pt.x(), 7))
        if pon_no  is not None: set_f('pon_no',  pon_no)
        if zone_no is not None: set_f('zone_no', zone_no)
        for field, val in STATIC.items():
            set_f(field, val)
        for field, val in TYPE_ATTRS_CON.items():
            set_f(field, val)

        changes[feat.id()] = row
        con_updated += 1

    if changes:
        dp.changeAttributeValues(changes)
        con_layer.reload()
    print(f"  Updated {con_updated} features")
else:
    print("  SKIP — Enclosures Connectorised not found")

# ────────────────────────────────────────────────────────────
# STEP 4: Enclosures Splice — fill NULL labels
# ────────────────────────────────────────────────────────────
print("\n[4/13] Enclosures Splice — filling NULL labels...")
spl_updated = 0

if spl_layer:
    # Build cable indexes for spec detection
    cable_layers_spl = {}
    cable_indexes_spl = {}
    cable_feats_spl = {}
    for cname in [PRIM_LAYER, SEC_LAYER, DIST_LAYER]:
        clyr = all_layers.get(cname)
        if clyr:
            cable_layers_spl[cname] = clyr
            cable_indexes_spl[cname] = QgsSpatialIndex(clyr.getFeatures())
            cable_feats_spl[cname] = {f.id(): f for f in clyr.getFeatures()}

    def get_nearest_cable_capacity_spl(point):
        best_dist = float('inf')
        best_cblcpty = '24F'
        for cname, cidx in cable_indexes_spl.items():
            cfeats = cable_feats_spl[cname]
            candidates = cidx.nearestNeighbor(point, 1)
            if not candidates:
                continue
            cfeat = cfeats[candidates[0]]
            cgeom = cfeat.geometry()
            dist = d.measureLine(point, QgsPointXY(
                cgeom.nearestPoint(QgsGeometry.fromPointXY(point)).asPoint().x(),
                cgeom.nearestPoint(QgsGeometry.fromPointXY(point)).asPoint().y()
            ))
            if dist < best_dist:
                best_dist = dist
                cbl = cfeat['cblcpty']
                if cbl:
                    best_cblcpty = str(cbl)
        return best_cblcpty

    AGG_FIXED = {
        'type_1':   'Enclosure',
        'subtyp_1': 'Enclosure (Splice)',
        'conntr1':  None,
    }

    def fidx_spl(name):
        return spl_layer.fields().indexOf(name)

    dp = spl_layer.dataProvider()
    changes = {}

    for feat in spl_layer.getFeatures():
        lbl = feat['label_1']
        if lbl and str(lbl).strip() and 'NULL' not in str(lbl).upper():
            continue

        geom = feat.geometry()
        if not geom or geom.isNull():
            continue

        pt = geom.asPoint()
        pxy = QgsPointXY(pt.x(), pt.y())

        pole_alphanum = get_pole_alphanum(pxy)
        if not pole_alphanum:
            continue
        label = f'{SR}.AGG.DM.P.{pole_alphanum}'

        cbl_str = get_nearest_cable_capacity_spl(pxy)
        spec_attrs = spec_from_fibre_count(parse_fibre_count(cbl_str))

        pon_no, zone_no = get_pon_zone(geom, pon_index, pon_feats_d, zone_index, zone_feats_d)

        row = {}
        def set_f(name, val):
            idx = fidx_spl(name)
            if idx != -1 and val is not None:
                row[idx] = val

        set_f('label_1', label)
        set_f('lat',     round(pt.y(), 6))
        set_f('lon',     round(pt.x(), 7))
        if pon_no  is not None: set_f('pon_no',  pon_no)
        if zone_no is not None: set_f('zone_no', zone_no)
        for field, val in STATIC.items():
            set_f(field, val)
        for field, val in AGG_FIXED.items():
            set_f(field, val)
        for field, val in spec_attrs.items():
            set_f(field, val)

        changes[feat.id()] = row
        spl_updated += 1

    if changes:
        dp.changeAttributeValues(changes)
        spl_layer.reload()
    print(f"  Updated {spl_updated} features")
else:
    print("  SKIP — Enclosures Splice not found")

# ────────────────────────────────────────────────────────────
# STEP 5: Distribution Cable — fill NULL labels
# ────────────────────────────────────────────────────────────
print("\n[5/13] Distribution Cable — filling NULL labels...")
dist_updated = 0

if dist_layer:
    DIST_ATTRS = {
        'type':     'Cable',
        'subtyp':   'Mini-ADSS',
        'spec':     'SM/G657A1',
        'dim1':     '5,6mm',
        'cblcpty':  '24F',
        'ntwrkptn': 'Distribution',
        'cmpownr':  'VelocityFibre',
        'subplace': '676007',
        'mainplce': '676007',
        'mun':      'JB Marks Local Municipality',
        'stackref': 'MOA',
        'crtdby':   'Johan Scholtz',
    }

    def fidx_dist(name):
        return dist_layer.fields().indexOf(name)

    dp = dist_layer.dataProvider()
    changes = {}

    for feat in dist_layer.getFeatures():
        lbl = feat['label']
        if lbl and str(lbl).strip() and str(lbl).upper() not in ('NULL', 'NONE', ''):
            continue

        geom = feat.geometry()
        if not geom or geom.isNull():
            continue

        # Get start and end vertices
        if geom.isMultipart():
            mline = geom.asMultiPolyline()
            line = mline[0] if mline else []
        else:
            line = geom.asPolyline()
        if not line or len(line) < 2:
            continue

        start_pt = QgsPointXY(line[0].x(),  line[0].y())
        end_pt   = QgsPointXY(line[-1].x(), line[-1].y())

        start_alnum = get_pole_alphanum(start_pt)
        end_alnum   = get_pole_alphanum(end_pt)
        if not start_alnum or not end_alnum:
            continue

        label = f'{SR}.DF.24F.P.{start_alnum}-P.{end_alnum}'

        row = {}
        def set_f(name, val):
            idx = fidx_dist(name)
            if idx != -1 and val is not None:
                row[idx] = val

        set_f('label',    label)
        set_f('strtfeat', f'{SR}.P.{start_alnum}')
        set_f('endfeat',  f'{SR}.P.{end_alnum}')
        for field, val in DIST_ATTRS.items():
            set_f(field, val)

        changes[feat.id()] = row
        dist_updated += 1

    if changes:
        dp.changeAttributeValues(changes)
        dist_layer.reload()
    print(f"  Updated {dist_updated} features")
else:
    print("  SKIP — Distribution Cable not found")

# ────────────────────────────────────────────────────────────
# STEP 6: Span — fill NULL / garbage labels
# ────────────────────────────────────────────────────────────
print("\n[6/13] Span — filling NULL/garbage labels...")
span_updated = 0

if span_layer and poles_layer and span_layer.fields().indexOf('label') != -1:
    # Build cable layer indexes for span type detection
    cable_span_indexes = {}
    cable_span_feats   = {}
    for cname in CABLE_LAYERS_SPAN:
        clyr = all_layers.get(cname)
        if clyr:
            cable_span_indexes[cname] = QgsSpatialIndex(clyr.getFeatures())
            cable_span_feats[cname]   = {f.id(): f for f in clyr.getFeatures()}

    def detect_span_cable_type(midpoint):
        """Find which cable layer's nearest feature is closest to this midpoint"""
        best_dist  = float('inf')
        best_cname = DIST_LAYER  # default
        for cname, cidx in cable_span_indexes.items():
            candidates = cidx.nearestNeighbor(midpoint, 1)
            if not candidates:
                continue
            cfeat = cable_span_feats[cname][candidates[0]]
            cgeom = cfeat.geometry()
            nearest_pt = cgeom.nearestPoint(QgsGeometry.fromPointXY(midpoint)).asPoint()
            dist = d.measureLine(midpoint, QgsPointXY(nearest_pt.x(), nearest_pt.y()))
            if dist < best_dist:
                best_dist  = dist
                best_cname = cname
        return best_cname

    def fidx_span(name):
        return span_layer.fields().indexOf(name)

    SPAN_STATIC = {
        'cmpownr':  'VelocityFibre',
        'subplace': '676007',
        'mainplce': '676007',
        'mun':      'JB Marks Local Municipality',
        'stackref': 'MOA',
        'crtdby':   'Johan Scholtz',
    }

    dp = span_layer.dataProvider()
    changes = {}
    garbage = {'NULL', 'NUL', 'NONE', 'NULL1', ''}

    for feat in span_layer.getFeatures():
        lbl = str(feat['label'] or '').strip().upper()
        if lbl and lbl not in garbage and not lbl.startswith('NULL'):
            continue  # Already has a valid label

        geom = feat.geometry()
        if not geom or geom.isNull():
            continue

        if geom.isMultipart():
            mline = geom.asMultiPolyline()
            line = mline[0] if mline else []
        else:
            line = geom.asPolyline()
        if not line or len(line) < 2:
            continue

        start_pt = QgsPointXY(line[0].x(),  line[0].y())
        end_pt   = QgsPointXY(line[-1].x(), line[-1].y())
        mid_idx  = len(line) // 2
        mid_pt   = QgsPointXY(line[mid_idx].x(), line[mid_idx].y())

        start_alnum = get_pole_alphanum(start_pt)
        end_alnum   = get_pole_alphanum(end_pt)
        if not start_alnum or not end_alnum:
            continue

        # Detect cable type from nearest cable layer
        cname = detect_span_cable_type(mid_pt)
        cable_id, subtyp, spec, dim1, cblcpty, ntwrkptn = CABLE_LAYERS_SPAN[cname]

        label = f'{SR}.{cable_id}.{cblcpty}.P.{start_alnum}-P.{end_alnum}'

        row = {}
        def set_f(name, val):
            idx = fidx_span(name)
            if idx != -1 and val is not None:
                row[idx] = val

        set_f('label',    label)
        set_f('strtfeat', f'{SR}.P.{start_alnum}')
        set_f('endfeat',  f'{SR}.P.{end_alnum}')
        set_f('type',     'Cable')
        set_f('subtyp',   subtyp)
        set_f('spec',     spec)
        set_f('dim1',     dim1)
        set_f('cblcpty',  cblcpty)
        set_f('ntwrkptn', ntwrkptn)
        for field, val in SPAN_STATIC.items():
            set_f(field, val)

        changes[feat.id()] = row
        span_updated += 1

    if changes:
        dp.changeAttributeValues(changes)
        span_layer.reload()
    print(f"  Updated {span_updated} features")
elif not span_layer:
    print("  SKIP — Span layer not found")
elif not poles_layer:
    print("  SKIP — Poles layer not found")
else:
    print("  SKIP — Span layer has no 'label' field")

# ────────────────────────────────────────────────────────────
# STEP 7: ONT — fill NULL labels from Home Connection v1
# ────────────────────────────────────────────────────────────
print("\n[7/13] ONT — filling NULL labels...")
ont_updated = 0

if ont_layer and hc_layer:
    # Build Home Connection spatial index (point layer)
    hc_index = QgsSpatialIndex(hc_layer.getFeatures())
    hc_feats  = {f.id(): f for f in hc_layer.getFeatures()}

    def get_hc_label(point):
        candidates = hc_index.nearestNeighbor(point, 1)
        if not candidates:
            return None
        return str(hc_feats[candidates[0]]['label_1'] or '')

    def fidx_ont(name):
        return ont_layer.fields().indexOf(name)

    dp = ont_layer.dataProvider()
    changes = {}

    for feat in ont_layer.getFeatures():
        lbl = feat['label_1']
        if lbl and str(lbl).strip() and 'NULL' not in str(lbl).upper():
            continue

        geom = feat.geometry()
        if not geom or geom.isNull():
            continue

        pt = geom.asPoint()
        pxy = QgsPointXY(pt.x(), pt.y())

        hc_lbl = get_hc_label(pxy)
        if not hc_lbl:
            continue

        # HC label format: MOA.ONT.DR1875440 → extract DR number
        parts = hc_lbl.split('.')
        dr_part = parts[-1] if parts else hc_lbl  # e.g. 'DR1875440'
        dr_num  = dr_part.replace('DR', '').strip() if dr_part.startswith('DR') else dr_part

        # ONT label inherits the same DR number
        ont_label = f'{SR}.ONT.{dr_part}'

        row = {}
        def set_f(name, val):
            idx = fidx_ont(name)
            if idx != -1 and val is not None:
                row[idx] = val

        set_f('label_1', ont_label)
        set_f('uuid',    dr_num)     # DR number as uuid
        set_f('lat',     round(pt.y(), 6))
        set_f('lon',     round(pt.x(), 7))
        if pon_feats_d:
            pon_no, zone_no = get_pon_zone(geom, pon_index, pon_feats_d, zone_index, zone_feats_d)
            if pon_no  is not None: set_f('pon_no',  pon_no)
            if zone_no is not None: set_f('zone_no', zone_no)

        for field, val in STATIC.items():
            set_f(field, val)
        for field, val in ONT_ATTRS.items():
            set_f(field, val)

        changes[feat.id()] = row
        ont_updated += 1

    if changes:
        dp.changeAttributeValues(changes)
        ont_layer.reload()
    print(f"  Updated {ont_updated} features")
else:
    print("  SKIP — ONT or Home Connection not found")

# ────────────────────────────────────────────────────────────
# STEP 8: Primary Cable — fill NULL labels
# ────────────────────────────────────────────────────────────
print("\n[8/13] Primary Cable — filling NULL labels...")
prim_updated = 0
prim_layer = get_layer(PRIM_LAYER)
if prim_layer and poles_layer:
    PRIM_ATTRS = {
        'type': 'Cable', 'subtyp': 'ADSS', 'spec': 'SM/G657A1',
        'dim1': '7.5mm', 'ntwrkptn': 'Feeder',
        'cmpownr': 'VelocityFibre', 'stackref': SR, 'crtdby': 'Johan Scholtz',
    }
    dp = prim_layer.dataProvider()
    changes = {}
    for feat in prim_layer.getFeatures():
        lbl = feat['label']
        if lbl and str(lbl).strip() and str(lbl).upper() not in ('NULL','NONE','NUL',''):
            continue
        geom = feat.geometry()
        if not geom or geom.isNull(): continue
        line = geom.asMultiPolyline()[0] if geom.isMultipart() else geom.asPolyline()
        if not line or len(line) < 2: continue
        s = get_pole_alphanum(QgsPointXY(line[0].x(),  line[0].y()))
        e = get_pole_alphanum(QgsPointXY(line[-1].x(), line[-1].y()))
        if not s or not e: continue
        cblcpty = str(feat['cblcpty'] or '96F')
        row = {}
        fi = lambda n: prim_layer.fields().indexOf(n)
        def sf(n, v):
            i = fi(n)
            if i != -1 and v is not None: row[i] = v
        sf('label',    f'{SR}.PF.{cblcpty}.P.{s}-P.{e}')
        sf('strtfeat', f'{SR}.P.{s}')
        sf('endfeat',  f'{SR}.P.{e}')
        for k, v in PRIM_ATTRS.items(): sf(k, v)
        changes[feat.id()] = row
        prim_updated += 1
    if changes:
        dp.changeAttributeValues(changes)
        prim_layer.reload()
    print(f"  Updated {prim_updated} features")
else:
    print("  SKIP — Primary Cable or poles not found")

# ────────────────────────────────────────────────────────────
# STEP 9: Secondary Cable — fill NULL labels
# ────────────────────────────────────────────────────────────
print("\n[9/13] Secondary Cable — filling NULL labels...")
sec_updated = 0
sec_layer = get_layer(SEC_LAYER)
if sec_layer and poles_layer:
    SEC_ATTRS = {
        'type': 'Cable', 'subtyp': 'Mini-ADSS', 'spec': 'SM/G657A1',
        'dim1': '5,6mm', 'ntwrkptn': 'Distribution',
        'cmpownr': 'VelocityFibre', 'stackref': SR, 'crtdby': 'Johan Scholtz',
    }
    dp = sec_layer.dataProvider()
    changes = {}
    for feat in sec_layer.getFeatures():
        lbl = feat['label']
        if lbl and str(lbl).strip() and str(lbl).upper() not in ('NULL','NONE','NUL',''):
            continue
        geom = feat.geometry()
        if not geom or geom.isNull(): continue
        line = geom.asMultiPolyline()[0] if geom.isMultipart() else geom.asPolyline()
        if not line or len(line) < 2: continue
        s = get_pole_alphanum(QgsPointXY(line[0].x(),  line[0].y()))
        e = get_pole_alphanum(QgsPointXY(line[-1].x(), line[-1].y()))
        if not s or not e: continue
        cblcpty = str(feat['cblcpty'] or '48F')
        row = {}
        fi = lambda n: sec_layer.fields().indexOf(n)
        def sf(n, v):
            i = fi(n)
            if i != -1 and v is not None: row[i] = v
        sf('label',    f'{SR}.SF.{cblcpty}.P.{s}-P.{e}')
        sf('strtfeat', f'{SR}.P.{s}')
        sf('endfeat',  f'{SR}.P.{e}')
        for k, v in SEC_ATTRS.items(): sf(k, v)
        changes[feat.id()] = row
        sec_updated += 1
    if changes:
        dp.changeAttributeValues(changes)
        sec_layer.reload()
    print(f"  Updated {sec_updated} features")
else:
    print("  SKIP — Secondary Cable or poles not found")

# ────────────────────────────────────────────────────────────
# STEP 10: Drop Cable — fill NULL labels (sequential DR#)
# ────────────────────────────────────────────────────────────
print("\n[10/13] Drop Cable — filling NULL labels...")
drop_updated = 0
drop_layer = all_layers.get(DROP_LAYER)
spare_layer = all_layers.get(SPARE_LAYER)
if drop_layer:
    import re as _re
    # Find max DR number across Drop + Spare Drop
    max_dr = 0
    for lyr in [drop_layer, spare_layer]:
        if not lyr: continue
        for f in lyr.getFeatures():
            lbl = str(f['label'] or '')
            m = _re.search(r'DR(\d+)', lbl)
            if m: max_dr = max(max_dr, int(m.group(1)))

    dp = drop_layer.dataProvider()
    changes = {}
    null_fids = sorted(
        f.id() for f in drop_layer.getFeatures()
        if not str(f['label']).strip() or str(f['label']).upper() in ('NULL','NONE','NUL','NULL\\')
    )
    for fid in null_fids:
        max_dr += 1
        fi = lambda n: drop_layer.fields().indexOf(n)
        row = {}
        def sf(n, v):
            i = fi(n)
            if i != -1 and v is not None: row[i] = v
        sf('label',   f'DR{max_dr}')
        sf('cmpownr', 'VelocityFibre')
        sf('stackref', SR)
        sf('crtdby',  'Johan Scholtz')
        changes[fid] = row
        drop_updated += 1
    if changes:
        dp.changeAttributeValues(changes)
        drop_layer.reload()
    print(f"  Updated {drop_updated} features (next DR: DR{max_dr})")
else:
    print("  SKIP — Drop Cable not found")

# ────────────────────────────────────────────────────────────
# STEP 11: FTS Splitters — sequential OLT port re-labeling
# ────────────────────────────────────────────────────────────
# PH1 FTS ends at C15P10 → PH2 starts at C15P11.
# Sort all PH2 FTS splitters by nearest-pole alphanum and assign
# sequential ports (C15P11, C15P12 … C16P1 … ) in that order.
# Also re-labels STS splitters to match the new port assignments
# and resets leg numbers (L1, L2 …) in pole order within each group.
print("\n[11/13] FTS + STS Splitters — sequential re-labeling...")

import re as _re2

def _pole_key(label_str):
    m = _re2.search(r'DM\.P\.([A-Z]+)(\d+)', str(label_str))
    return (m.group(1), int(m.group(2))) if m else ('ZZZ', 99999)

def _next_olt(card, port, max_port=16):
    port += 1
    if port > max_port:
        port = 1; card += 1
    return card, port

fts_layer = all_layers.get(FTS_LAYER)
sts_layer = all_layers.get(STS_LAYER)
fts_relabeled = sts_relabeled = 0

if fts_layer and sts_layer:
    # ── FTS ──────────────────────────────────────────────────
    fts_sorted = sorted(fts_layer.getFeatures(), key=lambda f: _pole_key(f['label']))
    card, port = 15, 10   # one step before start so first next_olt gives C15P11
    old_to_new = {}
    fts_changes = {}
    lbl_fts = fts_layer.fields().indexOf('label')

    for feat in fts_sorted:
        card, port = _next_olt(card, port)
        new_port = f'C{card}P{port}'
        old_lbl = str(feat['label'])
        m = _re2.search(r'OLT\.01\.(C\d+P\d+)', old_lbl)
        if m:
            old_port = m.group(1)
            old_to_new[old_port] = new_port
            new_lbl = old_lbl.replace(f'OLT.01.{old_port}', f'OLT.01.{new_port}')
            if new_lbl != old_lbl:
                fts_changes[feat.id()] = {lbl_fts: new_lbl}

    if fts_changes:
        fts_layer.dataProvider().changeAttributeValues(fts_changes)
        fts_layer.reload()
    fts_relabeled = len(fts_changes)

    # ── STS ──────────────────────────────────────────────────
    sts_by_port = {}
    for feat in sts_layer.getFeatures():
        m = _re2.search(r'OLT\.01\.(C\d+P\d+)', str(feat['label']))
        if m:
            sts_by_port.setdefault(m.group(1), []).append(feat)

    sts_changes = {}
    lbl_sts = sts_layer.fields().indexOf('label')

    for old_port, feats in sts_by_port.items():
        new_port = old_to_new.get(old_port, old_port)
        for leg, feat in enumerate(sorted(feats, key=lambda f: _pole_key(f['label'])), start=1):
            old_lbl = str(feat['label'])
            new_lbl = _re2.sub(r'OLT\.01\.C\d+P\d+', f'OLT.01.{new_port}', old_lbl)
            new_lbl = _re2.sub(r'\.L\d+$', f'.L{leg}', new_lbl)
            if new_lbl != old_lbl:
                sts_changes[feat.id()] = {lbl_sts: new_lbl}

    if sts_changes:
        sts_layer.dataProvider().changeAttributeValues(sts_changes)
        sts_layer.reload()
    sts_relabeled = len(sts_changes)

    print(f"  FTS re-labeled: {fts_relabeled}  |  STS re-labeled: {sts_relabeled}")
else:
    print("  SKIP — FTS or STS Splitters layer not found")

# ────────────────────────────────────────────────────────────
# STEP 12: Set attribute table sort order — all PH2 layers
# ────────────────────────────────────────────────────────────
print("\n[12/13] Setting attribute table sort order...")
from qgis.core import QgsAttributeTableConfig
from qgis.PyQt.QtCore import Qt as _Qt

_sort_targets = [
    (POLES_LAYER,  'Label'),
    (ENC_LAYER,    'label_1'),
    (CON_LAYER,    'label_1'),
    (SPL_LAYER,    'label_1'),
    (DIST_LAYER,   'label'),
    (SPAN_LAYER,   'label'),
    (ONT_LAYER,    'label_1'),
    (HC_LAYER,     'label_1'),
    (PRIM_LAYER,   'label'),
    (SEC_LAYER,    'label'),
    (DROP_LAYER,   'label'),
    (SPARE_LAYER,  'label'),
    (FTS_LAYER,    'label'),
    (STS_LAYER,    'label'),
    (PON_LAYER,    'label'),
]
_sorted_n = 0
for _lname, _fld in _sort_targets:
    _lyr = all_layers.get(_lname)
    if not _lyr or _lyr.fields().indexOf(_fld) == -1:
        continue
    _cfg = _lyr.attributeTableConfig()
    _cfg.setSortExpression(f'"{_fld}"')
    _cfg.setSortOrder(_Qt.SortOrder.AscendingOrder)
    _lyr.setAttributeTableConfig(_cfg)
    _sorted_n += 1
print(f"  Sort order applied to {_sorted_n} layers")

# ────────────────────────────────────────────────────────────
# STEP 13: Polish — fill NULL secondary attributes on ALL
# labeled features (lat/lon, pon_no/zone_no, datecrtd, static
# fields, Enclosure v1 _1 mirrors, cable cblcpty/midpoint).
# Span v1 excluded.
# ────────────────────────────────────────────────────────────
print("\n[13/13] Polishing NULL secondary attributes...")
import datetime as _dt
_today = _dt.date.today().isoformat()
_polish_total = 0

def _isnull(v):
    return v is None or str(v).strip().upper() in ('', 'NULL', 'NONE', 'NUL')

def _set_if_null(feat, lyr, row, fname, fval):
    """Write fval into row[field_idx] only if the field is currently NULL."""
    if fval is None:
        return
    idx = lyr.fields().indexOf(fname)
    if idx == -1:
        return
    if not _isnull(feat[fname]):
        return
    row[idx] = fval

# ── Point layers: lat/lon, pon/zone, datecrtd, static ────────
_polish_pt_layers = [
    (poles_layer,               'Label'),
    (enc_layer,                 'label_1'),
    (con_layer,                 'label_1'),
    (spl_layer,                 'label_1'),
    (ont_layer,                 'label_1'),
    (hc_layer,                  'label_1'),
    (all_layers.get(FTS_LAYER), 'label'),
    (all_layers.get(STS_LAYER), 'label'),
]
for _plyr, _plbl in _polish_pt_layers:
    if not _plyr:
        continue
    _pdp  = _plyr.dataProvider()
    _pchg = {}
    for _pfeat in _plyr.getFeatures():
        if _isnull(_pfeat[_plbl]):
            continue
        _pgeom = _pfeat.geometry()
        if not _pgeom or _pgeom.isNull():
            continue
        _ppt = _pgeom.asPoint()
        _row = {}
        _set_if_null(_pfeat, _plyr, _row, 'lat',      round(_ppt.y(), 6))
        _set_if_null(_pfeat, _plyr, _row, 'lon',      round(_ppt.x(), 7))
        _set_if_null(_pfeat, _plyr, _row, 'datecrtd', _today)
        if pon_feats_d:
            _ppn, _pzn = get_pon_zone(_pgeom, pon_index, pon_feats_d, zone_index, zone_feats_d)
            if _ppn is not None: _set_if_null(_pfeat, _plyr, _row, 'pon_no',  _ppn)
            if _pzn is not None: _set_if_null(_pfeat, _plyr, _row, 'zone_no', _pzn)
        for _sfn, _sfv in STATIC.items():
            _set_if_null(_pfeat, _plyr, _row, _sfn, _sfv)
        if _row:
            _pchg[_pfeat.id()] = _row
    if _pchg:
        _pdp.changeAttributeValues(_pchg)
        _plyr.reload()
        _polish_total += len(_pchg)

# ── Enclosure v1 special: mirror bare fields → _1 fields ─────
if enc_layer:
    _edp  = enc_layer.dataProvider()
    _echg = {}
    _mirrors = [
        ('type',    'type_1'),
        ('subtyp',  'subtyp_1'),
        ('spec',    'spec_1'),
        ('cblcpty', 'cblcpty1'),
        ('conntr',  'conntr1'),
    ]
    for _efeat in enc_layer.getFeatures():
        if _isnull(_efeat['label_1']):
            continue
        _erow = {}
        for _esrc, _edst in _mirrors:
            _eidx = enc_layer.fields().indexOf(_edst)
            if _eidx == -1:
                continue
            if not _isnull(_efeat[_edst]):
                continue
            _esrcval = _efeat[_esrc]
            if not _isnull(_esrcval):
                _erow[_eidx] = _esrcval
        if _erow:
            _echg[_efeat.id()] = _erow
    if _echg:
        _edp.changeAttributeValues(_echg)
        enc_layer.reload()
        _polish_total += len(_echg)

# ── Cable layers: lat/lon midpoint, cblcpty, pon/zone, static ─
import re as _re3
_polish_cbl_layers = [
    (prim_layer,                'label', '96F'),
    (sec_layer,                 'label', '48F'),
    (dist_layer,                'label', '24F'),
    (all_layers.get(DROP_LAYER),  'label', None),
    (all_layers.get(SPARE_LAYER), 'label', None),
]
for _clyr, _clbl, _cbl_default in _polish_cbl_layers:
    if not _clyr:
        continue
    _cdp  = _clyr.dataProvider()
    _cchg = {}
    for _cfeat in _clyr.getFeatures():
        if _isnull(_cfeat[_clbl]):
            continue
        _cgeom = _cfeat.geometry()
        if not _cgeom or _cgeom.isNull():
            continue
        _cline = _cgeom.asMultiPolyline()[0] if _cgeom.isMultipart() else _cgeom.asPolyline()
        if not _cline:
            continue
        _cmid = _cline[len(_cline) // 2]
        _cmxy = QgsPointXY(_cmid.x(), _cmid.y())
        _crow = {}
        _set_if_null(_cfeat, _clyr, _crow, 'lat',      round(_cmid.y(), 6))
        _set_if_null(_cfeat, _clyr, _crow, 'lon',      round(_cmid.x(), 7))
        _set_if_null(_cfeat, _clyr, _crow, 'datecrtd', _today)
        if _cbl_default:
            _cm = _re3.search(r'\.([\d]+F)\.', str(_cfeat[_clbl]))
            _set_if_null(_cfeat, _clyr, _crow, 'cblcpty', _cm.group(1) if _cm else _cbl_default)
        if pon_feats_d:
            _cmgeom = QgsGeometry.fromPointXY(_cmxy)
            _cpn, _czn = get_pon_zone(_cmgeom, pon_index, pon_feats_d, zone_index, zone_feats_d)
            if _cpn is not None: _set_if_null(_cfeat, _clyr, _crow, 'pon_no',  _cpn)
            if _czn is not None: _set_if_null(_cfeat, _clyr, _crow, 'zone_no', _czn)
        for _sfn, _sfv in STATIC.items():
            _set_if_null(_cfeat, _clyr, _crow, _sfn, _sfv)
        if _crow:
            _cchg[_cfeat.id()] = _crow
    if _cchg:
        _cdp.changeAttributeValues(_cchg)
        _clyr.reload()
        _polish_total += len(_cchg)

print(f"  Polished {_polish_total} features")

# ── Re-enable rendering ──────────────────────────────────────
iface.mapCanvas().setRenderFlag(True)
iface.mapCanvas().refresh()

# ── Save project ─────────────────────────────────────────────
QgsProject.instance().write()

# ── Summary ──────────────────────────────────────────────────
print("\n" + "=" * 65)
print("  MASTER UPDATE V1 — COMPLETE")
print("=" * 65)
print(f"  poles labels added:              {poles_updated}")
print(f"  Enclosure fixed:                 {enc_updated}")
print(f"  Enclosures Connectorised fixed:  {con_updated}")
print(f"  Enclosures Splice fixed:         {spl_updated}")
print(f"  Distribution Cable fixed:        {dist_updated}")
print(f"  Span fixed:                      {span_updated}")
print(f"  ONT fixed:                       {ont_updated}")
print(f"  Primary Cable fixed:             {prim_updated}")
print(f"  Secondary Cable fixed:           {sec_updated}")
print(f"  Drop Cable fixed:                {drop_updated}")
print(f"  FTS Splitters re-labeled:        {fts_relabeled}")
print(f"  STS Splitters re-labeled:        {sts_relabeled}")
print(f"  Secondary attrs polished:        {_polish_total}")
print("=" * 65)
print("  Project saved.")
