# Velocity: Standardise Layers — VN 1
# claude:intent READ-ONLY BY DEFAULT — previews unless APPLY is ticked, and even
# then writes only a NEW GeoPackage. No source file is ever opened for editing.

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterString,
    QgsProject,
)


class VN01StandardiseLayersAlgorithm(QgsProcessingAlgorithm):
    """
    VN 1 — Standardise Layers. Gives this project the canonical layer names,
    field names and symbology, after backing it up and proving the backup
    restores.

    ⛔ IT PREVIEWS BY DEFAULT. Nothing is written unless APPLY is ticked, and
    even then the output is a NEW GeoPackage — no source file is opened for
    editing, ever. The preview you see is the exact plan that gets executed;
    they are the same object, not two derivations that could disagree.

    Phase 1 renames and restyles. It writes no VALUE and removes no COLUMN.
    Adding missing fields and folding value spellings is phase 2, separately
    approved, because renaming is reversible and changing data is not.

    Why it refuses sometimes
    ------------------------
    If any layer cannot be backed up — a memory layer, or one whose file has
    moved — APPLYING stops. Previewing does not: a preview writes nothing, and
    refusing to show the plan because a scratch layer exists withholds the
    information needed to fix it. Lulekani has four such layers and a dead path,
    Ventersdorp has three, and no file-based backup can capture any of them.

    Layer identity comes from network_planner/layer_names.py, so it finds a
    layer under whatever this project happens to call it — "PON Drop Cables",
    "Drop Cable v1" and "Drops  7,554  (159,598 m)" are all the same thing.
    """

    APPLY = 'APPLY'
    TOWN = 'TOWN'
    OUTPUT = 'OUTPUT'
    STYLES = 'STYLES'
    SNAPSHOT_ROOT = 'SNAPSHOT_ROOT'

    def createInstance(self):
        return VN01StandardiseLayersAlgorithm()

    def name(self):
        return 'vn_01_standardise_layers'

    def displayName(self):
        return 'VN 1 — Standardise Layers (preview, then apply)'

    def group(self):
        return 'Velocity Standards'

    def groupId(self):
        return 'velocity_standards'

    def shortHelpString(self):
        return """
        <p><b>VN 1 — Standardise Layers.</b> Renames this project's layers and
        fields onto one benchmark and writes matching symbology, so every
        project reads the same way.</p>

        <h4>It previews by default</h4>
        <p>With <b>Apply</b> unticked it backs the project up, proves the backup
        restores, and prints exactly what it <i>would</i> change. Nothing else.
        Tick <b>Apply</b> and that same plan is executed into a new GeoPackage.
        Your source files are never opened for editing.</p>

        <h4>What it changes in this pass</h4>
        <ul>
          <li><b>Layer names</b> — <code>Lulekani Distribution</code> and
              <code>Matiko Distribution Final</code> both become
              <code>Distribution Cables</code>.</li>
          <li><b>Field names</b> — <code>splitter_c</code> →
              <code>splitter_count</code>, <code>Lenght</code> →
              <code>Length</code>, recovering names a shapefile truncated.</li>
          <li><b>Symbology</b> — categorised styles that always carry an
              all-other-values catch-all, so a value nobody listed still
              draws.</li>
        </ul>

        <h4>What it does NOT change</h4>
        <p>No attribute value is written. No column is removed. No geometry is
        touched — the run is verified by comparing geometry, not feature ids.</p>

        <h4>When it refuses</h4>
        <p>If any layer cannot be backed up — a scratch/memory layer, or one
        whose source file has moved — <b>applying</b> stops and names them. A
        rewrite without a rollback is not something this tool will do.
        <b>Previewing still works</b>, so you can see the plan first and then
        decide what to do about those layers.</p>
        """

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterBoolean(
                self.APPLY,
                'Apply the changes (leave OFF to preview only)',
                defaultValue=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.TOWN,
                'Town name (blank = use the project name) — lets it strip a '
                'town prefix like "Lulekani Distribution"',
                defaultValue='', optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT,
                'Standardised GeoPackage (only written when applying)',
                fileFilter='GeoPackage (*.gpkg)',
                optional=True, createByDefault=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.STYLES, 'Folder for the .qml styles',
                optional=True, createByDefault=False,
            )
        )
        self.addParameter(
            QgsProcessingParameterString(
                self.SNAPSHOT_ROOT, 'Snapshot folder',
                defaultValue='C:/VelocityNexus/snapshots', optional=True,
            )
        )

    # ------------------------------------------------------------------ run
    def processAlgorithm(self, parameters, context, feedback):
        import os

        from fibre_automation import project_snapshot as ps
        from fibre_automation.velocity_schema import standardise, validate

        project = QgsProject.instance()
        do_apply = self.parameterAsBool(parameters, self.APPLY, context)
        town = (self.parameterAsString(parameters, self.TOWN, context) or '').strip()
        out_path = self.parameterAsFileOutput(parameters, self.OUTPUT, context)
        style_dir = self.parameterAsString(parameters, self.STYLES, context)
        snap_root = (self.parameterAsString(parameters, self.SNAPSHOT_ROOT, context)
                     or ps.DEFAULT_ROOT)

        if not town:
            town = project.baseName() or ''

        # Reported here, enforced at apply. A preview writes nothing to your
        # data, so refusing to show the plan because a scratch layer exists
        # withholds exactly the information needed to fix the scratch layer.
        # standardise.apply() raises on the same list; this is the human-facing
        # half of that, and it is deliberately loud.
        unsaveable = ps.unsaveable_layers(project)
        for u in unsaveable:
            feedback.reportError('NO ROLLBACK  %s  [%s] — %s'
                                 % (u['name'], u['provider'], u['reason']))
        if unsaveable and do_apply:
            raise QgsProcessingException(
                '%d layer(s) cannot be backed up, so applying would leave them '
                'with no rollback. Save them to a file (right-click the layer → '
                'Make Permanent) or remove them, then run again. Previewing is '
                'still allowed — untick Apply to see the plan.'
                % len(unsaveable))

        views, sources, handles = [], ps.sources_from_project(project), {}
        for lyr in project.mapLayers().values():
            try:
                if lyr.dataProvider().name() != 'ogr':
                    continue
            except Exception:
                continue
            views.append(self._view_of(lyr, validate))

        if not views:
            raise QgsProcessingException(
                'No file-based vector layers in this project — nothing to do.')

        feedback.pushInfo('Town: %s' % (town or '(none)'))
        feedback.pushInfo('Reading %d layer(s), %d source file(s)…'
                          % (len(views), len(sources)))

        try:
            prev = standardise.preview(
                views, sources, project.baseName() or 'project',
                town=town, snapshot_root=snap_root, unsaveable=unsaveable)
        except standardise.Refused as exc:
            raise QgsProcessingException(str(exc))

        for line in standardise.format_preview(prev):
            feedback.pushInfo(line)

        if not do_apply:
            feedback.pushInfo('')
            feedback.pushInfo('PREVIEW ONLY — nothing was changed. The backup '
                              'above is real and verified; tick Apply to run '
                              'this exact plan.')
            if unsaveable:
                feedback.pushWarning(
                    'Applying is BLOCKED while %d layer(s) have no rollback — '
                    'see the NO ROLLBACK lines above.' % len(unsaveable))
            return {'APPLIED': False,
                    'NO_ROLLBACK': len(unsaveable),
                    'SNAPSHOT': prev['snapshot']['dir'],
                    'RENAMES': prev['renames'],
                    'FIELD_RENAMES': prev['field_renames']}

        if not out_path:
            raise QgsProcessingException(
                'Applying needs an output GeoPackage — set "Standardised '
                'GeoPackage". The source project is never edited in place.')

        def open_source(name, _h=handles):
            lyr = next((x for x in project.mapLayers().values()
                        if x.name() == name), None)
            if lyr is None:
                return None
            src = lyr.source().split('|')[0]
            sub = None
            for part in lyr.source().split('|')[1:]:
                if part.startswith('layername='):
                    sub = part.split('=', 1)[1]
            if not os.path.isfile(src):
                return None
            from osgeo import ogr
            if src not in _h:
                _h[src] = ogr.Open(src)
            ds = _h[src]
            return ds.GetLayerByName(sub) if sub else ds.GetLayer(0)

        try:
            rep = standardise.apply(prev, open_source, out_path,
                                    style_dir=style_dir or None, views=views,
                                    progress=feedback)
        except standardise.Refused as exc:
            raise QgsProcessingException(str(exc))

        for row in rep['verified']['layers']:
            mark = 'ok  ' if (row['count_ok'] and row['geometry_ok']
                              and row['fields_ok']) else 'FAIL'
            feedback.pushInfo('%s  %-30s %d features, geometry identical: %s'
                              % (mark, row['dst'], row['dst_count'],
                                 row['geometry_ok']))
        for s in rep['styles']:
            feedback.pushInfo('style  %-30s on %s (%s)'
                              % (s['layer'], s['attribute'], s['kind']))

        if not rep['ok']:
            feedback.reportError(rep['msg'] or 'standardise failed')
            feedback.reportError('Roll back from: %s' % rep['rollback'])
            raise QgsProcessingException(
                'The rewrite did not verify. Nothing in your source files was '
                'changed; the snapshot is at %s' % rep['rollback'])

        feedback.pushInfo('')
        feedback.pushInfo('Wrote %s' % out_path)
        feedback.pushInfo('Rollback if needed: %s' % rep['rollback'])
        return {'APPLIED': True, 'OUTPUT': out_path,
                'SNAPSHOT': rep['rollback'],
                'RENAMES': prev['renames'],
                'FIELD_RENAMES': prev['field_renames'],
                'STYLES': len(rep['styles'])}

    # -------------------------------------------------------------- helpers
    @staticmethod
    def _view_of(layer, validate, sample=400):
        """A read-only LayerView of a QGIS layer, sampling values for vocabularies.

        Sampled, not exhaustive: a vocabulary check needs to see which values
        occur, not how often, and walking every feature of a 7,000-drop layer
        on the Qt main thread would freeze QGIS.
        """
        names = [f.name() for f in layer.fields()]
        geom = ''
        try:
            from qgis.core import QgsWkbTypes
            geom = QgsWkbTypes.displayString(layer.wkbType()).lower()
        except Exception:
            pass
        values = {n: set() for n in names}
        try:
            for i, feat in enumerate(layer.getFeatures()):
                if i >= sample:
                    break
                for n in names:
                    v = feat[n]
                    if v is not None and len(values[n]) < 60:
                        values[n].add(v)
        except Exception:
            pass
        return validate.LayerView(
            layer.name(), names, geom, layer.featureCount(),
            {k: sorted(v, key=str) for k, v in values.items()})
