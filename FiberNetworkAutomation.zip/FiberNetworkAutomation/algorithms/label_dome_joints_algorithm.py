# Label Dome Joints Algorithm

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing
)

from .base_algorithm import BaseFiberAlgorithm


class LabelDomeJointsAlgorithm(BaseFiberAlgorithm):
    """Algorithm to label Dome Joint layers"""

    def name(self):
        return 'labeldomejoints'

    def displayName(self):
        return '4. Label Dome Joints'

    def shortHelpString(self):
        return """
        Auto-populate Dome Joint fields.

        Fields updated:
        - id: 1, 2, 3...
        - Name: PRAK-Z01-DJ001, DJ002... (3-digit padding)
        - x: longitude
        - y: latitude
        - Block: PRAK-Z1-B001 (spatial lookup)
        - AG: PRAK-Z1-AG01 (spatial lookup)
        - fid: 1, 2, 3...

        ⚠️ Run Aggregation Polygons and Blocks first!
        """

    def initAlgorithm(self, config=None):
        # Input layer
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'Dome Joints Layer',
                [QgsProcessing.SourceType.TypeVectorPoint]
            )
        )

        # Project selection
        self.add_common_parameters()

    def processAlgorithm(self, parameters, context, feedback):
        # Get parameters
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        project = self.get_project_code(parameters, context)

        feedback.pushInfo(f"Labeling Dome Joints for {project}...")

        # Update id
        feedback.pushInfo("Updating id...")
        self.calculate_field(layer, "id", "@row_number", feedback)

        # Update Name (3-digit padding)
        feedback.pushInfo("Updating Name...")
        formula = f"'{project}-Z01-DJ' || lpad(to_string(\"id\"), 3, '0')"
        self.calculate_field(layer, "Name", formula, feedback)

        # Update x
        feedback.pushInfo("Updating x coordinate...")
        self.calculate_field(layer, "x", "x($geometry)", feedback)

        # Update y
        feedback.pushInfo("Updating y coordinate...")
        self.calculate_field(layer, "y", "y($geometry)", feedback)

        # Update Block (spatial)
        feedback.pushInfo("Updating Block (spatial lookup)...")
        formula = "array_first(overlay_contains('Block', \"Label\"))"
        self.calculate_field(layer, "Block", formula, feedback)

        # Update AG (spatial)
        feedback.pushInfo("Updating AG (spatial lookup)...")
        formula = "array_first(overlay_contains('Aggregation Polygon', \"Label\"))"
        self.calculate_field(layer, "AG", formula, feedback)

        # Update fid
        feedback.pushInfo("Updating fid...")
        self.calculate_field(layer, "fid", "@row_number", feedback)

        layer.triggerRepaint()
        feedback.pushInfo("✅ Dome Joints labeled successfully!")

        return {self.INPUT: layer.id()}
