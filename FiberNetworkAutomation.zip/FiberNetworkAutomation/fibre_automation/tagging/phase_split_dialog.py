"""phase_split_dialog — the "Split into Phases" UI.

Flow:  pick the phase polygons + layers + what to make  →  Preview (read-only)  →  Apply.
Apply runs, in order: back up the layer files → fill the Phase column (blanks + ticked
conflicts) → write Combined / Phase N folders → add the Phases group → open the folder.

The engine lives in phase_split / phase_export / phase_tree (Qt-free, harness-tested);
this module only gathers choices and shows results. Qt6 rules: qgis.PyQt shim only,
fully-scoped enums, values captured before any modal opens.
"""
import os
import time

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QFont
from qgis.PyQt.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
                                 QDialog, QFileDialog, QHBoxLayout, QHeaderView, QLabel,
                                 QLineEdit, QListWidget, QListWidgetItem, QMessageBox,
                                 QProgressDialog, QPushButton, QRadioButton, QTableWidget,
                                 QTableWidgetItem, QVBoxLayout)

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

try:
    from . import phase_export, phase_split, phase_tree
    from .zone_tag_dialog import _BTN, _geom_name, _hline, _section, _theme_colors
except ImportError:                                    # flat / path import
    import phase_export
    import phase_split
    import phase_tree
    from zone_tag_dialog import _BTN, _geom_name, _hline, _section, _theme_colors

TITLE = "Split into Phases"


def _default_out_dir(project):
    home = project.absolutePath() or os.path.expanduser("~")
    return os.path.normpath(os.path.join(home, "Shapefiles"))


def _long_field_layers(project, layer_ids):
    """[(layer name, [field names > 10 chars])] — shapefiles will shorten these."""
    out = []
    for lid in layer_ids:
        lyr = project.mapLayer(lid)
        if lyr is None:
            continue
        longs = [f.name() for f in lyr.fields() if len(f.name()) > 10]
        if longs:
            out.append((lyr.name(), longs))
    return out


def _open_in_explorer(path):
    """Open the folder in File Explorer with ``path`` selected (JJ, 2026-10-27)."""
    try:
        if os.name == "nt":
            import subprocess
            subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
            return
    except Exception:
        _swallowed_note()
    try:
        from qgis.PyQt.QtCore import QUrl
        from qgis.PyQt.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(path)))
    except Exception:
        _swallowed_note()


# ── main dialog ──────────────────────────────────────────────────────────────
class PhaseSplitDialog(QDialog):

    def __init__(self, project, parent=None):
        super().__init__(parent)
        self.project = project
        self._c = _theme_colors(self)
        self.setWindowTitle(TITLE)
        self.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
            Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint |
            Qt.WindowType.WindowMaximizeButtonHint)
        self.setMinimumSize(780, 680)
        self._build()

    # ── construction ─────────────────────────────────────────────────────────
    def _build(self):
        c = self._c
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(8)

        title = QLabel("🧩  " + TITLE)
        f = QFont()
        f.setBold(True)
        f.setPointSize(14)
        title.setFont(f)
        title.setStyleSheet(f"color:{c['accent']};")
        lay.addWidget(title)
        sub = QLabel("Every feature gets the phase polygon it sits in (cables: the phase "
                     "they run furthest in; outside every phase: the nearest one). Then "
                     "the layers are written as Combined + Phase folders and grouped by "
                     "phase in the Layers panel. Nothing is written until you press Apply.")
        sub.setWordWrap(True)
        sub.setStyleSheet(f"color:{c['muted']};font-size:9pt;")
        lay.addWidget(sub)
        lay.addWidget(_hline(c))

        # ── phase polygons ──
        lay.addWidget(_section("// PHASE POLYGONS", c))
        self._rb_field = QRadioButton("One layer holds every phase polygon")
        self._rb_layers = QRadioButton("One layer per phase, in a group")
        self._rb_field.setChecked(True)
        rb = QHBoxLayout()
        rb.addWidget(self._rb_field)
        rb.addWidget(self._rb_layers)
        rb.addStretch(1)
        lay.addLayout(rb)

        row = QHBoxLayout()
        self._poly = QComboBox()
        for lyr, _likely in phase_split.phase_layers(self.project):
            self._poly.addItem("%s   (%d)" % (lyr.name(), lyr.featureCount()), lyr.id())
        self._poly.setPlaceholderText("No polygon layers in this project")
        self._poly.setToolTip("The polygon layer you drew the phase boundaries in — "
                              "one polygon per phase (e.g. a layer called 'Phases').")
        self._field = QComboBox()
        self._field.setMinimumWidth(170)
        self._field.setPlaceholderText("Pick a layer first")
        self._field.setToolTip("The column in that layer that holds each polygon's phase "
                               "name, e.g. 'Phase' with values Phase 1, Phase 2…")
        self._group = QComboBox()
        for name, ids in self._polygon_groups():
            self._group.addItem("%s   (%d layers)" % (name, len(ids)), ids)
        self._group.setToolTip("A Layers-panel group holding one polygon layer per phase — "
                               "each layer's name is used as the phase name.")
        row.addWidget(QLabel("Phase polygon layer"))
        row.addWidget(self._poly, 1)
        row.addWidget(QLabel("Phase name field"))
        row.addWidget(self._field)
        row.addWidget(self._group, 1)
        lay.addLayout(row)
        self._phases_lbl = QLabel("")
        self._phases_lbl.setWordWrap(True)
        self._phases_lbl.setStyleSheet(f"color:{c['muted']};font-size:9pt;")
        lay.addWidget(self._phases_lbl)

        self._poly.currentIndexChanged.connect(lambda _i: self._on_poly_changed())
        self._field.currentIndexChanged.connect(lambda _i: self._refresh())
        self._group.currentIndexChanged.connect(lambda _i: self._refresh())
        self._rb_field.toggled.connect(lambda _on: self._refresh())

        # ── layers ──
        lay.addWidget(_section("// LAYERS TO SPLIT", c))
        self._targets = QListWidget()
        self._targets.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self._fill_targets()
        self._targets.itemChanged.connect(lambda _i: self._refresh())
        lay.addWidget(self._targets, 1)
        sel = QHBoxLayout()
        for text, state in (("Select all", Qt.CheckState.Checked),
                            ("None", Qt.CheckState.Unchecked)):
            b = QPushButton(text)
            b.setStyleSheet("QPushButton { padding: 3px 10px; }")
            b.clicked.connect(lambda _=False, s=state: self._set_all(s))
            sel.addWidget(b)
        sel.addStretch(1)
        self._count_lbl = QLabel("")
        self._count_lbl.setStyleSheet(f"color:{c['muted']};font-size:9pt;")
        sel.addWidget(self._count_lbl)
        lay.addLayout(sel)

        # ── what to make ──
        lay.addWidget(_section("// MAKE", c))
        self._cb_tag = QCheckBox("Fill the Phase column in these layers (blank cells only)")
        self._cb_files = QCheckBox("Write Combined + Phase folders to:")
        self._cb_tree = QCheckBox("Add a Phases group to the Layers panel")
        for cb in (self._cb_tag, self._cb_files, self._cb_tree):
            cb.setChecked(True)
            cb.toggled.connect(lambda _on: self._refresh())
        lay.addWidget(self._cb_tag)
        out = QHBoxLayout()
        out.addWidget(self._cb_files)
        self._out = QLineEdit(_default_out_dir(self.project))
        out.addWidget(self._out, 1)
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse)
        out.addWidget(browse)
        self._fmt = QComboBox()
        self._fmt.addItems(["Shapefile (.shp)", "GeoPackage (.gpkg)"])
        self._fmt.setToolTip("GeoPackage writes one .gpkg per file, same folders and "
                             "names — and keeps full field names (no 10-character cut).")
        self._fmt.currentIndexChanged.connect(lambda _i: self._refresh())
        out.addWidget(self._fmt)
        lay.addLayout(out)
        lay.addWidget(self._cb_tree)
        lay.addWidget(_hline(c))

        btns = QHBoxLayout()
        cancel = QPushButton("Cancel")
        cancel.setStyleSheet(_BTN.format(bg="#6b5320", hov="#8a6c2a"))
        cancel.clicked.connect(self.reject)
        self._preview_btn = QPushButton("Preview ▸")
        self._preview_btn.setStyleSheet(_BTN.format(bg="#1a6b3c", hov="#238a4f"))
        self._preview_btn.setDefault(True)
        self._preview_btn.clicked.connect(self._on_preview)
        btns.addWidget(cancel)
        btns.addStretch(1)
        btns.addWidget(self._preview_btn)
        lay.addLayout(btns)

        self._on_poly_changed()

    def _polygon_groups(self):
        """[(group name, [polygon layer ids])] for groups that hold 2+ polygon layers."""
        from qgis.core import QgsLayerTree, QgsVectorLayer, QgsWkbTypes
        out = []
        root = self.project.layerTreeRoot()
        for grp in root.findGroups(True):
            if grp.customProperty(phase_tree.MARK):
                continue
            ids = [n.layerId() for n in grp.children()       # direct children only
                   if QgsLayerTree.isLayer(n) and isinstance(n.layer(), QgsVectorLayer)
                   and QgsWkbTypes.geometryType(n.layer().wkbType()) == QgsWkbTypes.PolygonGeometry]
            if len(ids) >= 2:
                out.append((grp.name(), ids))
        out.sort(key=lambda t: ("phase" not in t[0].lower(), t[0].lower()))
        return out

    def _fill_targets(self):
        from qgis.core import QgsVectorLayer
        tool_ids = set()
        g = phase_tree.find_tool_group(self.project.layerTreeRoot())
        if g is not None:
            tool_ids = set(g.findLayerIds())
        for node in self.project.layerTreeRoot().findLayers():
            lyr = node.layer()
            if (not isinstance(lyr, QgsVectorLayer) or not lyr.isValid()
                    or not lyr.isSpatial() or lyr.id() in tool_ids):
                continue                           # plain tables have no phase to find
            copy = phase_split.looks_like_phase_copy(lyr.name())
            n = lyr.featureCount()
            txt = "%s     ·  %s  ·  %s" % (lyr.name(), format(n, ","), _geom_name(lyr))
            if copy:
                txt += "   (looks like a phase copy — left out)"
            it = QListWidgetItem(txt)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Unchecked if (copy or n == 0)
                             else Qt.CheckState.Checked)
            it.setData(Qt.ItemDataRole.UserRole, lyr.id())
            self._targets.addItem(it)

    # ── state ────────────────────────────────────────────────────────────────
    def _set_all(self, state):
        for i in range(self._targets.count()):
            self._targets.item(i).setCheckState(state)

    def _checked_ids(self):
        out = []
        for i in range(self._targets.count()):
            it = self._targets.item(i)
            if it.checkState() == Qt.CheckState.Checked:
                out.append(it.data(Qt.ItemDataRole.UserRole))
        return out

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, "Write the phase folders into", self._out.text())
        if d:
            self._out.setText(os.path.normpath(d))

    def _on_poly_changed(self):
        lid = self._poly.currentData()
        lyr = self.project.mapLayer(lid) if lid else None
        self._field.blockSignals(True)
        self._field.clear()
        if lyr is not None:
            self._field.addItem("— choose —", "")
            for f in lyr.fields():
                self._field.addItem(f.name(), f.name())
            guess = phase_split.guess_phase_field(lyr)
            i = self._field.findData(guess) if guess else 0
            self._field.setCurrentIndex(max(0, i))
        self._field.blockSignals(False)
        self._refresh()

    def _source(self):
        if self._rb_layers.isChecked():
            ids = self._group.currentData() or []
            return phase_split.PhaseSource("layers", ids) if ids else None
        lid = self._poly.currentData()
        fld = self._field.currentData()
        if not lid or not fld:
            return None
        return phase_split.PhaseSource("field", [lid], fld)

    def _refresh(self):
        by_layers = self._rb_layers.isChecked()
        self._poly.setEnabled(not by_layers)
        self._field.setEnabled(not by_layers)
        self._group.setEnabled(by_layers)
        self._group.setVisible(by_layers or self._group.count() > 0)
        src = self._source()
        if src is None and not by_layers and not self._poly.count():
            # set here, not once in _build: every _refresh rewrites this label
            self._phases_lbl.setText("⚠ This project has no polygon layers. Draw your phase "
                                     "boundaries as polygons in one layer (one polygon per "
                                     "phase, with a column holding its name), then reopen.")
        elif src is None and by_layers:
            self._phases_lbl.setText("Pick the group that holds one polygon layer per phase "
                                     "— each layer's name becomes the phase name.")
        elif src is None:
            self._phases_lbl.setText("Phase polygon layer = the layer with your phase "
                                     "boundaries. Phase name field = its column holding each "
                                     "phase's name (e.g. Phase 1, Phase 2…).")
        else:
            names = self._phase_names(src)
            self._phases_lbl.setText(
                ("%d phases: %s" % (len(names), ", ".join(names[:12])
                                    + (" …" if len(names) > 12 else "")))
                if names else "⚠ No phase values found there — pick another field.")
        n = len(self._checked_ids())
        self._count_lbl.setText("%d layer%s ticked" % (n, "" if n == 1 else "s"))
        self._out.setEnabled(self._cb_files.isChecked())
        self._fmt.setEnabled(self._cb_files.isChecked())
        any_make = (self._cb_tag.isChecked() or self._cb_files.isChecked()
                    or self._cb_tree.isChecked())
        self._preview_btn.setEnabled(bool(src is not None and n and any_make))

    def _phase_names(self, src):
        names = set()
        for lid in src.layer_ids:
            lyr = self.project.mapLayer(lid)
            if lyr is None:
                continue
            if src.kind == "layers":
                v = phase_split.phase_label(lyr.name())
                if v:
                    names.add(v)
                continue
            real = phase_split._field_lookup(lyr, src.field)
            if real is None:
                continue
            for f in lyr.getFeatures():
                v = phase_split.phase_label(f[real])
                if v:
                    names.add(v)
        return sorted(names, key=phase_split.natural_key)

    # ── preview ──────────────────────────────────────────────────────────────
    def _on_preview(self):
        src = self._source()
        targets = self._checked_ids()
        opts = {"tag": self._cb_tag.isChecked(), "files": self._cb_files.isChecked(),
                "tree": self._cb_tree.isChecked(), "out": self._out.text().strip(),
                "fmt": "gpkg" if self._fmt.currentIndex() == 1 else "shp"}
        if src is None or not targets:
            return
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            plan = phase_split.build_plan(self.project, src, targets)
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, TITLE, "Could not work out the phases:\n%s" % exc)
            return
        QApplication.restoreOverrideCursor()
        if plan.errors and not plan.layers:
            QMessageBox.warning(self, TITLE, "Nothing to do:\n\n• " + "\n• ".join(plan.errors))
            return
        export_ids = list(targets) + [i for i in src.layer_ids if i not in targets]
        dlg = PreviewDialog(self.project, plan, export_ids, opts, parent=self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.accept()


# ── preview + apply ──────────────────────────────────────────────────────────
class PreviewDialog(QDialog):

    def __init__(self, project, plan, export_ids, opts, parent=None):
        super().__init__(parent)
        self.project = project
        self.plan = plan
        self.export_ids = export_ids
        self.opts = opts
        self._c = _theme_colors(self)
        self._conflict_boxes = []      # (layer_id, fid, QCheckBox)
        self.setWindowTitle(TITLE + " — preview")
        self.setWindowFlags(
            Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
            Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint |
            Qt.WindowType.WindowMaximizeButtonHint)
        self.setMinimumSize(960, 700)
        self._build()

    def _build(self):
        c = self._c
        plan = self.plan
        lay = QVBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(8)
        title = QLabel("PREVIEW — nothing has been written yet")
        f = QFont()
        f.setBold(True)
        f.setPointSize(13)
        title.setFont(f)
        title.setStyleSheet(f"color:{c['accent']};")
        lay.addWidget(title)

        feats = sum(len(lp.assign) for lp in plan.layers.values())
        near = len(plan.nearest_rows())
        bits = ["%s features in %d layers" % (format(feats, ","), len(plan.layers)),
                "%d phases" % len(plan.phases),
                "%s blank Phase cells to fill" % format(plan.total_fill, ",")]
        if near:
            bits.append("%d outside every phase → nearest" % near)
        if plan.total_conflicts:
            bits.append("%d already set differently (kept unless ticked)" % plan.total_conflicts)
        bits.append("worked out in %.1f s" % plan.elapsed_s)
        sub = QLabel("   ·   ".join(bits))
        sub.setWordWrap(True)
        sub.setStyleSheet(f"color:{c['ink']};font-size:9.5pt;")
        lay.addWidget(sub)

        notes = list(plan.warnings)
        for lp in plan.layers.values():
            if lp.skipped_reason:
                notes.append("'%s' %s" % (lp.name, lp.skipped_reason))
        for lp in plan.layers.values():
            n = len(lp.assign)
            far = sum(1 for h in lp.how.values() if h == phase_split.HOW_NEAREST)
            if n >= 5 and far > 0.5 * n:
                notes.append("Most of '%s' (%d of %d) lies outside every phase — is it part "
                             "of this network? Untick it if not." % (lp.name, far, n))
        if self.opts["tag"]:
            new_field = [lp.name for lp in plan.layers.values()
                         if not lp.field_exists and not lp.skipped_reason]
            if new_field:
                notes.insert(0, "A new Phase field will be ADDED to %d layer%s: %s"
                             % (len(new_field), "" if len(new_field) == 1 else "s",
                                ", ".join(new_field[:10]) + (" …" if len(new_field) > 10 else "")))
        if self.opts["files"]:
            if self.opts.get("fmt") != "gpkg":          # GeoPackage keeps full field names
                for name, longs in _long_field_layers(self.project, self.export_ids):
                    notes.append("'%s': shapefiles cut field names to 10 characters (%s)."
                                 % (name, ", ".join(longs[:4]) + (" …" if len(longs) > 4 else "")))
            notes.append("Folders go to %s — any existing Combined / Phase folders there are "
                         "moved into _previous\\, not deleted." % self.opts["out"])
        if not self.opts["tag"] and (self.opts["files"] or self.opts["tree"]):
            notes.append("The Phase column is not being filled, so blank features stay out "
                         "of the phase folders and groups.")
        editing = [self.project.mapLayer(lid).name() for lid in plan.layers
                   if self.project.mapLayer(lid) is not None
                   and self.project.mapLayer(lid).isEditable()]
        for e in plan.errors:
            lbl = QLabel("✖  " + e)
            lbl.setWordWrap(True)
            lbl.setStyleSheet(f"color:{c['bad']};font-size:9pt;")
            lay.addWidget(lbl)
        if editing:
            lbl = QLabel("✖  In edit mode — save or discard first: " + ", ".join(editing))
            lbl.setWordWrap(True)
            lbl.setStyleSheet(f"color:{c['bad']};font-size:9pt;")
            lay.addWidget(lbl)
        for n in notes[:16]:
            lbl = QLabel("⚠  " + n)
            lbl.setWordWrap(True)
            lbl.setStyleSheet(f"color:{c['warn']};font-size:9pt;")
            lay.addWidget(lbl)

        lay.addWidget(_section("// FEATURES PER PHASE (after Apply)", c))
        lay.addWidget(self._counts_table(), 2)
        flagged = self._flagged_rows()
        lay.addWidget(_section("// CHECK THESE (%d)" % len(flagged), c))
        lay.addWidget(self._flag_table(flagged), 1)

        btns = QHBoxLayout()
        back = QPushButton("Cancel")
        back.setStyleSheet(_BTN.format(bg="#6b5320", hov="#8a6c2a"))
        back.clicked.connect(self.reject)
        btns.addWidget(back)
        btns.addStretch(1)
        self._apply_btn = QPushButton("✔  Apply")
        self._apply_btn.setStyleSheet(_BTN.format(bg="#1a6b3c", hov="#238a4f"))
        self._apply_btn.setDefault(True)
        self._apply_btn.setEnabled(bool(plan.layers) and not plan.errors and not editing)
        self._apply_btn.clicked.connect(self._on_apply)
        btns.addWidget(self._apply_btn)
        lay.addLayout(btns)

    def _counts_table(self):
        plan = self.plan
        cols = list(plan.phases) + ["No phase"]
        rows = list(plan.layers.values())
        tbl = QTableWidget(len(rows), 1 + len(cols))
        tbl.setHorizontalHeaderLabels(["Layer"] + cols)
        tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        tbl.verticalHeader().setVisible(False)
        keymap = {phase_split.phase_key(p): p for p in plan.phases}
        for r, lp in enumerate(rows):
            tbl.setItem(r, 0, QTableWidgetItem(lp.name))
            counts = {}
            for v, n in lp.counts().items():
                lab = keymap.get(phase_split.phase_key(v), v) if v else "No phase"
                counts[lab] = counts.get(lab, 0) + n
            for col, p in enumerate(cols, start=1):
                it = QTableWidgetItem(format(counts.get(p, 0), ","))
                it.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                tbl.setItem(r, col, it)
        tbl.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        return tbl

    def _flagged_rows(self):
        out = []
        for lid, lp in self.plan.layers.items():
            for fid, how in lp.how.items():
                if fid in lp.conflicts:
                    old, new = lp.conflicts[fid]
                    out.append((lid, fid, lp.name, lp.labels.get(fid), new,
                                "set to '%s'" % old, True))
                elif how == phase_split.HOW_NEAREST:
                    out.append((lid, fid, lp.name, lp.labels.get(fid), lp.assign.get(fid),
                                "outside every phase, %.0f m away" % lp.dist.get(fid, 0), False))
                elif how == phase_split.HOW_TIE:
                    out.append((lid, fid, lp.name, lp.labels.get(fid), lp.assign.get(fid),
                                "equal in two phases — lowest taken", False))
                elif how == phase_split.HOW_NONE and fid not in lp.old:
                    out.append((lid, fid, lp.name, lp.labels.get(fid), None,
                                "no geometry — no phase", False))
        return out

    def _flag_table(self, rows):
        cap = 2000
        tbl = QTableWidget(min(len(rows), cap), 5)
        tbl.setHorizontalHeaderLabels(["Layer", "Feature", "Polygon says", "Why",
                                       "Overwrite?"])
        tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        tbl.verticalHeader().setVisible(False)
        for r, (lid, fid, lname, label, phase, why, is_conflict) in enumerate(rows[:cap]):
            tbl.setItem(r, 0, QTableWidgetItem(lname))
            tbl.setItem(r, 1, QTableWidgetItem(str(label or fid)))
            tbl.setItem(r, 2, QTableWidgetItem(phase or "—"))
            tbl.setItem(r, 3, QTableWidgetItem(why))
            if is_conflict:
                cb = QCheckBox()
                tbl.setCellWidget(r, 4, cb)
                self._conflict_boxes.append((lid, fid, cb))
        for col in range(4):
            tbl.horizontalHeader().setSectionResizeMode(
                col, QHeaderView.ResizeMode.ResizeToContents)
        tbl.horizontalHeader().setStretchLastSection(True)
        return tbl

    # ── apply ────────────────────────────────────────────────────────────────
    def _on_apply(self):
        plan, opts = self.plan, self.opts
        overwrite = {}
        for lid, fid, cb in self._conflict_boxes:
            if cb.isChecked():
                overwrite.setdefault(lid, set()).add(fid)
        n_over = sum(len(v) for v in overwrite.values())
        steps = []
        if opts["tag"]:
            steps.append("• fill %s blank Phase cells%s (layer files are backed up first)"
                         % (format(plan.total_fill, ","),
                            " and overwrite %d you ticked" % n_over if n_over else ""))
        if opts["files"]:
            steps.append("• write Combined + %d Phase folders to\n    %s"
                         % (len(plan.phases), opts["out"]))
        if opts["tree"]:
            steps.append("• add a Phases group to the Layers panel")
        ok = QMessageBox.question(
            self, TITLE, "This will:\n\n" + "\n".join(steps) + "\n\nContinue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel)
        if ok != QMessageBox.StandardButton.Yes:
            return
        self._apply_btn.setEnabled(False)
        prog = QProgressDialog("Starting…", "Cancel", 0, 100, self)
        prog.setWindowTitle(TITLE)
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(0)
        prog.setValue(0)
        summary, problems = [], []
        try:
            summary, problems = self._run(prog, overwrite)
        except Exception as exc:
            problems.append("%s: %s" % (type(exc).__name__, exc))
        finally:
            prog.close()
        msg = "\n".join(summary)
        if problems:
            QMessageBox.warning(self, TITLE + " — check this",
                                msg + "\n\nProblems:\n• " + "\n• ".join(problems[:15]))
        else:
            QMessageBox.information(self, TITLE, "✔  Done\n\n" + msg)
        self.accept()

    def _step(self, prog, value, text):
        prog.setLabelText(text)
        prog.setValue(value)
        QApplication.processEvents()
        return not prog.wasCanceled()

    def _run(self, prog, overwrite):
        plan, opts, project = self.plan, self.opts, self.project
        summary, problems = [], []
        if opts["tag"]:
            if not self._step(prog, 2, "Backing up the layer files…"):
                return ["Cancelled before anything was written."], []
            home = project.absolutePath() or opts["out"] or os.path.expanduser("~")
            bdir = os.path.join(home, "_backups",
                                "Phase Split %s" % time.strftime("%Y-%m-%d %H%M%S"))
            touched = [lid for lid, lp in plan.layers.items()
                       if (lp.fill or overwrite.get(lid) or not lp.field_exists)
                       and not lp.skipped_reason]
            backed_up, copied, bproblems = phase_split.backup_layers(project, touched, bdir)
            if not backed_up:
                return [], ["Backup failed, nothing was written: " + "; ".join(bproblems[:3])]
            problems += bproblems
            summary.append("Backup: %d files in %s" % (len(copied), bdir))
            self._step(prog, 10, "Filling the Phase column…")
            res = phase_split.apply_plan(project, plan, overwrite)
            summary.append("Phase filled on %s features" % format(res.total_written, ","))
            if res.fields_added:
                summary.append("Phase field added to: " + ", ".join(res.fields_added[:8]))
            problems += res.errors + res.skipped
        ep = None
        if opts["files"] or opts["tree"]:
            if not self._step(prog, 20, "Sorting features into phases…"):
                return summary + ["Cancelled after the Phase column."], problems
            ep = phase_export.plan_export(project, plan, self.export_ids,
                                          opts["out"] or _default_out_dir(project),
                                          fmt=opts.get("fmt", "shp"))
            problems += ep.warnings
        if opts["files"] and ep is not None:
            if ep.errors:
                problems += ep.errors
            else:
                def cb(done, total, text):
                    return self._step(prog, 20 + int(65 * done / max(1, total)),
                                      "Writing %s…" % text)
                xr = phase_export.run_export(project, ep, progress=cb, plan=plan)
                problems += xr.errors
                bad = [c for c in xr.checks if not c[3]]
                problems += ["%s: Combined %d ≠ phases %d" % (c[0], c[1], c[2]) for c in bad]
                summary.append("Files: %d written to %s (every count re-checked: %s)"
                               % (len(xr.written), ep.out_dir,
                                  "all match" if not bad else "%d mismatch" % len(bad)))
                if xr.moved:
                    summary.append("Old folders moved to %s"
                                   % os.path.dirname(xr.moved[0][1]))
                if xr.report_path:
                    summary.append("Report: " + xr.report_path)
                    _open_in_explorer(xr.report_path)
        if opts["tree"] and ep is not None:
            self._step(prog, 90, "Adding the Phases group…")
            tr = phase_tree.build_group(project, ep)
            problems += tr.errors
            problems += ["%s shows %d features, expected %d" % m for m in tr.mismatch]
            summary.append("Layers panel: '%s' group with %d phase layers%s"
                           % (tr.group_name, tr.added,
                              " (replaced the previous one)" if tr.removed_old else ""))
        self._step(prog, 100, "Done")
        return summary, problems


# ── entry point (what the dock button calls) ─────────────────────────────────
def open_dialog(parent=None, project=None):
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    dlg = PhaseSplitDialog(project, parent=parent)
    dlg.exec()
