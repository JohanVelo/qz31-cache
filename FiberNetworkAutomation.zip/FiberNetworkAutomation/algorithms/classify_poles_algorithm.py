# Client-Aware Pole Classifier — "FT7 for HeroTel" (and Fibertime)
#
# claude:intent MUTATE — user asked (verbatim): "go and then publish when done"
# (build the A+B+C client-aware pole classifier per the approved blueprint). The
# ONLY write is the operator-triggered Processing algorithm with DRY_RUN
# UNticked — it bulk-writes pole role/thickness/road-crossing attributes. DRY_RUN
# defaults TRUE (preview counts, writes nothing); no write happens on import,
# registration, or a dry run. # claude:approved-destructive
#
# For each pole, reads its geometry facts (bend angle of the cable through it,
# whether it is a road crossing, whether it is an end-of-run) and assigns the
# correct role/height/thickness/reason per the CLIENT's spec, then writes them
# into the pole attribute table (auto-creating self-documenting columns).
#
# Reuses the SAME geometry logic as FT7 (ft_pole_thickness) but does NOT modify
# it — FT7 stays the locked Fibertime path.  A DRY-RUN preview shows the per-role
# counts before anything is written.

import math
import json
import os
from collections import defaultdict

from qgis.PyQt.QtCore import QMetaType
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean,
    QgsProcessing,
    QgsSpatialIndex,
    QgsGeometry,
    QgsWkbTypes,
    QgsFeature,
    QgsField,
)

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

SNAP_DEG = 10.0 / 111320.0   # 10 m in degrees


def _classifier():
    """The pure engine (bundled under fibre_automation)."""
    try:
        from fibre_automation import pole_classifier
    except Exception:
        from FiberNetworkAutomation.fibre_automation import pole_classifier
    return pole_classifier


def _roads_json_path():
    try:
        from fibre_automation.shared.vf_paths import roads_json
        return roads_json()
    except Exception:
        return os.path.join(os.environ.get('VF_DATA_DIR', 'C:/Temp'),
                            'roads.json')


class ClassifyPolesAlgorithm(QgsProcessingAlgorithm):
    """Classify poles to a client's engineering spec + flag road crossings."""

    POLES = 'POLES'
    CABLES = 'CABLES'
    ROADS = 'ROADS'
    CLIENT = 'CLIENT'
    DRY_RUN = 'DRY_RUN'

    def createInstance(self):
        return ClassifyPolesAlgorithm()

    def name(self):
        return 'classify_poles'

    def displayName(self):
        return 'Classify Poles (client-aware)'

    def group(self):
        return 'Fibertime Network Labeling'

    def groupId(self):
        return 'fibertimenetworklabeling'

    def shortHelpString(self):
        return (
            'Client-aware pole classifier ("FT7 for HeroTel"). For each pole it '
            'reads the bend angle of the cable through it, whether it is a road '
            'crossing (from a roads layer or C:/Temp/roads.json) and whether it '
            'is an end-of-run, then assigns role / height / thickness / reason '
            'per the chosen CLIENT and writes them into the pole table '
            '(auto-creating pole_role / road_cross / road_name / reason).\n\n'
            'HeroTel: 5.4m/100-120 straight, 5.4m/120-140 corner (>15deg), '
            '7.2m road crossing, 9m/140-160 exception.\n'
            'Fibertime: 140-160 anchor/strain (end-of-run | road crossing | '
            'dir change >15deg), else 120-140 intermediate.\n\n'
            'Tick DRY RUN to preview the per-role counts without writing.'
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.POLES, 'Poles layer',
            [QgsProcessing.SourceType.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterMultipleLayers(
            self.CABLES, 'Cable layers (define bends / ends / crossings)',
            QgsProcessing.SourceType.TypeVectorLine))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.ROADS, 'Roads layer (optional — else C:/Temp/roads.json)',
            [QgsProcessing.SourceType.TypeVectorLine], optional=True))
        self.addParameter(QgsProcessingParameterEnum(
            self.CLIENT, 'Client', options=list(_classifier().CLIENTS),
            defaultValue=0))
        self.addParameter(QgsProcessingParameterBoolean(
            self.DRY_RUN, 'DRY RUN (preview counts, write nothing)',
            defaultValue=True))

    # -- geometry facts (reuses FT7's logic) --------------------------------
    def _extract_facts(self, poles_lyr, cable_lyrs, road_index, road_meta,
                       feedback):
        pole_index = QgsSpatialIndex()
        pole_feats = {}
        for f in poles_lyr.getFeatures():
            g = f.geometry()
            if g and not g.isEmpty():
                pole_index.addFeature(f)
                pole_feats[f.id()] = f
        facts = {fid: {'bend_deg': 0.0, 'road_crossing': False,
                       'end_of_run': False, 'road_name': ''}
                 for fid in pole_feats}
        for lyr in cable_lyrs:
            for cab in lyr.getFeatures():
                if feedback.isCanceled():
                    return facts, pole_feats
                g = cab.geometry()
                if not g or g.isEmpty():
                    continue
                try:
                    coords = (g.asPolyline() if not g.isMultipart()
                              else g.asMultiPolyline()[0])
                except Exception:
                    _swallowed_note(); continue
                if len(coords) < 2:
                    continue
                tld = sum(math.sqrt((coords[i + 1].x() - coords[i].x()) ** 2 +
                                    (coords[i + 1].y() - coords[i].y()) ** 2)
                          for i in range(len(coords) - 1))
                if tld == 0:
                    continue
                bbox = g.boundingBox()
                bbox.grow(SNAP_DEG)
                here = []
                for fid in pole_index.intersects(bbox):
                    if g.distance(pole_feats[fid].geometry()) <= SNAP_DEG:
                        pos = g.lineLocatePoint(pole_feats[fid].geometry()) / tld
                        here.append((pos, fid))
                here.sort()
                n = len(here)
                for idx, (pos, fid) in enumerate(here):
                    if idx == 0 or idx == n - 1:
                        facts[fid]['end_of_run'] = True
                    elif 0 < idx < n - 1:
                        bend = self._bend(coords, tld, here[idx - 1][0], pos,
                                          here[idx + 1][0])
                        if bend > facts[fid]['bend_deg']:
                            facts[fid]['bend_deg'] = bend
                if road_index is not None:
                    self._road_hits(g, road_index, road_meta, pole_index,
                                    pole_feats, facts)
        return facts, pole_feats

    @staticmethod
    def _bend(coords, tld, p_prev, p_here, p_next):
        def tangent(p):
            target = p * tld
            acc = 0.0
            for i in range(len(coords) - 1):
                dx = coords[i + 1].x() - coords[i].x()
                dy = coords[i + 1].y() - coords[i].y()
                seg = math.sqrt(dx * dx + dy * dy)
                if acc + seg >= target or i == len(coords) - 2:
                    m = seg or 1.0
                    return dx / m, dy / m
                acc += seg
            return 1.0, 0.0
        t_in = tangent((p_prev + p_here) / 2)
        t_out = tangent((p_here + p_next) / 2)
        dot = max(-1.0, min(1.0, t_in[0] * t_out[0] + t_in[1] * t_out[1]))
        return math.degrees(math.acos(dot))

    @staticmethod
    def _road_hits(g, road_index, road_meta, pole_index, pole_feats, facts):
        for rid in road_index.intersects(g.boundingBox()):
            road_g = road_meta.get(('geom', rid))
            if road_g is None:
                continue
            # a GENUINE crossing (interiors cross) — not a cable merely running
            # along / touching a road, which over-counts in a dense grid.
            if g.crosses(road_g):
                inter = g.intersection(road_g)
                ipts = []
                try:
                    if QgsWkbTypes.flatType(inter.wkbType()) == \
                            QgsWkbTypes.Type.Point:
                        ipts = [inter.asPoint()]
                    elif inter.isMultipart():
                        ipts = list(inter.asMultiPoint())
                except Exception:
                    ipts = []
                for ipt in ipts:
                    for nfid in pole_index.nearestNeighbor(ipt, 2):
                        if g.distance(pole_feats[nfid].geometry()) <= SNAP_DEG:
                            facts[nfid]['road_crossing'] = True
                            nm = road_meta.get(('name', rid), '')
                            if nm:
                                facts[nfid]['road_name'] = nm

    def _load_roads(self, roads_lyr, feedback):
        """(road_index, meta) from a roads layer, else roads.json. meta maps
        ('geom',id)->geometry and ('name',id)->road name."""
        geoms = []
        names = []
        if roads_lyr is not None:
            nm_idx = None
            for cand in ('name', 'Name', 'road', 'ROAD', 'fullname'):
                if roads_lyr.fields().indexFromName(cand) != -1:
                    nm_idx = cand
                    break
            for f in roads_lyr.getFeatures():
                g = f.geometry()
                if g and not g.isEmpty():
                    geoms.append(g)
                    names.append(str(f[nm_idx]) if nm_idx else '')
        else:
            path = _roads_json_path()
            if not os.path.exists(path):
                feedback.pushWarning('No roads layer and no roads.json — road '
                                     'crossing detection skipped.')
                return None, {}
            with open(path, encoding='utf-8') as fh:
                data = json.load(fh)
            from qgis.core import QgsPointXY
            for el in data.get('elements', []):
                if el.get('type') == 'way' and 'geometry' in el:
                    pts = [QgsPointXY(p['lon'], p['lat'])
                           for p in el['geometry']]
                    if len(pts) >= 2:
                        geoms.append(QgsGeometry.fromPolylineXY(pts))
                        names.append(el.get('tags', {}).get('name', ''))
        if not geoms:
            return None, {}
        idx = QgsSpatialIndex()
        meta = {}
        for i, g in enumerate(geoms):
            ft = QgsFeature(i)
            ft.setGeometry(g)
            idx.addFeature(ft)
            meta[('geom', i)] = g
            meta[('name', i)] = names[i]
        feedback.pushInfo('Roads loaded: %d' % len(geoms))
        return idx, meta

    # -- run ----------------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):
        pc = _classifier()
        poles = self.parameterAsVectorLayer(parameters, self.POLES, context)
        cables = self.parameterAsLayerList(parameters, self.CABLES, context)
        roads = self.parameterAsVectorLayer(parameters, self.ROADS, context)
        client = pc.CLIENTS[self.parameterAsEnum(parameters, self.CLIENT,
                                                 context)]
        dry = self.parameterAsBoolean(parameters, self.DRY_RUN, context)
        if poles is None or not cables:
            raise Exception('Need a poles layer and at least one cable layer.')

        feedback.pushInfo('Loading roads...')
        road_index, road_meta = self._load_roads(roads, feedback)
        feedback.pushInfo('Extracting pole geometry facts...')
        facts, pole_feats = self._extract_facts(
            poles, cables, road_index, road_meta, feedback)

        results = {fid: pc.classify(client, fx) for fid, fx in facts.items()}
        role_counts = defaultdict(int)
        rc_count = 0
        for r in results.values():
            role_counts[r['role']] += 1
            if r['road_cross'] == 'Y':
                rc_count += 1

        feedback.pushInfo('-- %s -- %d poles --' % (client, len(results)))
        for role, c in sorted(role_counts.items(), key=lambda kv: -kv[1]):
            feedback.pushInfo('  %-16s %d' % (role, c))
        feedback.pushInfo('  road crossings   %d' % rc_count)

        if dry:
            feedback.pushInfo('DRY RUN -- nothing written. Untick DRY RUN to '
                              'write these into the pole table.')
            return {'poles': len(results), 'road_crossings': rc_count,
                    'roles': dict(role_counts), 'written': 0}

        written = self._write(poles, results, client, feedback)
        feedback.pushInfo('Wrote %d poles.' % written)
        return {'poles': len(results), 'road_crossings': rc_count,
                'roles': dict(role_counts), 'written': written}

    def _write(self, poles, results, client, feedback):
        # target fields: existing height/thick per client + the self-doc columns
        names = poles.fields().names()

        def pick(*cands):
            for c in cands:
                if c in names:
                    return c
            return None
        height_f = pick('Height', 'height_m', 'height')
        thick_f = pick('pole_thick', 'Pole Thick', 'dim2', 'thick_mm')
        to_add = []
        for col in ('pole_role', 'road_cross', 'road_name', 'reason'):
            if col not in names:
                to_add.append(QgsField(col, QMetaType.Type.QString, '', 60))
        if client == 'HeroTel' and height_f is None:
            to_add.append(QgsField('Height', QMetaType.Type.QString, '', 12))
        if thick_f is None:
            to_add.append(QgsField('pole_thick', QMetaType.Type.QString, '', 16))
        if to_add:
            poles.dataProvider().addAttributes(to_add)
            poles.updateFields()
            if client == 'HeroTel' and height_f is None:
                height_f = 'Height'
            if thick_f is None:
                thick_f = 'pole_thick'
        idx = {n: poles.fields().indexOf(n) for n in poles.fields().names()}

        def put(row, col, val):
            if col and col in idx and val is not None:
                row[idx[col]] = val
        changes = {}
        for f in poles.getFeatures():
            r = results.get(f.id())
            if not r:
                continue
            row = {}
            put(row, 'pole_role', r['role'])
            put(row, 'road_cross', r['road_cross'])
            put(row, 'road_name', r['road_name'])
            put(row, 'reason', r['reason'])
            put(row, thick_f, r['thick'])
            if r['height'] is not None:
                put(row, height_f, r['height'])
            if row:
                changes[f.id()] = row
        if changes:
            poles.dataProvider().changeAttributeValues(changes)
            poles.triggerRepaint()
        return len(changes)
