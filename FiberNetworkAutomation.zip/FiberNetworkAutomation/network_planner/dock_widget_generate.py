# claude:approved-destructive - handlers moved verbatim from dock_widget.py; writes only on explicit UI actions
"""GenerateMixin: the Network Planner network generation handlers (poles, drops, splitters, boundaries, spans, enclosures, AutoNet).

Moved verbatim out of dock_widget.py (2026-09-22) - FTTHPlanToolDockWidget inherits it, so
every call and signal connection resolves as before. Import only via dock_widget."""
from qgis.PyQt import sip
import colorsys
from qgis.PyQt.QtCore import QMetaType, Qt
try:
    from .. import theme_safe
except ImportError:
    pass   # standalone fallback
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import QApplication
from qgis.core import (
    QgsVectorLayer, QgsProject, QgsGeometry, QgsFeature, QgsField, QgsUnitTypes, QgsSpatialIndex, QgsRectangle,
    QgsFillSymbol, QgsMarkerSymbol, QgsSingleSymbolRenderer,
    QgsRendererCategory, QgsLineSymbol,
    QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
    QgsVectorLayerSimpleLabeling,
)
from qgis.gui import QgsMapLayerComboBox
try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass
try:
    from fibre_automation.shared.vf_paths import MAXPATH_BUDGET as _BACKUP_PATH_BUDGET
    from fibre_automation.shared.vf_paths import spill_root as _vf_shared_spill_root
except Exception:                                    # pragma: no cover
    _BACKUP_PATH_BUDGET = 245
    _vf_shared_spill_root = None
from .dock_widget import (  # noqa: E402 - defined before dock_widget imports this module
    AutoNetProgressDialog,
    PROFILE_TYPE_DEFAULT,
    _DROP_GRP_RE,
    _build_span_routing_graph,
    _categorized_with_catch_all,
    _coord_round,
    _demand_group_field,
    _m_to_units,
    _safe_commit,
    _safe_ellipsoid,
    _span_route_pts,
    format_cable_profile,
    get_cable_profile,
)



class GenerateMixin:
    """Methods of FTTHPlanToolDockWidget; relies on its attributes, never instantiated alone."""

    def on_generate_splitters_clicked(self):
        """Generate splitter points on span line for each group."""
        from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject, QgsField, QgsPointXY
        from qgis.PyQt.QtCore import QMetaType
        import math
        
        # Find the grouped layer — prefer the instance reference set by Step 1
        grouped_layer = None
        try:
            from qgis.PyQt import sip as _sip
            if self.grouped_layer and not _sip.isdeleted(self.grouped_layer):
                grouped_layer = self.grouped_layer
        except Exception:
            _swallowed_note()
        if not grouped_layer:
            # #4 anti-scatter: in a PON-per-PON BATCH the grouped layer MUST be the
            # batch's own layer (set by step 1). The name-search fallback below would
            # grab a stale full-project 'Groups of 8' layer left by an earlier standard
            # run and place splitters for the WHOLE project — scattering them far
            # outside the selection polygon. So in batch mode, refuse to guess.
            if getattr(self, '_current_batch_label', None):
                self.log_message(
                    "⛔ ERROR: PON-per-PON batch has no grouped layer from step 1 "
                    "(grouping failed for this batch) — splitters SKIPPED to avoid "
                    "placing them from a stale project-wide layer.")
                return
            # Fallback: find the most recently added grouped layer (highest feature count as tie-breaker)
            _best_layer = None
            _best_count = -1
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    layer_name = layer.name().lower()
                    if (('groups of 8' in layer_name or 'group of 8' in layer_name or
                         'groups of 16' in layer_name or 'group of 16' in layer_name or
                         'groups of 128' in layer_name or 'group of 128' in layer_name or
                         'groups of 100' in layer_name or 'group of 100' in layer_name) and
                       'boundary' not in layer_name and
                       'splitter' not in layer_name):
                        _fc = layer.featureCount()
                        if _fc > _best_count:
                            _best_count = _fc
                            _best_layer = layer
            if _best_layer:
                self.log_message(f"⚠ WARNING: self.grouped_layer was None — using fallback layer '{_best_layer.name()}' "
                                 f"({_best_count} features). Check if step 1 ran correctly for this batch.")
                grouped_layer = _best_layer
        
        if not grouped_layer:
            self.log_message("ERROR: Could not find grouped layer.")
            self.log_message("Please run 'Generate PONs' first.")
            return
        
        # Get span layer — for PON-per-PON use the full (unfiltered) span so all
        # Distribution spans are available for snapping, not just those inside the polygon
        _full_span = getattr(self, '_pon_full_span_layer', None)
        if _full_span is not None:
            try:
                from qgis.PyQt import sip as _sip_fs
                if _sip_fs.isdeleted(_full_span):
                    _full_span = None
            except Exception:
                _full_span = None
        span_layer = _full_span or self.comboBox_span_layer.currentLayer()
        if not span_layer:
            self.log_message("ERROR: Please select a Route/Span layer.")
            return
        
        # Check for group field — #79: detect any group_<N> size (incl. HeroTel
        # group_32/64) or batch_id, not a fixed list.
        src_field_names = [f.name() for f in grouped_layer.fields()]
        group_field = _demand_group_field(src_field_names)
        if not group_field:
            self.log_message("ERROR: Layer must have a group_<N> (e.g. group_8/16/32/128) or batch_id field.")
            return

        # Detect aggregation zone field so each splitter records which zone it belongs to
        zone_field_src = None
        if 'zone_id' in src_field_names:
            zone_field_src = 'zone_id'
        elif 'group_100' in src_field_names:
            zone_field_src = 'group_100'
        # DISPLAY-ONLY per-zone numbering: the demand layer may carry group_local (the
        # per-zone rank 1..N). If present, the splitter copies it so its label shows the
        # same per-zone number the crews read on the demand (else falls back to group_id).
        local_field_src = 'group_local' if 'group_local' in src_field_names else None

        self.log_message("\n=== Generating Splitter Points ===")
        self.log_message(f"Source layer: '{grouped_layer.name()}'")
        self.log_message(f"Source layer feature count: {grouped_layer.featureCount()}")
        self.log_message(f"Source layer fields: {src_field_names}")
        self.log_message(f"Span layer: '{span_layer.name()}'")
        self.log_message(f"Splitter-link field detected: '{group_field}'")
        # Check if span layer has Cable Type field for filtering Distribution spans
        span_field_names = [f.name() for f in span_layer.fields()]
        has_cable_type = 'Cable Type' in span_field_names
        if has_cable_type:
            self.log_message("🎯 FILTERING: Splitters will ONLY snap to Distribution spans (Cable Type = 'Distribution')")
            self.log_message("   Feeder and other span types will be IGNORED for splitter placement.")
            # Check all unique Cable Type values and count Distribution spans
            cable_types_found = set()
            dist_count = 0
            for _sf in span_layer.getFeatures():
                ct = str(_sf['Cable Type'] or '').strip()
                cable_types_found.add(ct)
                if ct.lower() == 'distribution':
                    dist_count += 1
            self.log_message(f"   Cable Type values in span layer: {sorted(cable_types_found)}")
            self.log_message(f"   Found {dist_count} Distribution span features")
            if dist_count == 0:
                self.log_message(
                    "⚠ WARNING: No Distribution spans found — falling back to ALL spans for splitter placement."
                )
                has_cable_type = False  # disable filter so all spans are used
        else:
            self.log_message("⚠ WARNING: Span layer has no 'Cable Type' field — using ALL spans for splitter placement")
        
        try:
            crs = grouped_layer.crs().authid()
            
            # Build layer name — include batch label when running PON-per-PON
            _splitter_layer_name = "Splitter Points"
            if getattr(self, '_current_batch_label', None):
                _splitter_layer_name = f"Splitter Points - {self._current_batch_label}"

            # Create splitter points layer
            splitter_layer = QgsVectorLayer(f"Point?crs={crs}",
                                           _splitter_layer_name,
                                           "memory")
            provider = splitter_layer.dataProvider()
            
            # Add fields
            provider.addAttributes([
                QgsField('fid', QMetaType.Type.Int),
                QgsField('ID', QMetaType.Type.QString),
                QgsField('group_id', QMetaType.Type.Int),
                QgsField('zone_id', QMetaType.Type.Int),    # aggregation zone membership
                QgsField('drop_count', QMetaType.Type.Int),   # number of demand points in this group
                # group_local = the group's per-zone RANK (1..N within its zone). This is
                # a DISPLAY-ONLY companion to group_id (which stays globally-unique so all
                # drop routing + Manual Override are untouched). It is copied verbatim from
                # the demand layer's own group_local so the splitter label ALWAYS matches
                # the number crews read on the demand (guards the #114/#126 mismatch). Left
                # NULL when the demand has no group_local (old data) → label falls back to
                # group_id, exactly the #126 behaviour.
                QgsField('group_local', QMetaType.Type.Int),
                # Diagnostics (appended at the END so existing field indices are
                # unchanged and every downstream reader — all of which use field
                # NAMES — is unaffected): serve_m = median distance from the splitter
                # to the houses it serves; own_run = the span feature id it snapped
                # onto. Any future "weird spot" is now explainable from the table.
                QgsField('serve_m', QMetaType.Type.Double),
                QgsField('own_run', QMetaType.Type.Int),
            ])
            splitter_layer.updateFields()
            
            # --- Locate poles layer for snapping (optional) ---
            # The old detector ONLY matched a layer literally named 'poles_*' WITH a
            # 'pole_type' field — so real pole layers ("Poles v1", "Distribution
            # Poles", "Feeder Poles") were never found and splitters snapped to the
            # bare span line, never to a pole. Broaden it: a point layer is a pole
            # layer if its name reads as poles (and isn't a splitter/enclosure/
            # junction) OR it carries a pole-identifying field. Prefer a
            # distribution / v1 pole layer, then the most-populated (main network
            # poles), so STS splitters snap to the poles on their Distribution route.
            from qgis.core import QgsSpatialIndex
            poles_layer = None
            _pole_cands = []
            for lyr in QgsProject.instance().mapLayers().values():
                if not (isinstance(lyr, QgsVectorLayer) and lyr.geometryType() == 0):  # Point only
                    continue
                _pnm = lyr.name().lower()
                _pfields = {f.name().lower() for f in lyr.fields()}
                _name_is_pole = ('pole' in _pnm and not any(
                    x in _pnm for x in ('splitter', 'enclosure', 'junction', 'closure')))
                _field_is_pole = bool(_pfields & {'pole_id', 'pole_type', 'pole_thick', 'pole size', 'pole type'})
                if _name_is_pole or _field_is_pole:
                    _pole_cands.append(lyr)
            if _pole_cands:
                def _pole_rank(l):
                    n = l.name().lower()
                    # distribution/v1 poles first (the STS route), then feature count
                    return (('distribution' in n) or (' v1' in n) or n.endswith('v1'),
                            l.featureCount())
                poles_layer = max(_pole_cands, key=_pole_rank)
                self.log_message(
                    f"Pole layer for snapping: '{poles_layer.name()}' "
                    f"({poles_layer.featureCount()} poles; "
                    f"{len(_pole_cands)} pole layer(s) seen)")

            # Build spatial index + coordinate lookup for poles on DISTRIBUTION spans only
            pole_coords = {}   # feature_id -> QgsPointXY
            pole_index = None
            if poles_layer:
                # PRE-FILTER: Only include poles that are on Distribution spans
                # For each pole, check if it's within snap distance of a Distribution span
                distribution_pole_ids = set()
                pole_snap_tolerance = 5.0  # meters - poles within 5m of a Distribution span
                # Batch B: on a GEOGRAPHIC CRS the coords are degrees, so 5.0 was
                # ~550 km → every pole counted as "on a Distribution span". Convert
                # metres→degrees (projected CRS unchanged).
                try:
                    _pcrs = poles_layer.crs()
                    if _pcrs.isValid() and _pcrs.isGeographic():
                        import math as _mb1
                        _plat = poles_layer.extent().center().y()
                        pole_snap_tolerance = 5.0 / (111320.0 * max(0.1, _mb1.cos(_mb1.radians(_plat))))
                except Exception:
                    _swallowed_note()
                
                if has_cable_type:
                    # Build spatial index of Distribution spans
                    dist_span_index = QgsSpatialIndex()
                    dist_span_geoms = {}
                    for span_feat in span_layer.getFeatures():
                        if str(span_feat['Cable Type'] or '').strip().lower() == 'distribution':
                            dist_span_index.insertFeature(span_feat)
                            dist_span_geoms[span_feat.id()] = span_feat.geometry()
                    
                    # Check each pole against Distribution spans
                    for pf in poles_layer.getFeatures():
                        # Batch C: skip null/empty pole geometry (known null-geom
                        # poles exist) — asPoint() on null yields NaN that poisons
                        # the spatial index + nearest-pole snap.
                        _pg = pf.geometry()
                        if not _pg or _pg.isEmpty():
                            continue
                        pole_pt = _pg.asPoint()
                        pole_bbox = QgsRectangle(
                            pole_pt.x() - pole_snap_tolerance,
                            pole_pt.y() - pole_snap_tolerance,
                            pole_pt.x() + pole_snap_tolerance,
                            pole_pt.y() + pole_snap_tolerance
                        )
                        nearby_spans = dist_span_index.intersects(pole_bbox)
                        # If pole is near ANY Distribution span, include it
                        for span_id in nearby_spans:
                            span_geom = dist_span_geoms.get(span_id)
                            if span_geom and not span_geom.isEmpty():
                                pole_geom = QgsGeometry.fromPointXY(pole_pt)
                                dist = pole_geom.distance(span_geom)
                                if dist <= pole_snap_tolerance:
                                    distribution_pole_ids.add(pf.id())
                                    break
                    
                    self.log_message(f"Filtered poles: {len(distribution_pole_ids)} of {poles_layer.featureCount()} poles are on Distribution spans")
                else:
                    # No Cable Type field - use all poles
                    distribution_pole_ids = {pf.id() for pf in poles_layer.getFeatures()}
                
                # Build index only for Distribution poles
                if distribution_pole_ids:
                    pole_index = QgsSpatialIndex()
                    for pf in poles_layer.getFeatures():
                        if pf.id() in distribution_pole_ids:
                            _pg = pf.geometry()
                            if not _pg or _pg.isEmpty():
                                continue
                            pole_index.insertFeature(pf)
                            pole_coords[pf.id()] = _pg.asPoint()
                    self.log_message(f"Snapping splitters to nearest Distribution pole ('{poles_layer.name()}')")
                else:
                    self.log_message("No poles on Distribution spans — snapping splitters to span line directly")
            else:
                self.log_message("No poles layer found — snapping splitters to nearest span line point")

            # Group features by group_id (skip ungrouped features where group_id is None)
            features_by_group = {}
            _ungrouped_sp = 0
            for feat in grouped_layer.getFeatures():
                group_id = feat[group_field]
                # NULL group_id must be treated as ungrouped. On Qt5 a NULL is QVariant(NULL)
                # (has .isNull()), not None — it slipped this check, became a dict key, and
                # then aborted the WHOLE run at the sorted() log line below. Catch both forms.
                if group_id is None or (hasattr(group_id, 'isNull') and group_id.isNull()):
                    _ungrouped_sp += 1
                    continue
                if group_id not in features_by_group:
                    features_by_group[group_id] = []
                features_by_group[group_id].append(feat)
            if _ungrouped_sp:
                self.log_message(f"Skipping {_ungrouped_sp} ungrouped feature(s) (no group_id)")
            self.log_message(f"Splitters found: {len(features_by_group)} (splitter IDs: {sorted(list(features_by_group.keys()))[:10]})")

            # BUGFIX: Guard against empty group dict — means step 1 produced no valid groups
            if not features_by_group:
                self.log_message("⛔ ERROR: No PONs with a valid group_id found in grouped layer.")
                self.log_message(f"   Layer: '{grouped_layer.name()}' has {grouped_layer.featureCount()} features but all have NULL group_id.")
                self.log_message("   This usually means step 1 (Generate PONs) failed or used the wrong layer.")
                self.log_message("   Re-draw the polygon selection and try again.")
                return

            # ----------------------------------------------------------------
            # Build spatial index of span geometries ONCE (fast per-group lookup)
            # ----------------------------------------------------------------
            from qgis.core import QgsSpatialIndex as _QSI2, QgsRectangle as _QRect2
            _snap_geoms = {}   # fid -> QgsGeometry
            _snap_index = _QSI2()
            _snap_count = 0
            for _sf in span_layer.getFeatures():
                if has_cable_type:
                    _ct = str(_sf['Cable Type'] or '').strip().lower()
                    if _ct != 'distribution':
                        continue
                _sg = _sf.geometry()
                if _sg and not _sg.isEmpty():
                    _snap_geoms[_sf.id()] = _sg
                    _snap_index.addFeature(_sf)
                    _snap_count += 1
            if _snap_count == 0 and has_cable_type:
                self.log_message("⚠ No Distribution spans indexed — falling back to all spans")
                for _sf in span_layer.getFeatures():
                    _sg = _sf.geometry()
                    if _sg and not _sg.isEmpty():
                        _snap_geoms[_sf.id()] = _sg
                        _snap_index.addFeature(_sf)
                        _snap_count += 1
            self.log_message(f"Span snap index: {_snap_count} feature(s) indexed")

            # Search radius for nearest-span lookup (expand if needed).
            # _SNAP_RADIUS = bbox half-size in LAYER UNITS (spatial-index prefilter only).
            # The real bound is a METRES cap (_SNAP_CAP_M) applied to the snap distance
            # below — the bbox is deliberately loose; the metres cap stops teleporting.
            _SNAP_RADIUS = 500.0
            _SNAP_CAP_M = 500.0            # accept only within this many METRES; one doubling → ~1 km hard cap
            _is_geo = False
            try:
                _scrs = span_layer.crs()
                if _scrs.isValid() and _scrs.isGeographic():
                    _is_geo = True
                    import math as _mb2
                    _slat = span_layer.extent().center().y()
                    _SNAP_RADIUS = 500.0 / (111320.0 * max(0.1, _mb2.cos(_mb2.radians(_slat))))
            except Exception:
                _swallowed_note()

            # Create splitter point for each group
            splitter_features = []
            total_groups_sp = len(features_by_group)
            _groups_skipped_error = 0
            _groups_no_span = 0   # groups with no Distribution span within a sane radius
            self.log_message(f"Processing {total_groups_sp} splitters...")
            self._start_operation("Generating Splitter Points…")
            for sp_idx, (group_id, group_features) in enumerate(features_by_group.items()):
                self._progress(sp_idx + 1, total_groups_sp, 'Splitters')
                if self._cancel_check():
                    self.log_message("⛔ Splitter generation cancelled.")
                    return
                if not group_features:
                    continue

                try:
                    # Calculate centroid of all features in group
                    all_points = []
                    for feat in group_features:
                        geom = feat.geometry()
                        if geom and not geom.isEmpty():
                            centroid = geom.centroid().asPoint()
                            all_points.append(centroid)

                    if not all_points:
                        continue

                    # ANCHOR = MEDOID of the group's houses (the house with the smallest
                    # summed distance to the rest) — NOT the arithmetic mean. The mean of a
                    # scattered / L-shaped group lands in an empty gap and then snaps to a
                    # parallel span on the wrong street; the medoid always sits on a real
                    # house, so the nearest span is the one that actually serves the group.
                    # Distance in METRES on both CRS types, so the bounded-radius and
                    # pole-snap thresholds below compare directly in metres (no unit drift).
                    # Geographic: scale lon by cos(lat), then both axes by ~111.32 km/deg.
                    # Projected (metre units): plain Euclidean — do NOT apply cos(lat); its
                    # y is a northing, not a latitude, and cos(northing) corrupted every dist.
                    if _is_geo:
                        _coslat = math.cos(math.radians(all_points[0].y())) or 1.0

                        def _md(a, b, _c=_coslat):
                            return math.sqrt(((a.x() - b.x()) * _c) ** 2
                                             + (a.y() - b.y()) ** 2) * 111320.0
                    else:
                        def _md(a, b):
                            return math.sqrt((a.x() - b.x()) ** 2 + (a.y() - b.y()) ** 2)

                    if len(all_points) <= 2:
                        anchor = all_points[0]
                    else:
                        anchor = min(all_points,
                                     key=lambda p: sum(_md(p, q) for q in all_points))

                    # Snap the anchor to the nearest Distribution span — BOUNDED by a METRES
                    # cap. The bbox (layer units) is only a spatial-index prefilter: a long
                    # span can clip the box while its nearest point sits far outside it, so
                    # every candidate is ALSO checked against cap_m in metres and REJECTED if
                    # beyond it (that check is what stops teleporting — the bbox alone can't).
                    # Try base cap, then ONE doubling (~1 km); if still nothing within the
                    # cap, SKIP + flag the group instead of teleporting onto a far span.
                    best_dist_point = None
                    min_distance = float('inf')
                    _best_fid = None
                    radius = _SNAP_RADIUS      # bbox half-size, LAYER UNITS
                    cap_m = _SNAP_CAP_M        # accept cap, METRES
                    for _try in range(2):      # base then ONE doubling — never 4 km
                        bbox = _QRect2(
                            anchor.x() - radius, anchor.y() - radius,
                            anchor.x() + radius, anchor.y() + radius,
                        )
                        _anchor_geom = QgsGeometry.fromPointXY(anchor)
                        for fid in _snap_index.intersects(bbox):
                            _sg = _snap_geoms[fid]
                            nearest = _sg.nearestPoint(_anchor_geom)
                            if nearest.isEmpty():
                                continue
                            np_pt = nearest.asPoint()
                            d = _md(anchor, np_pt)   # METRES
                            if d > cap_m + 1e-6:
                                continue             # beyond the searched radius — never teleport
                            # strict improvement, or exact tie broken by lowest fid → stable
                            if d < min_distance - 1e-9 or (
                                    abs(d - min_distance) <= 1e-9
                                    and (_best_fid is None or fid < _best_fid)):
                                min_distance = d
                                best_dist_point = np_pt
                                _best_fid = fid
                        if best_dist_point is not None:
                            break
                        if _try == 0:     # expand once for the final try; don't inflate the reported cap after it
                            radius *= 2   # bbox (layer units)
                            cap_m *= 2    # accept cap (metres) in lockstep

                    if best_dist_point is None:
                        self.log_message(
                            f"   ⚠ Group {group_id}: no Distribution span within "
                            f"~{cap_m:.0f} m of its houses — splitter SKIPPED (review this group)")
                        _groups_no_span += 1
                        continue

                    # OWN-ROUTE GUARD (PON-per-PON fix): the medoid's nearest span is not
                    # always the run the GROUP is strung along — a polygon-edge group can
                    # snap onto a NEIGHBOURING street's cable that is nearer the medoid but
                    # far from most of the group's houses (the reported "wrong street"
                    # splitter). If the chosen span serves the houses poorly (large median
                    # house→span distance), re-pick the candidate span that best SERVES the
                    # houses and snap there instead. On dense standard groups the medoid-
                    # nearest span already IS the best-serving one, so the cheap median
                    # check passes (< floor) and this block does nothing.
                    try:
                        def _med_house_dist(_fid):
                            _g = _snap_geoms.get(_fid)
                            if _g is None:
                                return float('inf')
                            _dd = sorted(
                                _md(p, _g.nearestPoint(QgsGeometry.fromPointXY(p)).asPoint())
                                for p in all_points)
                            return _dd[len(_dd) // 2] if _dd else float('inf')
                        _chosen_med = _med_house_dist(_best_fid)
                        # Only investigate when the chosen span looks off for the houses
                        # (median house distance beyond a normal drop) — keeps the common
                        # good case cheap (no per-candidate rescan on standard runs).
                        if _chosen_med > 40.0:
                            _alt_fid, _alt_med = _best_fid, _chosen_med
                            _bbox2 = _QRect2(anchor.x() - radius, anchor.y() - radius,
                                             anchor.x() + radius, anchor.y() + radius)
                            for _cfid in _snap_index.intersects(_bbox2):
                                if _cfid == _best_fid:
                                    continue
                                _cm = _med_house_dist(_cfid)
                                if _cm < _alt_med - 1e-9 or (
                                        abs(_cm - _alt_med) <= 1e-9 and _cfid < _alt_fid):
                                    _alt_med, _alt_fid = _cm, _cfid
                            # override ONLY for a meaningfully better-serving span (≥30%)
                            if _alt_fid != _best_fid and _alt_med < _chosen_med * 0.7:
                                _alt_np = _snap_geoms[_alt_fid].nearestPoint(
                                    QgsGeometry.fromPointXY(anchor))
                                if _alt_np and not _alt_np.isEmpty():
                                    best_dist_point = _alt_np.asPoint()
                                    _best_fid = _alt_fid
                                    self.log_message(
                                        f"   ↪ Group {group_id}: medoid-nearest span served its "
                                        f"houses poorly (~{_chosen_med:.0f} m); snapped to its own "
                                        f"run instead (~{_alt_med:.0f} m)")
                    except Exception:
                        _swallowed_note()

                    # Pole snap: land the splitter ON a pole rather than floating mid-span.
                    # Poles are 40-60 m apart, so the old 10 m tolerance almost never fired;
                    # ~30 m (≈ half a span) snaps it to the nearest pole on the route.
                    # _md is METRES on both CRS types, so compare to 30.0 m directly.
                    nearest_point = best_dist_point
                    if pole_index and pole_coords:
                        _pole_cands = pole_index.nearestNeighbor(
                            QgsPointXY(best_dist_point.x(), best_dist_point.y()), 1)
                        if _pole_cands:
                            _pp = pole_coords[_pole_cands[0]]
                            _pd = _md(QgsPointXY(best_dist_point.x(), best_dist_point.y()), _pp)
                            if _pd <= 30.0:
                                nearest_point = _pp

                    # Create splitter point feature
                    splitter_feat = QgsFeature(splitter_layer.fields())
                    splitter_feat.setGeometry(QgsGeometry.fromPointXY(nearest_point))

                    drop_count = len(group_features)
                    # Robust against a NULL / typed-null zone: on Qt5 a NULL comes back as
                    # QVariant(NULL), which passes an `is not None` check and then throws on
                    # int() — dropping the WHOLE group's splitter (crews get no STS). Mirror
                    # the local_val guard below: try int(), fall back to the -1 sentinel.
                    zone_int = -1
                    if zone_field_src:
                        _zv = group_features[0][zone_field_src]
                        if _zv is not None:
                            try:
                                zone_int = int(_zv)
                            except (TypeError, ValueError):
                                zone_int = -1
                    # Copy the demand's per-zone rank verbatim so the splitter label
                    # matches what crews read on the demand (NULL when absent → #126).
                    local_val = None
                    if local_field_src:
                        _lv = group_features[0][local_field_src]
                        if _lv is not None:
                            try:
                                local_val = int(_lv)
                            except (TypeError, ValueError):
                                local_val = None
                    # Diagnostics: median distance from this splitter to the houses it
                    # serves + the span fid it sits on (see field defs above).
                    try:
                        _sv = sorted(_md(nearest_point, p) for p in all_points)
                        _serve_m = float(round(_sv[len(_sv) // 2], 1)) if _sv else -1.0
                    except Exception:
                        _serve_m = -1.0
                    # SANITY GATE: never ship a splitter absurdly far from the homes it
                    # serves (a symptom of bad input or a pathological group). 250 m is
                    # far beyond any real drop, so a good run never trips it; a garbage
                    # placement is skipped + flagged rather than shipped.
                    if 0 <= _serve_m > 250.0:
                        self.log_message(
                            f"   ⚠ Group {group_id}: splitter would sit ~{_serve_m:.0f} m from "
                            f"its own houses (absurd — check input layers) — SKIPPED.")
                        continue
                    _own_run = int(_best_fid) if _best_fid is not None else -1
                    splitter_feat.setAttributes([
                        int(group_id),  # fid
                        str(group_id),  # ID
                        int(group_id),  # group_id
                        zone_int,       # zone_id
                        drop_count,     # drop_count
                        local_val,      # group_local (per-zone rank, display-only)
                        _serve_m,       # serve_m (median house→splitter distance, m)
                        _own_run,       # own_run (span fid the splitter sits on)
                    ])
                    splitter_features.append(splitter_feat)

                except Exception as _grp_err:
                    _groups_skipped_error += 1
                    self.log_message(f"   ⚠ Group {group_id}: Exception — {_grp_err} (skipping this group, continuing)")

            if _groups_skipped_error:
                self.log_message(f"⚠ {_groups_skipped_error} splitter(s) skipped due to errors (see above)")
            if _groups_no_span:
                self.log_message(
                    f"⚠ {_groups_no_span} group(s) had NO Distribution span nearby — no splitter "
                    f"placed for them (review these; they'd have been teleported to a far span before).")
            if not splitter_features:
                self.log_message("⛔ ERROR: No splitter points generated for this batch — "
                                 "check span layer has Distribution features near demand points.")
                return
            
            # Add features to layer
            provider.addFeatures(splitter_features)
            splitter_layer.updateExtents()
            
            # Apply symbology - green circles
            symbol = QgsMarkerSymbol.createSimple({
                'name': 'circle',
                'color': '0,255,0',
                'outline_color': 'black',
                'outline_width': '0.5',
                'size': '4'
            })
            renderer = QgsSingleSymbolRenderer(symbol)
            splitter_layer.setRenderer(renderer)
            
            # Add labels showing drop count
            from qgis.core import QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings, QgsVectorLayerSimpleLabeling
            from qgis.PyQt.QtGui import QFont, QColor
            
            label_settings = QgsPalLayerSettings()
            # Label: "Splitter <n> | PON <zone_id> [<drop_count>]"
            # <n> is the DISPLAY per-PON rank (group_local) when the demand carries it,
            # else the raw group_id. The #114/#126 rule still holds: the splitter shows the
            # SAME number the crews read on the demand — because group_local was copied
            # verbatim from the demand. coalesce() per-feature falls back to group_id for
            # any group with no local rank, so a mixed/old layer never shows a blank label.
            # NB: "group_id"/"zone_id"/"group_local" are the physical COLUMN names (Phase 2
            # rename); only the DISPLAY prefixes changed here to Splitter/PON.
            _grp_expr = 'coalesce("group_local", "group_id")' if local_field_src else '"group_id"'
            if zone_field_src:
                label_settings.fieldName = (
                    "'Splitter ' || " + _grp_expr + " || ' | PON ' || \"zone_id\" "
                    "|| ' [' || \"drop_count\" || ']'"
                )
                label_settings.isExpression = True
            else:
                label_settings.fieldName = "'Splitter ' || " + _grp_expr + " || ' [' || \"drop_count\" || ']'"
                label_settings.isExpression = True
            label_settings.enabled = True
            label_settings.placement = QgsPalLayerSettings.AroundPoint
            
            text_format = QgsTextFormat()
            text_format.setFont(QFont('Arial', 8))
            text_format.setSize(8)
            text_format.setColor(QColor('black'))
            
            buffer_settings = QgsTextBufferSettings()
            buffer_settings.setEnabled(True)
            buffer_settings.setSize(1.0)
            buffer_settings.setColor(QColor('white'))
            text_format.setBuffer(buffer_settings)
            
            label_settings.setFormat(text_format)
            
            labeling = QgsVectorLayerSimpleLabeling(label_settings)
            splitter_layer.setLabeling(labeling)
            splitter_layer.setLabelsEnabled(True)
            
            # Add layer to project
            splitter_layer = self._add_output_layer(splitter_layer)
            
            # Store reference for drop cable generation
            self.splitter_points_layer = splitter_layer
            
            # Calculate statistics
            total_drops = sum(f['drop_count'] for f in splitter_features)
            max_drops = max((f['drop_count'] for f in splitter_features), default=0)
            min_drops = min((f['drop_count'] for f in splitter_features), default=0)
            
            self.log_message(f"\nCreated {len(splitter_features)} splitter points")
            self._elapsed("Total time")
            self.log_message(f"  Total demand points: {total_drops}")
            self.log_message(f"  Max drops per splitter: {max_drops}")
            self.log_message(f"  Min drops per splitter: {min_drops}")
            self.log_message(f"Layer: '{splitter_layer.name()}'")
            # Pass 3: result summary — per-PON splitter counts (spec ≤16) + ungrouped
            # skips. Reads the built features only; placement algorithm is unchanged.
            try:
                from .generation_ux import splitter_summary
            except ImportError:
                from generation_ux import splitter_summary
            try:
                _sp_fnames = [fl.name() for fl in splitter_layer.fields()]
                _dc = [int(f['drop_count'] or 0) for f in splitter_features]
                _spp = {}
                if 'zone_id' in _sp_fnames:
                    for _f in splitter_features:
                        _z = _f['zone_id']
                        if _z is not None:
                            _spp[_z] = _spp.get(_z, 0) + 1
                for _ln in splitter_summary(_dc, _spp,
                                            ungrouped_skipped=locals().get('_ungrouped_sp', 0)):
                    self.log_message(_ln)
            except Exception as _ss_e:
                self.log_message(f"  (splitter summary skipped: {_ss_e})")
            if zone_field_src:
                self.log_message(f"PON membership sourced from field '{zone_field_src}'")
                self.log_message("Label shows: Splitter | PON [drop count]")
            else:
                self.log_message("No zone field found — zone_id set to -1; label shows drop count only")
            self.log_message("Splitters placed on span line for each PON")
            
        except Exception as e:
            self.log_message(f"ERROR generating splitters: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_drop_lashed_clicked(self, force_cross_fids=None):
        """Generate drop cables that follow the span network for drops >50 m (aerial lashed).

        force_cross_fids: demand FIDs the planner MANUALLY assigned (Manual Override) —
        their drops are allowed to cross a road even though the auto road-barrier would
        skip them (ticket #94, mirrors on_generate_drop_ptp_clicked). A bool from a
        button's clicked signal is treated as 'no overrides'."""
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject,
                               QgsField, QgsPointXY,
                               QgsUnitTypes,
                               QgsRuleBasedRenderer)
        from qgis.PyQt.QtCore import QMetaType
        import math
        
        # Try to use stored layer references first, then search if needed
        demand_points_layer = None
        splitter_points_layer = None
        
        # Check if stored references are valid
        try:
            if self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                demand_points_layer = self.demand_points_layer
                self.log_message(f"Using stored demand points layer: '{demand_points_layer.name()}'")
        except Exception:            _swallowed_note()
        
        try:
            if self.splitter_points_layer and not sip.isdeleted(self.splitter_points_layer):
                splitter_points_layer = self.splitter_points_layer
                self.log_message(f"Using stored splitter points layer: '{splitter_points_layer.name()}'")
        except Exception:            _swallowed_note()
        
        # Find demand points layer if not stored — prefer point geometry over polygon
        if not demand_points_layer:
            _dm_candidates = []
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    layer_name = layer.name().lower()
                    if 'demand points' in layer_name or 'demand_points' in layer_name:
                        _dm_candidates.append(layer)
            # Prefer point (geometryType 0) layers; fall back to first match
            _pt_layers = [l for l in _dm_candidates if l.geometryType() == 0]
            if _pt_layers:
                demand_points_layer = _pt_layers[0]
            elif _dm_candidates:
                demand_points_layer = _dm_candidates[0]
            if demand_points_layer:
                self.log_message(f"Found demand points layer: '{demand_points_layer.name()}'")

        if not demand_points_layer:
            self.log_message("ERROR: Could not find demand points layer.")
            self.log_message("Please generate demand points first.")
            return
        
        # Find splitter points layer if not stored
        if not splitter_points_layer:
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    layer_name = layer.name().lower()
                    if 'splitter' in layer_name and layer.geometryType() == 0:  # Point layer
                        splitter_points_layer = layer
                        self.log_message(f"Found splitter points layer: '{splitter_points_layer.name()}'")
                        break
        
        if not splitter_points_layer:
            self.log_message("ERROR: Could not find splitter points layer.")
            self.log_message("Please generate splitter points first.")
            return
        
        self.log_message("\n=== Generating Drop Cables Lashed ===")
        self.log_message(f"Demand points: '{demand_points_layer.name()}'")
        self.log_message(f"Splitters: '{splitter_points_layer.name()}'")
        
        try:
            crs = demand_points_layer.crs().authid()
            
            # Build layer name — batch-specific to preserve previous PON-per-PON runs
            _lashed_layer_name = "Drop Cables Lashed"
            if getattr(self, '_current_batch_label', None):
                _lashed_layer_name = f"Drop Cables Lashed - {self._current_batch_label}"

            # Remove existing layer of the SAME name only (don't touch other batches)
            for layer in list(QgsProject.instance().mapLayers().values()):
                if isinstance(layer, QgsVectorLayer) and layer.name() == _lashed_layer_name:
                    self.log_message(f"Updating existing {_lashed_layer_name} layer...")
                    QgsProject.instance().removeMapLayer(layer.id())
                    break

            # Create drop cables layer
            drop_cable_layer = QgsVectorLayer(f"LineString?crs={crs}",
                                             _lashed_layer_name,
                                             "memory")
            provider = drop_cable_layer.dataProvider()
            
            # Add fields - including fiber count from cable profile system
            provider.addAttributes([
                QgsField('cable_id', QMetaType.Type.Int),
                QgsField('group_id', QMetaType.Type.Int),
                QgsField('demand_id', QMetaType.Type.Int),
                QgsField('fiber_count', QMetaType.Type.Int),
                QgsField('fiber_size', QMetaType.Type.QString),
                QgsField('via_span', QMetaType.Type.Int),      # 1 = routed via span; 0 = direct
                QgsField('cable_length', QMetaType.Type.Double),   # length in METRES (QgsDistanceArea)
                QgsField('zone_id', QMetaType.Type.Int),      # aggregation zone membership
            ])
            drop_cable_layer.updateFields()
            
            # Add virtual field for length using $length expression
            from qgis.core import QgsField
            length_field = QgsField('length', QMetaType.Type.Double)
            length_field.setLength(10)
            length_field.setPrecision(2)
            drop_cable_layer.addExpressionField('$length', length_field)
            
            # Drop cables typically use smallest profile (1-2 fibers per customer)
            drop_fiber_count = get_cable_profile(1, PROFILE_TYPE_DEFAULT)  # 2F minimum
            drop_fiber_size = format_cable_profile(drop_fiber_count)
            self.log_message(f"Drop cable profile: {drop_fiber_size} (1 fiber per customer + spare)")
            
            # Get splitters indexed by group_id; also build zone lookup (group_id -> zone_id)
            splitters_by_group = {}
            zone_by_group = {}
            _sp_has_zone = 'zone_id' in [f.name() for f in splitter_points_layer.fields()]
            # Experiment-found bug: transform splitter points into the demand CRS when the
            # two layers differ (mixed import) so drops don't shoot off the map.
            _sp_xform = None
            try:
                from qgis.core import QgsCoordinateTransform
                _scrs = splitter_points_layer.crs(); _dcrs = demand_points_layer.crs()
                if _scrs.isValid() and _dcrs.isValid() and _scrs != _dcrs:
                    _sp_xform = QgsCoordinateTransform(_scrs, _dcrs, QgsProject.instance())
            except Exception:
                _sp_xform = None
            for _sp in splitter_points_layer.getFeatures():
                # Batch D: normalise the key to int (mirror the PTP path). Keying by
                # the raw QVariant let an int-vs-QVariant/str mismatch silently miss
                # every demand point of a group → whole groups of drops skipped.
                _sgid = _sp['group_id']
                if _sgid is None:
                    continue
                try:
                    _sgid = int(_sgid)
                except (TypeError, ValueError):
                    continue
                _sgeom = _sp.geometry()
                if _sgeom and not _sgeom.isEmpty():
                    # Experiment-found bug: a dict overwrite sent ALL of a group's drops
                    # to the LAST splitter sharing that group_id (often a far one). Keep
                    # every splitter per group and connect each demand to the NEAREST.
                    _spt = _sgeom.asPoint()
                    if _sp_xform is not None:
                        try:
                            _spt = _sp_xform.transform(_spt)
                        except Exception:
                            _swallowed_note()
                    splitters_by_group.setdefault(_sgid, []).append(_spt)
                if _sp_has_zone:
                    _zv = _sp['zone_id']
                    zone_by_group[_sgid] = int(_zv) if _zv is not None else -1

            self.log_message(f"Found {len(splitters_by_group)} splitters: {sorted(splitters_by_group.keys())}")

            # ---- Via-span routing setup ----------------------------------------
            # Drop cables longer than VIA_SPAN_THRESHOLD are routed to the nearest
            # point on the span line first, then onward to the splitter.
            # For PON-per-PON use the full span layer so routing covers the whole network
            _full_span_l = getattr(self, '_pon_full_span_layer', None)
            if _full_span_l is not None:
                try:
                    from qgis.PyQt import sip as _sip_fl
                    if _sip_fl.isdeleted(_full_span_l):
                        _full_span_l = None
                except Exception:
                    _full_span_l = None
            span_layer = _full_span_l or self.comboBox_span_layer.currentLayer()
            span_feats = {}
            span_index = None
            crs_units = demand_points_layer.crs().mapUnits()
            is_geographic = (crs_units == QgsUnitTypes.DistanceUnit.DistanceDegrees)
            # VIA_SPAN_THRESHOLD is in CRS units — it is compared against the
            # Cartesian `direct_dist` (also CRS units) to decide via-span routing,
            # so it must stay in degrees on a geographic CRS to match.
            VIA_SPAN_THRESHOLD = 0.00045 if is_geographic else 50.0  # ~50 m
            # cable_length is stored in true METRES via QgsDistanceArea so the
            # attribute table, the renderer (>50 m) and the warning label all agree
            # regardless of input CRS (spec: distances in projected metres).
            from qgis.core import QgsDistanceArea
            _drop_da = QgsDistanceArea()
            _drop_da.setSourceCrs(demand_points_layer.crs(), QgsProject.instance().transformContext())
            _drop_da.setEllipsoid(_safe_ellipsoid(QgsProject.instance(), demand_points_layer.crs()))
            DROP_WARN_M = 50.0  # spec: drop cables <=50 m (hard)
            if span_layer:
                span_feats = {f.id(): f for f in span_layer.getFeatures()}
                span_index = QgsSpatialIndex(span_layer.getFeatures())
                self.log_message(
                    f"Span layer: '{span_layer.name()}' ({len(span_feats)} segments)"
                    f" — cables >{VIA_SPAN_THRESHOLD:.0f} map units will follow span network")
            else:
                self.log_message("No span layer selected — all drop cables will be direct")

            # Build routing graph and pre-compute splitter snap points
            span_graph = None
            seg_ep = {}
            splitter_snaps = {}  # group_id -> (snap_pt, snap_fid)
            if span_feats:
                span_graph, seg_ep = _build_span_routing_graph(span_feats)
                self.log_message(
                    f"Routing graph: {span_graph.number_of_nodes()} nodes, "
                    f"{span_graph.number_of_edges()} edges")
                for _gid, _spts in splitters_by_group.items():
                    _spt = _spts[0] if _spts else None   # values are now lists (dup-group fix)
                    if _spt is None:
                        continue
                    _nearest = span_index.nearestNeighbor(_spt, 5)
                    _best_snap, _best_fid, _best_d = None, None, float('inf')
                    for _fid in _nearest:
                        _sg = span_feats[_fid].geometry()
                        _near = _sg.nearestPoint(QgsGeometry.fromPointXY(_spt))
                        if _near.isEmpty():
                            continue
                        _np = _near.asPoint()
                        _d = math.sqrt((_spt.x() - _np.x()) ** 2 + (_spt.y() - _np.y()) ** 2)
                        if _d < _best_d:
                            _best_d = _d
                            _best_snap = QgsPointXY(_np.x(), _np.y())
                            _best_fid = _fid
                    splitter_snaps[_gid] = (_best_snap, _best_fid)
            # -------------------------------------------------------------------

            # Check what fields exist in demand points
            demand_fields = [f.name() for f in demand_points_layer.fields()]
            self.log_message(f"Demand points fields: {demand_fields}")
            # #79: the group-link field is a layer CONSTANT — resolve it ONCE here
            # instead of rescanning demand_fields for every demand point in the loop.
            _drop_grp_field = next((fn for fn in demand_fields
                                    if _DROP_GRP_RE.fullmatch(fn) or fn == 'batch_id'), None)

            # Road crossing check — skip drops whose direct demand→splitter line crosses a road
            _crosses_road_lashed = self._build_road_crossing_checker(demand_points_layer.crs())
            # manually-assigned drops (Manual Override) allowed to cross a road (ticket #94).
            # A bool (from a button's clicked signal) means "no overrides".
            _fcl = force_cross_fids if isinstance(force_cross_fids, (set, frozenset, list, tuple)) else set()
            _fcl = set(_fcl)
            _show_all_l = self._show_all_drops()   # ticket #113: draw every drop, ignore road barrier
            _road_lyr = self.comboBox_road_layer.currentLayer() if hasattr(self, 'comboBox_road_layer') else None
            if _road_lyr and _show_all_l:
                self.log_message(f"Show all drops ON (#113) — road barrier '{_road_lyr.name()}' "
                                 "IGNORED; every drop drawn (incl. road crossings).")
            elif _road_lyr:
                _ovl = f" ({len(_fcl)} manually-assigned drop(s) allowed to cross)" if _fcl else ""
                self.log_message(f"Road barrier active: '{_road_lyr.name()}' — drops crossing roads will be skipped{_ovl}")

            # Create drop cable for each demand point to its group's splitter
            cable_features = []
            cable_id = 1
            skipped_no_group = 0
            skipped_no_splitter = 0
            skipped_road_cross = 0
            groups_found = set()
            connections_by_group = {}
            total_demand = demand_points_layer.featureCount()
            self.log_message(f"Connecting {total_demand} demand points to splitters...")
            self._start_operation("Generating Drop Cables Lashed…")
            for dc_idx, demand_point in enumerate(demand_points_layer.getFeatures()):
                self._progress(dc_idx + 1, total_demand, 'Drop cables')
                if self._cancel_check():
                    self.log_message("⛔ Drop cables (lashed) generation cancelled.")
                    return
                demand_geom = demand_point.geometry()
                if not demand_geom or demand_geom.isEmpty():
                    continue
                # Use centroid for polygon/line layers so non-point sources work correctly
                if demand_geom.type() == 0:  # Point
                    demand_pt = demand_geom.asPoint()
                else:
                    demand_pt = demand_geom.centroid().asPoint()
                
                # #79: match the demand group-link field by PATTERN (group_<N> any
                # size, incl. HeroTel group_32/group_64, or batch_id) — a hardcoded
                # list silently skipped sizes it didn't name, so drops never linked
                # to their dedicated splitter on those projects.
                # Batch D: normalise to int so the splitters_by_group lookup below
                # can't miss on an int-vs-QVariant type mismatch.
                group_id = None
                if _drop_grp_field is not None:
                    _raw = demand_point[_drop_grp_field]
                    if _raw is not None:
                        try:
                            group_id = int(_raw)
                        except (TypeError, ValueError):
                            group_id = None
                    if group_id is not None:
                        groups_found.add(group_id)

                if group_id is None:
                    skipped_no_group += 1
                    continue
                
                # Get splitter for this group (each demand point connects to splitter with matching group_id)
                if group_id not in splitters_by_group:
                    skipped_no_splitter += 1
                    continue
                
                _sp_cands = splitters_by_group[group_id]
                splitter_pt = (_sp_cands[0] if len(_sp_cands) == 1 else
                               min(_sp_cands, key=lambda _c: (_c.x()-demand_pt.x())**2
                                   + (_c.y()-demand_pt.y())**2))

                # Straight-line distance from demand point to splitter
                direct_dist = math.sqrt(
                    (demand_pt.x() - splitter_pt.x()) ** 2 +
                    (demand_pt.y() - splitter_pt.y()) ** 2
                )

                # Via-span routing: cables beyond threshold follow the span network
                # path: demand_pt → snap_on_span → [span] → snap_on_span → splitter_pt
                via_span_used = 0
                if span_index and span_feats and direct_dist > VIA_SPAN_THRESHOLD:
                    # Find nearest point on span for this demand point
                    snap_d, snap_d_fid, min_snap_d = None, None, float('inf')
                    for fid in span_index.nearestNeighbor(demand_pt, 5):
                        sg = span_feats[fid].geometry()
                        if not sg or sg.isEmpty():
                            continue
                        near_geom = sg.nearestPoint(QgsGeometry.fromPointXY(demand_pt))
                        if near_geom.isEmpty():
                            continue
                        np_pt = near_geom.asPoint()
                        d = math.sqrt((demand_pt.x() - np_pt.x()) ** 2 +
                                      (demand_pt.y() - np_pt.y()) ** 2)
                        if d < min_snap_d:
                            min_snap_d = d
                            snap_d = QgsPointXY(np_pt.x(), np_pt.y())
                            snap_d_fid = fid

                    snap_s, snap_s_fid = splitter_snaps.get(group_id, (None, None))

                    if snap_d and snap_s and span_graph:
                        span_pts = _span_route_pts(
                            snap_d, snap_d_fid, snap_s, snap_s_fid, span_graph, seg_ep)
                        if span_pts:
                            line_geom = QgsGeometry.fromPolylineXY(
                                [demand_pt] + span_pts + [splitter_pt])
                            via_span_used = 1
                        else:
                            # No graph path — fall back to simple 3-point line
                            line_geom = QgsGeometry.fromPolylineXY(
                                [demand_pt, snap_d, snap_s, splitter_pt])
                            via_span_used = 1
                    elif snap_d:
                        line_geom = QgsGeometry.fromPolylineXY(
                            [demand_pt, snap_d, splitter_pt])
                        via_span_used = 1
                    else:
                        line_geom = QgsGeometry.fromPolylineXY([demand_pt, splitter_pt])
                else:
                    line_geom = QgsGeometry.fromPolylineXY([demand_pt, splitter_pt])

                # Create feature (length auto-calculated by virtual field)
                # Skip drop if the direct demand→splitter line crosses a road — UNLESS
                # the planner manually assigned this demand point (its FID in _fcl), in
                # which case the planner's choice is honoured and the drop is forced
                # across the road (ticket #94).
                if (not _show_all_l) and (demand_point.id() not in _fcl) and _crosses_road_lashed(
                        demand_pt.x(), demand_pt.y(),
                        splitter_pt.x(), splitter_pt.y()):
                    skipped_road_cross += 1
                    continue

                cable_feat = QgsFeature(drop_cable_layer.fields())
                cable_feat.setGeometry(line_geom)
                cable_feat.setAttributes([
                    cable_id,
                    int(group_id),
                    int(demand_point.id()),
                    drop_fiber_count,
                    drop_fiber_size,
                    via_span_used,
                    round(_drop_da.measureLength(line_geom), 2),  # METRES — used by renderer
                    zone_by_group.get(int(group_id), -1),  # zone_id
                ])
                
                cable_features.append(cable_feat)
                
                # Track connections per group
                if group_id not in connections_by_group:
                    connections_by_group[group_id] = 0
                connections_by_group[group_id] += 1
                
                cable_id += 1
            
            self.log_message(f"Demand splitters found: {sorted(groups_found)}")
            self.log_message(f"Connections per splitter: {dict(sorted(connections_by_group.items()))}")
            if skipped_no_group > 0:
                self.log_message(f"Warning: {skipped_no_group} demand points had no group_id field")
            if skipped_no_splitter > 0:
                self.log_message(f"Warning: {skipped_no_splitter} demand points had no matching splitter")
                self.log_message(f"  Splitters: {sorted(splitters_by_group.keys())}")
                self.log_message(f"  Demand splitters: {sorted(groups_found)}")
            if skipped_road_cross > 0:
                self.log_message(f"🚫 Road barrier: {skipped_road_cross} drop(s) crossed a road — skipped")
            
            if len(cable_features) == 0:
                self.log_message("ERROR: No drop cables were created!")
                self.log_message("Please check that:")
                self.log_message("  1. Demand points have group_8, group_16, group_128, or group_100 field")
                self.log_message("  2. Splitters have matching group_id values")
                return
            
            # Add features to layer
            provider.addFeatures(cable_features)
            drop_cable_layer.updateExtents()
            
            # Apply rule-based symbology using stored cable_length field (METRES):
            #   cable_length > DROP_WARN_M (50 m)  → neon orange solid (warning)
            #   cable_length <= DROP_WARN_M (50 m) → red dashed (normal)
            # Use cookbook-style construction: renderer from default sym, then replace rules
            renderer = QgsRuleBasedRenderer(
                QgsLineSymbol.createSimple({'color': '220,0,0', 'width': '0.5', 'line_style': 'dash'}))
            root_rule = renderer.rootRule()
            for _r in root_rule.children()[:]:
                root_rule.removeChild(_r)
            rule_warn = QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple({'color': '255,140,0', 'width': '0.8', 'line_style': 'solid'}))
            rule_warn.setFilterExpression(f'"cable_length" > {DROP_WARN_M}')
            rule_warn.setLabel('Drop >50 m (WARNING)')
            root_rule.appendChild(rule_warn)
            rule_normal = QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple({'color': '220,0,0', 'width': '0.5', 'line_style': 'dash'}))
            # Batch A: ELSE catch-all — a drop with NULL/absent cable_length fails
            # BOTH "> threshold" and "<= threshold" (NULL comparisons are NULL), so
            # without an ELSE it would paint nothing. ELSE catches everything the
            # warn rule didn't.
            rule_normal.setFilterExpression('ELSE')
            rule_normal.setLabel('Drop ≤50 m')
            root_rule.appendChild(rule_normal)
            drop_cable_layer.setRenderer(renderer)
            
            # Add layer to project
            drop_cable_layer = self._add_output_layer(drop_cable_layer)
            
            # Calculate total length from the added features (virtual field will be populated)
            total_length = 0
            over_warn = 0
            for feat in drop_cable_layer.getFeatures():
                # cable_length is now in true METRES (QgsDistanceArea)
                fl = feat['cable_length'] if feat['cable_length'] else 0
                total_length += fl
                if fl > DROP_WARN_M:
                    over_warn += 1

            avg_length = total_length / len(cable_features) if len(cable_features) > 0 else 0

            via_span_count = sum(
                1 for f in drop_cable_layer.getFeatures() if f['via_span'] == 1)
            direct_count = len(cable_features) - via_span_count

            self.log_message(f"\nCreated {len(cable_features)} drop cables")
            self._elapsed("Total time")
            self.log_message(f"Layer: '{drop_cable_layer.name()}'")
            self.log_message(f"Total cable length: {total_length:.2f} m")
            self.log_message(f"Average cable length: {avg_length:.2f} m")
            self.log_message(
                f"Direct: {direct_count}  Via-span: {via_span_count}")
            if over_warn > 0:
                self.log_message(
                    f"WARNING: {over_warn} cable(s) exceed {DROP_WARN_M:.0f} m "
                    f"— shown in neon orange on map")
            self.log_message("Length field uses $length expression (auto-updates with geometry)")
            # Pass 3: result summary — drop lengths vs the 75 m max + no-splitter skips.
            # Reads the built cable_length field (ellipsoidal metres); routing unchanged.
            try:
                from .generation_ux import drop_summary
            except ImportError:
                from generation_ux import drop_summary
            try:
                _lens = [float(f['cable_length']) for f in drop_cable_layer.getFeatures()
                         if f['cable_length'] is not None]
                for _ln in drop_summary(_lens,
                                        no_splitter_skipped=locals().get('skipped_no_splitter', 0)):
                    self.log_message(_ln)
            except Exception as _ds_e:
                self.log_message(f"  (drop summary skipped: {_ds_e})")
            
        except Exception as e:
            self.log_message(f"ERROR generating drop cables: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_drop_ptp_clicked(self, silent=False, demand_layer=None,
                                     splitter_layer=None, drop_layer=None,
                                     force_cross_fids=None, only_groups=None):
        """Generate straight-line (point-to-point) drop cables from each demand point directly to its splitter.

        Args:
            silent: If True, suppress the main dock progress bar (used when called from Manual Override).
            demand_layer / splitter_layer / drop_layer: when supplied (e.g. from the
                Manual Override dialog), regenerate against THESE exact layers instead
                of re-resolving via accumulators / name-search. This guarantees that
                EVERY edit operation (reassign demand, move/delete splitter, add/delete
                demand point, the Regenerate-Drops button, …) rebuilds drops on the same
                layers the dialog is editing — no silent layer mismatch. When None, fall
                back to the accumulator → single-run-ref → name-search resolution.
        """
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsProject,
                               QgsField, QgsUnitTypes, QgsRuleBasedRenderer)
        from qgis.PyQt.QtCore import QMetaType

        # During a PON per PON batch run, use the batch-specific layers (set by pipeline steps).
        # Only use accumulators when called from Manual Override (regen after edit).
        _in_batch = bool(getattr(self, '_current_batch_label', None))

        def _alive(_lyr):
            if _lyr is None:
                return False
            try:
                return not sip.isdeleted(_lyr)
            except Exception:
                return True

        # Locate demand points layer — an explicit layer passed by the caller
        # (Manual Override) always wins over re-resolution.
        demand_points_layer = demand_layer if _alive(demand_layer) else None
        if not demand_points_layer and not _in_batch:
            try:
                _accum_grp = getattr(self, '_pon_accum_groups', None)
                if _accum_grp and not sip.isdeleted(_accum_grp) and _accum_grp.featureCount() > 0:
                    demand_points_layer = _accum_grp
            except Exception:
                _swallowed_note()
        try:
            if not demand_points_layer and self.demand_points_layer and not sip.isdeleted(self.demand_points_layer):
                demand_points_layer = self.demand_points_layer
        except Exception:            _swallowed_note()
        if not demand_points_layer:
            _dm_candidates = []
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    ln = layer.name().lower()
                    if 'demand points' in ln or 'demand_points' in ln:
                        _dm_candidates.append(layer)
            # Prefer point geometry layers; fall back to first match
            _pt_layers = [l for l in _dm_candidates if l.geometryType() == 0]
            if _pt_layers:
                demand_points_layer = _pt_layers[0]
            elif _dm_candidates:
                demand_points_layer = _dm_candidates[0]
        if not demand_points_layer:
            self.log_message("ERROR: Could not find demand points layer. Generate demand points first.")
            return

        # Locate splitter points layer — explicit caller layer wins.
        splitter_points_layer = splitter_layer if _alive(splitter_layer) else None
        if not splitter_points_layer and not _in_batch:
            try:
                _accum_sp = getattr(self, '_pon_accum_splitters', None)
                if _accum_sp and not sip.isdeleted(_accum_sp) and _accum_sp.featureCount() > 0:
                    splitter_points_layer = _accum_sp
            except Exception:
                _swallowed_note()
        try:
            if not splitter_points_layer and self.splitter_points_layer and not sip.isdeleted(self.splitter_points_layer):
                splitter_points_layer = self.splitter_points_layer
        except Exception:            _swallowed_note()
        if not splitter_points_layer:
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    if 'splitter' in layer.name().lower() and layer.geometryType() == 0:
                        splitter_points_layer = layer
                        break
        if not splitter_points_layer:
            self.log_message("ERROR: Could not find splitter points layer. Generate splitter points first.")
            return

        self.log_message("\n=== Generating Drop Cables PTP ===")
        self.log_message(f"Demand points: '{demand_points_layer.name()}'")
        self.log_message(f"Splitters:     '{splitter_points_layer.name()}'")

        try:
            crs = demand_points_layer.crs().authid()

            # Use the PON Drop Cables accumulator only when called from Manual Override
            # (i.e. regen after edit) — NOT during a PON per PON batch run, because the
            # batch layer must be created fresh so the merge step can append it correctly.
            _in_pon_batch = bool(getattr(self, '_current_batch_label', None))
            # An explicit drop_layer from the caller (Manual Override) is the target
            # to regenerate into; otherwise use the PON drops accumulator.
            _accum_drops = drop_layer if _alive(drop_layer) else getattr(self, '_pon_accum_drops', None)
            _use_accum = False
            if not _in_pon_batch:
                try:
                    if _accum_drops and not sip.isdeleted(_accum_drops):
                        _use_accum = True
                except Exception:
                    _swallowed_note()

            if _use_accum:
                drop_ptp_layer = _accum_drops
                provider = drop_ptp_layer.dataProvider()
                # Do NOT wipe existing drops yet. The old behaviour cleared the
                # accumulator here, then returned early when the rebuild produced
                # zero cables (e.g. a transient group/splitter mismatch after a
                # demand reassignment, or a mid-rebuild exception) — which silently
                # deleted EVERY drop cable on the whole project. Defer the wipe
                # until we know the rebuild succeeded, so a zero-result regen is a
                # no-op instead of data loss.
                # Incremental regen: when only_groups is set, replace ONLY those
                # groups' drops (delete just theirs below), leaving every other
                # group's drops untouched — identical result to a full rebuild for
                # the affected groups. Full rebuild (only_groups None) deletes all.
                if only_groups is not None:
                    _gi = provider.fields().indexFromName('group_id')
                    _existing_ids = []
                    if _gi >= 0:
                        for _ef in drop_ptp_layer.getFeatures():
                            try:
                                if int(_ef['group_id']) in only_groups:
                                    _existing_ids.append(_ef.id())
                            except (TypeError, ValueError):
                                continue
                else:
                    _existing_ids = list(drop_ptp_layer.allFeatureIds())
                # For accumulator use a plain QgsFields from the provider (no virtual fields)
                _accum_fields = provider.fields()
                self.log_message(f"  [Regen] Accumulator '{drop_ptp_layer.name()}': {len(_existing_ids)} existing features (wipe deferred until rebuild succeeds), fields: {[f.name() for f in _accum_fields]}")
            else:
                # Build layer name — batch-specific to preserve previous PON-per-PON runs
                _ptp_layer_name = "Drop Cables PTP"
                if getattr(self, '_current_batch_label', None):
                    _ptp_layer_name = f"Drop Cables PTP - {self._current_batch_label}"

                # Removal of the existing same-name layer is deferred until after
                # we confirm the rebuild produced features (see below) — so a
                # zero-result regen leaves the existing drop layer intact instead
                # of wiping it.
                # Create layer
                drop_ptp_layer = QgsVectorLayer(f"LineString?crs={crs}", _ptp_layer_name, "memory")
                provider = drop_ptp_layer.dataProvider()
                provider.addAttributes([
                    QgsField('cable_id', QMetaType.Type.Int),
                    QgsField('group_id', QMetaType.Type.Int),
                    QgsField('demand_id', QMetaType.Type.Int),
                    QgsField('fiber_count', QMetaType.Type.Int),
                    QgsField('fiber_size', QMetaType.Type.QString),
                    QgsField('via_span', QMetaType.Type.Int),      # always 0 for PTP
                    QgsField('cable_length', QMetaType.Type.Double),   # Cartesian CRS-unit length
                    QgsField('zone_id', QMetaType.Type.Int),      # aggregation zone membership
                ])
                drop_ptp_layer.updateFields()

                # Virtual length field
                vf = QgsField('length', QMetaType.Type.Double)
                vf.setLength(10)
                vf.setPrecision(2)
                drop_ptp_layer.addExpressionField('$length', vf)
                # For non-accum path, use layer fields (which includes virtual 'length')
                # but we set attributes by name so it's safe
                _accum_fields = drop_ptp_layer.dataProvider().fields()

            drop_fiber_count = get_cable_profile(1, PROFILE_TYPE_DEFAULT)
            drop_fiber_size = format_cable_profile(drop_fiber_count)
            self.log_message(f"Drop cable profile: {drop_fiber_size}")

            # Index splitters by group_id; also build zone lookup (group_id -> zone_id)
            # Normalise ALL keys to int to avoid type-mismatch misses (QVariant vs int)
            splitters_by_group = {}
            zone_by_group = {}
            _ptp_sp_has_zone = 'zone_id' in [f.name() for f in splitter_points_layer.fields()]
            # Experiment-found bug: if the splitter layer is in a DIFFERENT CRS than the
            # demand layer (mixed import / Manual Override Final picking layers from
            # different sources), mixing their raw coords builds drops that shoot off the
            # map. Transform splitter points into the demand CRS first.
            _sp_xform = None
            try:
                from qgis.core import QgsCoordinateTransform
                _scrs = splitter_points_layer.crs(); _dcrs = demand_points_layer.crs()
                if _scrs.isValid() and _dcrs.isValid() and _scrs != _dcrs:
                    _sp_xform = QgsCoordinateTransform(_scrs, _dcrs, QgsProject.instance())
            except Exception:
                _sp_xform = None
            for sp in splitter_points_layer.getFeatures():
                gid = sp['group_id']
                if gid is None:
                    continue
                try:
                    gid = int(gid)
                except (TypeError, ValueError):
                    continue
                sg = sp.geometry()
                if sg and not sg.isEmpty():
                    # Experiment-found bug: a dict overwrite sent ALL of a group's drops
                    # to the LAST splitter sharing that group_id (often a far one). Keep
                    # every splitter per group and connect each demand to the NEAREST.
                    _spt = sg.asPoint()
                    if _sp_xform is not None:
                        try:
                            _spt = _sp_xform.transform(_spt)
                        except Exception:
                            _swallowed_note()
                    splitters_by_group.setdefault(gid, []).append(_spt)
                if _ptp_sp_has_zone:
                    _zv = sp['zone_id']
                    zone_by_group[gid] = int(_zv) if _zv is not None else -1

            # Threshold for colour warning (same units logic as lashed)
            crs_units = demand_points_layer.crs().mapUnits()
            is_geographic = (crs_units == QgsUnitTypes.DistanceUnit.DistanceDegrees)
            PTP_WARN_THRESHOLD = 0.00045 if is_geographic else 50.0

            demand_fields = [f.name() for f in demand_points_layer.fields()]
            # #79: group-link field is a layer constant — resolve once (not per point).
            _drop_grp_field = next((fn for fn in demand_fields
                                    if _DROP_GRP_RE.fullmatch(fn) or fn == 'batch_id'), None)

            # Road crossing check — skip drops whose demand→splitter line crosses a road.
            # Ticket #68: drops for demand points the planner MANUALLY assigned to a
            # splitter (their FIDs in force_cross_fids) are allowed to cross — only
            # those, not a global toggle.
            # Tickets #111/#112: the manual "allow this drop across a road" decision is
            # PERSISTED on the project, so it survives a dialog close / zone revisit /
            # Regenerate Drops / reload. Seed the allowed-cross set from BOTH this call's
            # explicit fids AND the persisted set — otherwise every regen re-applies the
            # road barrier and silently deletes the planner's manually-routed drops.
            _fcf = set(force_cross_fids or set()) | self._load_force_cross(demand_points_layer)
            _show_all = self._show_all_drops()   # ticket #113: draw every drop, ignore road barrier
            _crosses_road_ptp = self._build_road_crossing_checker(demand_points_layer.crs())
            _road_lyr_ptp = self.comboBox_road_layer.currentLayer() if hasattr(self, 'comboBox_road_layer') else None
            if _road_lyr_ptp and _show_all:
                self.log_message(f"Show all drops ON (#113) — road barrier '{_road_lyr_ptp.name()}' "
                                 "IGNORED; every drop drawn (incl. road crossings).")
            elif _road_lyr_ptp:
                _ov = f" ({len(_fcf)} manually-assigned drop(s) allowed to cross)" if _fcf else ""
                self.log_message(f"Road barrier active: '{_road_lyr_ptp.name()}' — crossing drops skipped{_ov}")
                # Tickets #111/#112 (self-heal for drops placed BEFORE this fix shipped):
                # an EXISTING drop that crosses a road can only be one the planner forced
                # (auto drops are always skipped), so re-approve its demand point before we
                # rebuild — else an incremental regen deletes it and never recreates it.
                # Bounded to the affected group's existing drops (cheap, index-backed); a
                # full rebuild over a huge layer skips the scan to avoid a main-thread stall.
                if _use_accum and _existing_ids and (
                        only_groups is not None or len(_existing_ids) <= 600):
                    try:
                        from qgis.core import QgsFeatureRequest as _QFReq_fc
                        _did_i_fc = drop_ptp_layer.fields().indexFromName('demand_id')
                        _newly_fc = set()
                        if _did_i_fc >= 0:
                            _req_fc = _QFReq_fc().setFilterFids(list(_existing_ids))
                            for _edf in drop_ptp_layer.getFeatures(_req_fc):
                                _eg = _edf.geometry()
                                if not _eg or _eg.isEmpty():
                                    continue
                                _pts = _eg.asPolyline()
                                if len(_pts) < 2:
                                    continue
                                if _crosses_road_ptp(_pts[0].x(), _pts[0].y(),
                                                     _pts[-1].x(), _pts[-1].y()):
                                    try:
                                        _newly_fc.add(int(_edf['demand_id']))
                                    except (TypeError, ValueError):
                                        continue
                        if _newly_fc:
                            _fcf |= _newly_fc
                            self._save_force_cross(demand_points_layer, _fcf)
                            self.log_message(
                                f"  ✦ Preserved {len(_newly_fc)} existing road-crossing "
                                f"drop(s) the planner had manually routed.")
                    except Exception:
                        _swallowed_note()

            cable_features = []
            cable_id = 1
            skipped_no_group = 0
            skipped_no_splitter = 0
            skipped_road_cross = 0
            connections_by_group = {}
            total_demand = demand_points_layer.featureCount()
            self.log_message(f"Connecting {total_demand} demand points (straight line)...")
            if not silent:
                self._start_operation("Generating Drop Cables PTP…")

            for idx, demand_point in enumerate(demand_points_layer.getFeatures()):
                if not silent:
                    self._progress(idx + 1, total_demand, 'PTP drops')
                if not silent and self._cancel_check():
                    self.log_message("⛔ Drop cables (PTP) generation cancelled.")
                    return
                dg = demand_point.geometry()
                if not dg or dg.isEmpty():
                    continue
                # Use centroid for polygon/line sources so non-point layers work correctly
                if dg.type() == 0:  # Point
                    demand_pt = dg.asPoint()
                else:
                    demand_pt = dg.centroid().asPoint()

                # Resolve group_id — match the group-link field by PATTERN (#79:
                # group_<N> any size incl. HeroTel group_32/64, or batch_id) and
                # normalise to int to match splitters_by_group keys.
                group_id = None
                if _drop_grp_field is not None:
                    _raw = demand_point[_drop_grp_field]
                    if _raw is not None:
                        try:
                            group_id = int(_raw)
                        except (TypeError, ValueError):
                            group_id = None
                if group_id is None:
                    skipped_no_group += 1
                    continue
                if group_id not in splitters_by_group:
                    skipped_no_splitter += 1
                    continue

                _sp_cands = splitters_by_group[group_id]
                splitter_pt = (_sp_cands[0] if len(_sp_cands) == 1 else
                               min(_sp_cands, key=lambda _c: (_c.x()-demand_pt.x())**2
                                   + (_c.y()-demand_pt.y())**2))
                line_geom = QgsGeometry.fromPolylineXY([demand_pt, splitter_pt])

                # Batch D incremental regen: when only specific groups are being
                # regenerated, skip demand points outside them so untouched groups'
                # drops are left exactly as-is (fast path for single-edit Manual
                # Override — avoids re-routing the whole layer on every click).
                if only_groups is not None and int(group_id) not in only_groups:
                    continue

                # Skip drop if it crosses a road — UNLESS this specific demand point
                # was MANUALLY assigned to its splitter (ticket #68: only the drops
                # the planner deliberately assigned across a road are forced through).
                if (not _show_all) and (demand_point.id() not in _fcf) and _crosses_road_ptp(
                        demand_pt.x(), demand_pt.y(),
                        splitter_pt.x(), splitter_pt.y()):
                    skipped_road_cross += 1
                    continue

                feat = QgsFeature(_accum_fields if _use_accum else drop_ptp_layer.fields())
                feat.setGeometry(line_geom)
                # Build attribute list matching provider fields only (no virtual expression fields)
                _attr_map = {
                    'cable_id':    cable_id,
                    'group_id':    int(group_id),
                    'demand_id':   int(demand_point.id()),
                    'fiber_count': drop_fiber_count,
                    'fiber_size':  drop_fiber_size,
                    'via_span':    0,
                    'cable_length': line_geom.length(),
                    'zone_id':     zone_by_group.get(int(group_id), -1),
                }
                _flds = _accum_fields if _use_accum else drop_ptp_layer.fields()
                feat.setAttributes([_attr_map.get(f.name(), None) for f in _flds])
                cable_features.append(feat)
                connections_by_group[group_id] = connections_by_group.get(group_id, 0) + 1
                cable_id += 1

            if skipped_no_group:
                self.log_message(f"Warning: {skipped_no_group} demand points had no group_id field")
            if skipped_no_splitter:
                self.log_message(f"Warning: {skipped_no_splitter} demand points had no matching splitter")
            if skipped_road_cross:
                self.log_message(f"🚫 Road barrier: {skipped_road_cross} drop(s) crossed a road — skipped")

            if not cable_features:
                # MO audit: for INCREMENTAL regen (only_groups set), zero cables means the
                # affected group(s) legitimately have no drops now (last demand point
                # deleted) → DELETE their stale old drops instead of leaving an orphan
                # line on the canvas. For a FULL rebuild, zero matches signals a transient
                # mismatch → keep everything (the data-loss guard).
                if only_groups is not None and _use_accum and _existing_ids:
                    provider.deleteFeatures(_existing_ids)
                    drop_ptp_layer.updateExtents()
                    drop_ptp_layer.triggerRepaint()
                    try:
                        self._refresh_canvas_now()
                    except Exception:
                        _swallowed_note()
                    self.log_message(
                        f"  [Regen] affected group(s) now empty — removed "
                        f"{len(_existing_ids)} stale drop(s).")
                    return
                self.log_message(
                    "⚠ No PTP drop cables produced — group_id/splitter alignment "
                    "yielded zero matches. Existing drop cables were LEFT UNTOUCHED "
                    "(regen aborted, nothing deleted).")
                return

            # Write features to layer
            if _use_accum:
                # SAFE ORDERING — add the NEW drops first, confirm they actually
                # landed, and only THEN delete the OLD ones. The previous order
                # (delete-then-add) could wipe the whole layer if the add failed —
                # e.g. a read-only or schema-mismatched disk layer (GPKG/shapefile),
                # which is exactly how a saved drop-cable layer lost all its data.
                # If the write fails we roll back the partial insert and abort with
                # the existing drops untouched.
                _before = drop_ptp_layer.featureCount()
                _res = provider.addFeatures(cable_features)
                _ok  = _res[0] if isinstance(_res, tuple) else bool(_res)
                _added = _res[1] if (isinstance(_res, tuple) and len(_res) > 1) else []
                _after = drop_ptp_layer.featureCount()
                if not _ok or _after <= _before:
                    # Write failed — undo any partial insert, keep the old drops.
                    try:
                        if _added:
                            provider.deleteFeatures([f.id() for f in _added])
                    except Exception:
                        _swallowed_note()
                    self.log_message(
                        f"  ⚠ Drop write FAILED on '{drop_ptp_layer.name()}' "
                        "(layer not editable or schema mismatch). Existing drop "
                        "cables were LEFT INTACT — nothing was deleted.")
                    return
                # Write succeeded — now remove the OLD features (captured up-front).
                if _existing_ids:
                    provider.deleteFeatures(_existing_ids)
                drop_ptp_layer.updateExtents()
                self.log_message(f"  [Regen] wrote {len(cable_features)} drop cables → '{drop_ptp_layer.name()}' (total={drop_ptp_layer.featureCount()})")
            else:
                provider.addFeatures(cable_features)
            drop_ptp_layer.updateExtents()

            # Same construction as the lashed path's renderer (in production there):
            # over-threshold drops in solid orange, everything else - including a NULL
            # length, via the ELSE catch-all - in the plain black PTP style as before.
            # cable_length here is in CRS units, hence PTP_WARN_THRESHOLD (50 m).
            renderer = QgsRuleBasedRenderer(
                QgsLineSymbol.createSimple({'color': '0,0,0', 'width': '0.4', 'line_style': 'solid'}))
            root_rule = renderer.rootRule()
            for _r in root_rule.children()[:]:
                root_rule.removeChild(_r)
            rule_warn = QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple({'color': '255,140,0', 'width': '0.8', 'line_style': 'solid'}))
            rule_warn.setFilterExpression(f'"cable_length" > {PTP_WARN_THRESHOLD}')
            rule_warn.setLabel('Drop >50 m (WARNING)')
            root_rule.appendChild(rule_warn)
            rule_normal = QgsRuleBasedRenderer.Rule(
                QgsLineSymbol.createSimple({'color': '0,0,0', 'width': '0.4', 'line_style': 'solid'}))
            rule_normal.setFilterExpression('ELSE')
            rule_normal.setLabel('Drop ≤50 m')
            root_rule.appendChild(rule_normal)
            drop_ptp_layer.setRenderer(renderer)

            if _use_accum:
                drop_ptp_layer.triggerRepaint()
                # Force an immediate canvas redraw so the new drops show at once
                # instead of after a queued repaint (the reassign/move render lag).
                self._refresh_canvas_now()
            else:
                # Now that we have features, remove the previous same-name layer
                # (deferred from above) and add the freshly built one.
                for _old in list(QgsProject.instance().mapLayers().values()):
                    if isinstance(_old, QgsVectorLayer) and _old.name() == _ptp_layer_name:
                        QgsProject.instance().removeMapLayer(_old.id())
                        break
                drop_ptp_layer = self._add_output_layer(drop_ptp_layer)
            self.drop_ptp_layer = drop_ptp_layer

            self.log_message(f"\nCreated {len(cable_features)} PTP drop cables")
            if not silent:
                self._elapsed("Total time")
            self.log_message(f"Layer: '{drop_ptp_layer.name()}'")
            avg_length = sum(f['cable_length'] or 0 for f in cable_features) / len(cable_features) if cable_features else 0
            self.log_message(f"Average cable length: {avg_length:.2f} units")
            self.log_message(f"Connections per splitter: {dict(sorted(connections_by_group.items()))}")
            _over_warn = sum(1 for f in cable_features
                             if (f['cable_length'] or 0) > PTP_WARN_THRESHOLD)
            if _over_warn:
                self.log_message(f"WARNING: {_over_warn} PTP drop cable(s) exceed 50 m "
                                 "(shown in orange)")

        except Exception as e:
            self.log_message(f"ERROR generating PTP drop cables: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_boundaries_clicked(self):
        """Generate one polygon boundary per PON zone from the grouped demand points layer."""
        # Prefer the stored reference; fall back to searching project layers by field
        grouped_layer = self.grouped_layer
        if not grouped_layer:
            # Pick the grouped layer with the MOST features to avoid stale partial layers
            _best_layer = None
            _best_count = -1
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer):
                    if 'zone_name' in [f.name() for f in layer.fields()]:
                        _fc = layer.featureCount()
                        if _fc > _best_count:
                            _best_count = _fc
                            _best_layer = layer
            grouped_layer = _best_layer

        if not grouped_layer:
            self.log_message("ERROR: No grouped PON layer found. Run 'Generate PONs' first.")
            return

        field_names = [f.name() for f in grouped_layer.fields()]
        if 'zone_name' not in field_names:
            self.log_message("ERROR: Layer has no 'zone_name' field. Run 'Generate PONs' first.")
            return

        has_zone_id = 'zone_id' in field_names
        is_point_layer = grouped_layer.geometryType() == 0

        self.log_message("\n=== Generating PON Boundaries ===")
        self.log_message(f"Source layer: '{grouped_layer.name()}' ({grouped_layer.featureCount()} features)")
        if not self.grouped_layer:
            self.log_message("  (using project layer — if incomplete, re-run 'Generate PONs' first)")

        try:
            crs = grouped_layer.crs().authid()

            polygon_layer = QgsVectorLayer(
                f"Polygon?crs={crs}",
                f"{grouped_layer.name()} - PON Zones",
                "memory"
            )
            poly_provider = polygon_layer.dataProvider()
            poly_provider.addAttributes([
                QgsField('zone_name', QMetaType.Type.QString),
                QgsField('zone_id', QMetaType.Type.Int),
                QgsField('unit_count', QMetaType.Type.Int),
                QgsField('splitter_count', QMetaType.Type.Int),
            ])
            polygon_layer.updateFields()

            # Group field on the source layer — one PON group == one STS splitter,
            # so the number of distinct groups in a zone IS its splitter count
            # (used for the zone-boundary label, per the planner request).
            _grp_field = next(
                (fn for fn in field_names
                 if fn == 'group_id' or _DROP_GRP_RE.fullmatch(fn) or fn == 'batch_id'),
                None)  # #79: any group_<N> size, plus the splitter's group_id

            # Collect features per zone
            features_by_zone = {}
            zone_id_map = {}
            _total_feats = 0
            _null_zone_feats = 0
            _null_zone_list = []
            for feat in grouped_layer.getFeatures():
                _total_feats += 1
                z_name = feat['zone_name']
                if not z_name:
                    _null_zone_feats += 1
                    _null_zone_list.append(feat)
                    continue
                if z_name not in features_by_zone:
                    features_by_zone[z_name] = []
                    zone_id_map[z_name] = feat['zone_id'] if has_zone_id else 0
                features_by_zone[z_name].append(feat)
            self.log_message(f"Layer features: {_total_feats} total, "
                             f"{_total_feats - _null_zone_feats} with zone, "
                             f"{_null_zone_feats} with NULL zone_name (assigning to nearest zone)")

            # Assign NULL-zone features to the geographically nearest zone
            if _null_zone_list and features_by_zone:
                # Build one centroid per zone from its members
                _zone_cx = {}
                _zone_cy = {}
                for _zn, _zfeats in features_by_zone.items():
                    _gz = [_zf.geometry() for _zf in _zfeats]
                    _xs = [_g.centroid().asPoint().x()
                           for _g in _gz if _g and not _g.isEmpty()]
                    _ys = [_g.centroid().asPoint().y()
                           for _g in _gz if _g and not _g.isEmpty()]
                    if _xs:
                        _zone_cx[_zn] = sum(_xs) / len(_xs)
                        _zone_cy[_zn] = sum(_ys) / len(_ys)
                _zone_names_sorted = list(_zone_cx.keys())
                for _nf in (_null_zone_list if _zone_names_sorted else []):
                    _nf_geom = _nf.geometry()
                    if not _nf_geom or _nf_geom.isEmpty():
                        continue
                    _pt = _nf_geom.centroid().asPoint()
                    _best_z = min(
                        _zone_names_sorted,
                        key=lambda _zn: (_pt.x() - _zone_cx[_zn]) ** 2
                                       + (_pt.y() - _zone_cy[_zn]) ** 2
                    )
                    features_by_zone[_best_z].append(_nf)

            # ③ Voronoi-tiled boundaries (JJ 2026-06-25, HTML-approved): clean, straight-edged,
            # gap-free, non-overlapping zone tiles instead of rounded buffer blobs. Membership
            # is unchanged (uses each point's zone_name). Falls back to the buffer path per zone
            # if Voronoi can't be built for it.
            _voro = {}
            if is_point_layer:
                try:
                    _voro = self._voronoi_zone_polygons(grouped_layer, features_by_zone)
                    if _voro:
                        self.log_message(f"  Voronoi tiles: built {len(_voro)} clean PON polygons")
                except Exception as _ve:
                    self.log_message(f"  ⚠ Voronoi boundaries failed ({_ve}); using buffer fallback")
                    _voro = {}

            # Build one polygon per zone
            zone_polygons = []
            zone_build_params = {}   # z_name → {radius, mean_nn, coords}
            _total_zones = len(features_by_zone)

            self._start_timer()
            _QApp = QApplication
            _QApp.processEvents()
            for _bz_idx, (z_name, zone_feats) in enumerate(sorted(
                    features_by_zone.items(),
                    key=lambda kv: zone_id_map.get(kv[0], 0))):
                self._progress(_bz_idx + 1, _total_zones, 'Boundaries')

                geoms = [f.geometry() for f in zone_feats
                         if f.geometry() and not f.geometry().isEmpty()]
                if not geoms:
                    continue

                z_id = zone_id_map.get(z_name, 0)
                count = len(zone_feats)
                # splitter count = distinct groups in this zone (1 STS per group)
                if _grp_field:
                    splitter_count = len({_zf[_grp_field] for _zf in zone_feats
                                          if _zf[_grp_field] is not None})
                else:
                    splitter_count = 0

                if is_point_layer:
                    unit_type = grouped_layer.crs().mapUnits()
                    if unit_type == QgsUnitTypes.DistanceUnit.DistanceDegrees:
                        min_r, max_r = 0.00004, 0.00025   # ~4 m – 28 m at equator
                    else:
                        min_r, max_r = 4.0, 30.0           # metres

                    coords = [f.geometry().asPoint()
                              for f in zone_feats
                              if f.geometry() and not f.geometry().isEmpty()]

                    if len(coords) <= 1:
                        radius = max_r
                        mean_nn = max_r
                    else:
                        nn_sum, nn_count = 0.0, 0
                        for i, pt in enumerate(coords):
                            best = float('inf')
                            for j, other in enumerate(coords):
                                if i == j:
                                    continue
                                d = ((pt.x()-other.x())**2 +
                                     (pt.y()-other.y())**2) ** 0.5
                                if d < best:
                                    best = d
                            if best < float('inf'):
                                nn_sum += best
                                nn_count += 1
                        mean_nn = nn_sum / nn_count if nn_count else max_r
                        radius = max(min(mean_nn * 0.55, max_r), min_r)

                    # Buffer every point and union
                    merged = geoms[0].buffer(radius, 12)
                    for g in geoms[1:]:
                        merged = merged.combine(g.buffer(radius, 12))

                    # First: light morphological close to merge same-side gaps
                    close_r = radius * 0.5
                    candidate = merged.buffer(close_r, 8).buffer(-close_r, 8)
                    zone_geom = candidate if not candidate.isEmpty() else merged

                    # Second: if still multipart, directly snap parts together
                    if zone_geom.isMultipart():
                        zone_geom = self._snap_parts_together(zone_geom, radius)

                    # Last resort: convex hull (always single polygon)
                    if zone_geom.isMultipart():
                        zone_geom = zone_geom.convexHull()

                    # Store params for post-overlap consolidation
                    zone_build_params[z_name] = {
                        'radius': radius, 'mean_nn': mean_nn, 'coords': coords
                    }

                else:
                    # Dissolve parcel polygons then convex hull for a clean outer envelope
                    merged = geoms[0]
                    for g in geoms[1:]:
                        merged = merged.combine(g)
                    zone_geom = merged.convexHull()

                _vg = _voro.get(z_name)
                if _vg is not None and not _vg.isEmpty():
                    zone_geom = _vg     # ③ use the clean Voronoi tile for this zone

                poly_feat = QgsFeature(polygon_layer.fields())
                poly_feat.setGeometry(zone_geom)
                poly_feat.setAttributes([z_name, z_id, count, splitter_count])
                zone_polygons.append(poly_feat)

            # ── Remove overlaps between zone polygons ─────────────────────────
            # For any area where two zones overlap, assign it to whichever zone
            # has a demand point closer to that overlap region. (Voronoi tiles are
            # already disjoint, so this step is skipped when ③ Voronoi was used.)
            if not _voro and len(zone_polygons) > 1:
                # Build working list
                zone_data = []
                for pf in zone_polygons:
                    z = pf.attribute('zone_name')
                    pts = [f.geometry().asPoint()
                           for f in features_by_zone.get(z, [])
                           if f.geometry() and not f.geometry().isEmpty()]
                    zone_data.append([pf.geometry(), pts, pf])

                # Subtract overlaps: zone that owns an overlap area keeps it
                clipped_geoms = []
                for i, (g_i, pts_i, feat_i) in enumerate(zone_data):
                    clipped = g_i
                    z_name_i = feat_i.attribute('zone_name')
                    cx_i, cy_i = self._centroid_xy(pts_i)
                    for j, (g_j, pts_j, feat_j) in enumerate(zone_data):
                        if i == j:
                            continue
                        inter = clipped.intersection(g_j)
                        if inter.isEmpty():
                            continue
                        oc = inter.centroid().asPoint()
                        cx_j, cy_j = self._centroid_xy(pts_j)
                        di = (oc.x()-cx_i)**2 + (oc.y()-cy_i)**2
                        dj = (oc.x()-cx_j)**2 + (oc.y()-cy_j)**2
                        if dj < di:
                            diff = clipped.difference(inter)
                            if not diff.isEmpty():
                                clipped = diff
                            # If the difference fragmented the polygon, immediately
                            # consolidate back to a single polygon.
                            if clipped.isMultipart():
                                clipped = self._force_single(clipped, z_name_i, zone_build_params)
                    clipped_geoms.append(clipped)

                # Re-add any demand point that fell outside its clipped polygon
                unit_type = grouped_layer.crs().mapUnits()
                for i in range(len(clipped_geoms)):
                    z_n = zone_polygons[i].attribute('zone_name')
                    pts_i = zone_data[i][1]
                    if not pts_i:
                        continue
                    pad_r = zone_build_params.get(z_n, {}).get(
                        'radius',
                        0.000009 if unit_type == QgsUnitTypes.DistanceUnit.DistanceDegrees else 5.0
                    )
                    clipped = clipped_geoms[i]
                    for _pt in pts_i:
                        pt_geom = QgsGeometry.fromPointXY(_pt)
                        if not clipped.contains(pt_geom):
                            clipped = clipped.combine(pt_geom.buffer(pad_r, 8))
                    clipped_geoms[i] = clipped

                # Final pass: guarantee every zone is a single solid polygon
                for i in range(len(clipped_geoms)):
                    if clipped_geoms[i].isMultipart():
                        z_n = zone_polygons[i].attribute('zone_name')
                        clipped_geoms[i] = self._force_single(clipped_geoms[i], z_n, zone_build_params)

                for i, pf in enumerate(zone_polygons):
                    pf.setGeometry(clipped_geoms[i])

            poly_provider.addFeatures(zone_polygons)
            polygon_layer.updateExtents()

            # Categorised renderer — distinct colour per zone
            # For PON-per-PON batches, rotate hue by _pon_color_offset for visual separation
            _hue_base = getattr(self, '_pon_color_offset', 0.0)
            n = max(len(zone_polygons), 1)
            categories = []
            for i, pf in enumerate(zone_polygons):
                z_name = pf.attribute('zone_name')
                hue = (_hue_base + (i / n)) % 1.0
                r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.65, 0.88)]
                fill_col    = QColor(r, g, b, 70)
                outline_col = QColor(r, g, b, 230)
                sym = QgsFillSymbol.createSimple({
                    'color':         fill_col.name(QColor.NameFormat.HexArgb),
                    'outline_color': outline_col.name(),
                    'outline_width': '1.2',
                    'outline_style': 'solid',
                })
                categories.append(QgsRendererCategory(z_name, sym, z_name))

            polygon_layer.setRenderer(
                _categorized_with_catch_all(polygon_layer, 'zone_name', categories))

            # Labels — zone name + unit count + splitter count
            label_settings = QgsPalLayerSettings()
            label_settings.fieldName = (
                "zone_name || '\n' || unit_count || ' units' || "
                "'\n' || splitter_count || ' splitters'")
            label_settings.isExpression = True
            label_settings.enabled = True

            text_fmt = QgsTextFormat()
            text_fmt.setFont(QFont('Arial', 9, QFont.Weight.Bold))
            text_fmt.setSize(9)
            text_fmt.setColor(QColor('#1a1a1a'))

            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(1.0)
            buf.setColor(QColor('white'))
            text_fmt.setBuffer(buf)
            label_settings.setFormat(text_fmt)

            # Ticket #52 — flag the zone label BRIGHT RED when a PON exceeds 16 splitters
            # (16 is the max; >16 is over capacity). Data-defined text colour.
            try:
                from qgis.core import QgsProperty
                label_settings.dataDefinedProperties().setProperty(
                    QgsPalLayerSettings.Color,
                    QgsProperty.fromExpression(
                        "CASE WHEN \"splitter_count\" > 16 THEN '#ff0000' ELSE '#1a1a1a' END"))
            except Exception as _e:
                self.log_message(f"  ⚠ splitter-overflow label colour skipped: {_e}")

            polygon_layer.setLabeling(QgsVectorLayerSimpleLabeling(label_settings))
            polygon_layer.setLabelsEnabled(True)

            polygon_layer = self._add_output_layer(polygon_layer)
            self.zone_boundaries_layer = polygon_layer  # store for PON-per-PON merge
            self.log_message(f"Layer: '{polygon_layer.name()}'")
            # Pass 3: result summary — tile validity + overlap QA. Geometry is READ
            # only (never altered); the Voronoi tiler above is unchanged.
            try:
                from .generation_ux import boundary_summary
            except ImportError:
                from generation_ux import boundary_summary
            try:
                _vcs, _invalid, _geoms = [], 0, []
                for _f in polygon_layer.getFeatures():
                    _g = _f.geometry()
                    if not _g or _g.isEmpty() or not _g.isGeosValid():
                        _invalid += 1
                        continue
                    _vcs.append(sum(1 for _ in _g.vertices()))
                    _geoms.append(_g)
                _ov = 0
                for _i in range(len(_geoms)):
                    for _j in range(_i + 1, len(_geoms)):
                        if not _geoms[_i].boundingBoxIntersects(_geoms[_j]):
                            continue
                        _inter = _geoms[_i].intersection(_geoms[_j])
                        if _inter and not _inter.isEmpty() and _inter.area() > 1e-9:
                            _ov += 1
                for _ln in boundary_summary(_vcs, invalid=_invalid, overlapping_pairs=_ov):
                    self.log_message(_ln)
            except Exception as _bs_e:
                self.log_message(f"  (boundary summary skipped: {_bs_e})")
            self._elapsed("Total time")

        except Exception as e:
            self.log_message(f"ERROR generating PON boundaries: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_generate_poles_clicked(self):
        """Generate pole points along span layer at specified intervals — PHASE 1: Enhanced attributes per Herotel spec."""
        from qgis.core import QgsWkbTypes, QgsPointXY
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
                                         QLabel, QPushButton, QComboBox, QSpinBox)
        from qgis.PyQt.QtCore import Qt
        from qgis.PyQt.QtGui import QFont
        from qgis.core import QgsMapLayerProxyModel
        import math

        # ── Settings popup ────────────────────────────────────────────────
        dlg = QDialog(None)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.setWindowTitle("Generate Poles — PHASE 1 (Enhanced Herotel Specs)")
        dlg.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                           Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
        dlg.setMinimumWidth(380)
        lay = QVBoxLayout(dlg)
        lay.setSpacing(10)
        lay.setContentsMargins(18, 18, 18, 18)

        hdr = QLabel("🪧  Generate Poles — V105.1")
        hf = QFont(); hf.setBold(True); hf.setPointSize(10)
        hdr.setFont(hf); hdr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(hdr)

        info = QLabel("Choose Span Role: Feeder (7m) or Distribution (5.4-7m)\nRun separately for each span layer type")
        info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info.setStyleSheet(f'color:{theme_safe.colors()["muted"]};font-size:9pt;')
        lay.addWidget(info)

        form = QFormLayout()
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.DontWrapRows)

        span_combo = QgsMapLayerComboBox()
        span_combo.setFilters(QgsMapLayerProxyModel.LineLayer)
        current_span = self.comboBox_span_layer.currentLayer()
        if current_span:
            span_combo.setLayer(current_span)
        form.addRow("Span Layer:", span_combo)

        # NEW: Type filter (filter spans by their TYPE attribute before generation)
        # Resolver is an instance method (_resolve_span_type_field) so the dropdown
        # population and the generation-time filter use the EXACT same field.
        _resolve_type_field = self._resolve_span_type_field

        type_filter_combo = QComboBox()
        type_filter_combo.addItem("All spans")

        def _on_span_layer_change(lyr):
            """Update Type filter options when span layer changes."""
            type_filter_combo.blockSignals(True)
            type_filter_combo.clear()
            type_filter_combo.addItem("All spans")

            if lyr and lyr.geometryType() == 1:  # LineGeometry
                try:
                    type_idx = _resolve_type_field(lyr)
                    if type_idx >= 0:
                        unique_types = set()
                        for feat in lyr.getFeatures():
                            val = feat[type_idx]
                            if val is not None and str(val).strip():
                                unique_types.add(str(val))
                        for t in sorted(unique_types):
                            type_filter_combo.addItem(t)
                        self.log_message(
                            f"[Generate Poles] Type filter field: "
                            f"'{lyr.fields()[type_idx].name()}' "
                            f"({len(unique_types)} types)")
                except Exception:
                    pass
            type_filter_combo.blockSignals(False)

        span_combo.layerChanged.connect(_on_span_layer_change)
        _on_span_layer_change(current_span)
        form.addRow("Filter by Type:", type_filter_combo)

        # NEW: Explicit span role selector (override auto-detect)
        span_role_combo = QComboBox()
        span_role_combo.addItem("Auto-detect (from layer name)")
        span_role_combo.addItem("Feeder")
        span_role_combo.addItem("Distribution")
        span_role_combo.setCurrentIndex(0)
        form.addRow("Assign Pole Role:", span_role_combo)

        dist_combo = QComboBox()
        for v in [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]:
            dist_combo.addItem(str(v))
        dist_combo.addItem("Custom…")
        dist_combo.setCurrentIndex(4)   # default 50 m

        custom_spin = QSpinBox()
        custom_spin.setRange(1, 500)
        custom_spin.setValue(50)
        custom_spin.setEnabled(False)
        custom_spin.setSuffix(" m")

        def _on_dist_change(text):
            custom_spin.setEnabled(text == "Custom…")
        dist_combo.currentTextChanged.connect(_on_dist_change)

        form.addRow("Distance (m):", dist_combo)
        form.addRow("Custom value:", custom_spin)
        lay.addLayout(form)

        btn_row = QHBoxLayout()
        run_btn = QPushButton("Generate")
        run_btn.setStyleSheet("QPushButton { background-color: #2e4057; color: white; font-weight: bold; "
                              "padding: 5px 18px; border-radius: 4px; } QPushButton:hover { background-color: #3d5270; }")
        cancel_btn = QPushButton("Cancel")
        btn_row.addWidget(run_btn)
        btn_row.addWidget(cancel_btn)
        lay.addLayout(btn_row)

        # #101/#102 (#65 class): WA_DeleteOnClose tears the dialog's widgets down when it
        # closes, so reading span_combo / type_filter_combo / dist_combo / spin / role
        # AFTER dlg.exec() returns crashed with "QgsMapLayerComboBox has been deleted"
        # for multiple teammates (timing/Qt-version dependent). Capture EVERY value
        # up-front in the accept handler — while the widgets are still alive — and read
        # only from this dict afterwards.
        _vals = {}

        def _capture_and_accept():
            try:
                _vals['span_layer'] = span_combo.currentLayer()
                _vals['dist_text'] = dist_combo.currentText()
                _vals['custom'] = custom_spin.value()
                _vals['type_filter'] = type_filter_combo.currentText()
                _vals['span_role'] = span_role_combo.currentText()
            except RuntimeError:
                pass
            dlg.accept()

        run_btn.clicked.connect(_capture_and_accept)
        cancel_btn.clicked.connect(dlg.reject)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        span_layer = _vals.get('span_layer')
        if not span_layer:
            self.log_message("ERROR: Please select a span layer for pole generation.")
            return
        if span_layer.geometryType() != QgsWkbTypes.GeometryType.LineGeometry:
            self.log_message("ERROR: Span layer must be a line layer.")
            return

        dist_text = _vals.get('dist_text', '50')
        distance_meters = _vals.get('custom', 50) if dist_text == "Custom…" else int(dist_text)

        # Get Type filter selection (V105.1 feature)
        type_filter_value = _vals.get('type_filter', 'All spans')
        type_filter_enabled = (type_filter_value != "All spans")

        # Get explicit span role selection (V105.1 feature)
        span_role_selection = _vals.get('span_role', 'Auto-detect (from layer name)')
        if span_role_selection == "Auto-detect (from layer name)":
            span_type = self._detect_span_type(span_layer.name())
            self.log_message("\n=== Generating Poles — PHASE 1.1 (Enhanced, V105.1) ===")
            self.log_message(f"Span layer: '{span_layer.name()}'")
            self.log_message(f"Span role: Auto-detected as {span_type.upper()}")
        else:
            span_type = span_role_selection.lower()
            self.log_message("\n=== Generating Poles — PHASE 1.1 (Enhanced, V105.1) ===")
            self.log_message(f"Span layer: '{span_layer.name()}'")
            self.log_message(f"Span role: Explicitly set to {span_type.upper()}")
        
        if type_filter_enabled:
            self.log_message(f"Type filter: '{type_filter_value}'")
        self.log_message(f"Distance between poles: {distance_meters}m")

        try:
            from qgis.core import QgsVectorLayer, QgsFeature, QgsGeometry, QgsField
            from qgis.PyQt.QtCore import QMetaType
            from qgis.core import QgsMarkerSymbol, QgsRendererCategory

            self._start_timer()

            # CRS handling
            crs = span_layer.crs()
            is_geographic = crs.isGeographic()
            
            if is_geographic:
                extent = span_layer.extent()
                center_lat = (extent.yMinimum() + extent.yMaximum()) / 2
                meters_per_degree = 111320 * math.cos(math.radians(center_lat))
                distance_units = distance_meters / meters_per_degree
                self.log_message(f"Geographic CRS: converting {distance_meters}m to ~{distance_units:.6f}°")
            else:
                distance_units = distance_meters
                meters_per_degree = 1.0
                self.log_message(f"Projected CRS: using {distance_meters}m directly")
            
            # Create output pole layer with PHASE 1 schema
            pole_layer = QgsVectorLayer(f"Point?crs={crs.authid()}", 
                                       f"Poles_{distance_meters}m_{span_type}", 
                                       "memory")
            provider = pole_layer.dataProvider()
            
            # PHASE 1: Enhanced attribute schema
            provider.addAttributes([
                QgsField('pole_id', QMetaType.Type.Int),
                QgsField('span_id', QMetaType.Type.Int),
                QgsField('distance_along', QMetaType.Type.Double),
                QgsField('pole_type', QMetaType.Type.QString),     # start, intermediate, end, kink
                QgsField('pole_role', QMetaType.Type.QString),     # NEW: feeder, distribution, support
                QgsField('pole_height', QMetaType.Type.Double),    # NEW: meters (7.0, 5.4, etc)
                QgsField('pole_thickness', QMetaType.Type.QString),# NEW: "100/120" or "120/140"
                QgsField('installation_notes', QMetaType.Type.QString)  # NEW: SANS 754 specs
            ])
            pole_layer.updateFields()
            
            pole_features = []
            pole_id = 1
            total_poles = 0
            global_placed_coords = set()
            
            # Get Type field index for filtering (if enabled) — use the SAME
            # resolver that populated the dropdown so we filter on the right field.
            type_field_idx = -1
            if type_filter_enabled:
                type_field_idx = _resolve_type_field(span_layer)
                if type_field_idx < 0:
                    self.log_message("WARNING: span type field not found. Filtering disabled.")
                    type_filter_enabled = False
            
            # Process each span segment
            for span_feat in span_layer.getFeatures():
                geom = span_feat.geometry()
                if not geom or geom.isEmpty():
                    continue
                
                # NEW: Apply Type filter
                if type_filter_enabled:
                    feat_type = span_feat[type_field_idx]
                    if str(feat_type) != type_filter_value:
                        continue  # Skip this feature, doesn't match filter
                
                span_id = span_feat.id()
                
                if geom.isMultipart():
                    lines = geom.asMultiPolyline()
                else:
                    lines = [geom.asPolyline()]
                
                for line in lines:
                    if len(line) < 2:
                        continue
                    
                    cumulative = 0.0

                    for i, vertex in enumerate(line):
                        if i == 0:
                            vtype = 'start'
                        elif i == len(line) - 1:
                            vtype = 'end'
                        else:
                            vtype = 'kink'

                        key = _coord_round(vertex.x(), vertex.y())
                        if key not in global_placed_coords:
                            global_placed_coords.add(key)
                            dist_out = cumulative if not is_geographic else cumulative * meters_per_degree
                            
                            # PHASE 1: Assign pole attributes
                            pole_role = span_type if vtype == 'start' else 'distribution'
                            pole_height = self._get_pole_height(pole_role)
                            pole_thickness = self._get_pole_thickness(pole_role, is_corner=(vtype == 'kink'))
                            install_notes = self._get_installation_notes(pole_role, vtype, pole_height, pole_thickness)
                            
                            pole_feat = QgsFeature(pole_layer.fields())
                            pole_feat.setGeometry(QgsGeometry.fromPointXY(vertex))
                            pole_feat.setAttributes([
                                pole_id, span_id, round(dist_out, 2), vtype,
                                pole_role, pole_height, pole_thickness, install_notes
                            ])
                            pole_features.append(pole_feat)
                            pole_id += 1
                            total_poles += 1

                        # Fill segment with intermediate poles
                        if i < len(line) - 1:
                            nv = line[i + 1]
                            dx = nv.x() - vertex.x()
                            dy = nv.y() - vertex.y()
                            seg_len = math.sqrt(dx * dx + dy * dy)

                            if seg_len > distance_units:
                                n_steps = int(seg_len / distance_units)
                                for k in range(1, n_steps + 1):
                                    frac = (k * distance_units) / seg_len
                                    if frac >= 0.999:
                                        break
                                    ix = vertex.x() + frac * dx
                                    iy = vertex.y() + frac * dy
                                    ikey = _coord_round(ix, iy)
                                    if ikey not in global_placed_coords:
                                        global_placed_coords.add(ikey)
                                        int_dist = cumulative + k * distance_units
                                        dist_out = int_dist if not is_geographic else int_dist * meters_per_degree
                                        
                                        # PHASE 1: Intermediate poles
                                        pole_role = 'distribution'
                                        pole_height = self._get_pole_height(pole_role)
                                        pole_thickness = self._get_pole_thickness(pole_role)
                                        install_notes = self._get_installation_notes(pole_role, 'intermediate', pole_height, pole_thickness)
                                        
                                        pole_feat = QgsFeature(pole_layer.fields())
                                        pole_feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(ix, iy)))
                                        pole_feat.setAttributes([
                                            pole_id, span_id, round(dist_out, 2), 'intermediate',
                                            pole_role, pole_height, pole_thickness, install_notes
                                        ])
                                        pole_features.append(pole_feat)
                                        pole_id += 1
                                        total_poles += 1

                            cumulative += seg_len
            
            if len(pole_features) == 0:
                self.log_message("WARNING: No poles were generated. Check span layer geometry.")
                return
            
            # Add features to layer
            provider.addFeatures(pole_features)
            pole_layer.updateExtents()
            
            # Apply symbology
            categories = []
            pole_styles = {
                'start': ('0,200,0', 4.0),        # Bright green
                'intermediate': ('100,149,237', 3.0),  # Cornflower blue
                'kink': ('255,140,0', 4.0),      # Dark orange
                'end': ('220,20,60', 4.0)        # Crimson red
            }
            
            for pole_type, (color, size) in pole_styles.items():
                symbol = QgsMarkerSymbol.createSimple({
                    'name': 'circle',
                    'color': color,
                    'size': str(size),
                    'outline_color': 'black',
                    'outline_width': '0.8'
                })
                category = QgsRendererCategory(pole_type, symbol, pole_type.capitalize())
                categories.append(category)
            
            renderer = _categorized_with_catch_all(pole_layer, 'pole_type', categories)
            pole_layer.setRenderer(renderer)
            
            # Add layer to project
            pole_layer = self._add_output_layer(pole_layer)
            
            # Summary statistics
            feeder_count = sum(1 for f in pole_features if f['pole_role'] == 'feeder')
            distribution_count = sum(1 for f in pole_features if f['pole_role'] == 'distribution')
            start_count = sum(1 for f in pole_features if f['pole_type'] == 'start')
            intermediate_count = sum(1 for f in pole_features if f['pole_type'] == 'intermediate')
            kink_count = sum(1 for f in pole_features if f['pole_type'] == 'kink')
            end_count = sum(1 for f in pole_features if f['pole_type'] == 'end')
            
            self.log_message(f"\n✓ PHASE 1: Generated {total_poles} poles with enhanced attributes")
            self.log_message(f"  Feeder poles: {feeder_count} @ 7.0m")
            self.log_message(f"  Distribution poles: {distribution_count} @ 5.4-7.0m")
            self.log_message(f"  By type: {start_count} start (green) | {intermediate_count} intermediate (blue) | "
                            f"{kink_count} kink (orange) | {end_count} end (red)")
            self.log_message("  All poles: SANS 754 H4 treated with FTTH spec details in attributes")
            self.log_message(f"Layer: '{pole_layer.name()}'")
            self._elapsed("Total time")
        except Exception as e:
            self.log_message(f"ERROR generating poles: {e!s}")
            import traceback
            self.log_message(traceback.format_exc())

    def on_span_evaluate_clicked(self):
        """Snap and merge span lines within a tolerance to form one continuous network.

        Strategy:
          1. For every line endpoint within `snap_radius` of another endpoint (but
             not the same feature) → move both to their midpoint (snap together).
          2. For overlapping / nearly-overlapping lines → dissolve/merge them into
             a single continuous polyline where possible.
          3. All edits are made in-place on the selected span layer.
          4. A full report is shown on completion.
        """
        from qgis.core import (QgsGeometry,
                               QgsPointXY, QgsFeature)
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout,
                                         QFormLayout, QLabel, QPushButton,
                                         QDoubleSpinBox, QCheckBox,
                                         QMessageBox, QTextEdit)
        from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
        from qgis.PyQt.QtGui import QFont

        span_layer = self.comboBox_span_layer.currentLayer()
        if span_layer is None:
            QMessageBox.warning(None, "Span Evaluate & Snap",
                                "Please select a Span (Route) layer first.")
            return
        if span_layer.geometryType() != 1:
            QMessageBox.warning(None, "Span Evaluate & Snap",
                                f"'{span_layer.name()}' is not a line layer.")
            return

        # ── Settings dialog ───────────────────────────────────────────────
        dlg = QDialog(None)
        dlg.setWindowTitle("Span Evaluate & Snap — Settings")
        dlg.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                           Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
        dlg.setMinimumWidth(380)
        lay = QVBoxLayout(dlg)
        lay.setSpacing(10)
        lay.setContentsMargins(18, 18, 18, 18)

        hdr = QLabel("🔗  Span Evaluate & Snap")
        hf = QFont(); hf.setBold(True); hf.setPointSize(10)
        hdr.setFont(hf); hdr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(hdr)

        desc = QLabel(
            "Snaps line endpoints that are within the snap radius to each\n"
            "other, and merges lines that share endpoints into a single\n"
            "continuous network. Edits the layer in-place.")
        desc.setWordWrap(True)
        lay.addWidget(desc)

        form = QFormLayout()
        radius_spin = QDoubleSpinBox()
        radius_spin.setRange(0.1, 100.0)
        radius_spin.setDecimals(1)
        radius_spin.setValue(4.0)
        radius_spin.setSuffix(" m")
        radius_spin.setToolTip("Endpoints within this distance will be snapped together.")
        form.addRow("Snap radius (m):", radius_spin)

        dry_chk = QCheckBox("Dry run — report only, do not modify layer")
        dry_chk.setChecked(False)
        lay.addLayout(form)
        lay.addWidget(dry_chk)

        btn_row = QHBoxLayout()
        run_btn = QPushButton("Run")
        run_btn.setStyleSheet(
            "QPushButton { background-color: #2e4057; color: white; font-weight: bold; "
            "padding: 5px 18px; border-radius: 4px; }"
            "QPushButton:hover { background-color: #3d5270; }")
        cancel_btn = QPushButton("Cancel")
        btn_row.addWidget(run_btn); btn_row.addWidget(cancel_btn)
        lay.addLayout(btn_row)
        run_btn.clicked.connect(dlg.accept)
        cancel_btn.clicked.connect(dlg.reject)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        # Batch B: radius_spin is in METRES; on a geographic CRS the worker compares it
        # against degree coordinates (a 4 m radius = ~440 km → the whole net snaps into
        # one blob). Convert to the span layer's units before handing it to the worker.
        snap_radius_m = radius_spin.value()           # original metres (for honest reporting)
        snap_radius = _m_to_units(snap_radius_m, span_layer)  # CRS units used for snapping
        _span_is_geo = span_layer.crs().isValid() and span_layer.crs().isGeographic()
        dry_run = dry_chk.isChecked()

        # ── Worker ────────────────────────────────────────────────────────
        class _SnapWorker(QThread):
            finished = pyqtSignal(int, int, list, dict)   # snaps, merges, report_lines, backup
            error    = pyqtSignal(str)

            def __init__(self, layer, radius, dry, radius_m=None, is_geo=False):
                super().__init__()
                self._layer    = layer
                self._radius   = radius
                self._radius_m = radius_m if radius_m is not None else radius
                self._is_geo   = is_geo
                self._dry      = dry

            def run(self):
                try:
                    import math
                    layer    = self._layer
                    radius   = self._radius
                    radius_m = self._radius_m
                    is_geo   = self._is_geo
                    dry      = self._dry
                    report = []

                    # ----------------------------------------------------------
                    # STEP 1: Collect all endpoints
                    # endpoint_map: {fake_id: (fid, 'start'|'end', QgsPointXY)}
                    # ----------------------------------------------------------
                    endpoint_map = {}
                    fid_geoms = {}   # fid -> list of vertex QgsPointXY
                    eid = 0
                    for feat in layer.getFeatures():
                        geom = feat.geometry()
                        if not geom or geom.isEmpty():
                            continue
                        if geom.isMultipart():
                            parts = geom.asMultiPolyline()
                        else:
                            parts = [geom.asPolyline()]
                        fid_geoms[feat.id()] = parts
                        for part in parts:
                            if len(part) >= 2:
                                endpoint_map[eid] = (feat.id(), 'start', part[0])
                                eid += 1
                                endpoint_map[eid] = (feat.id(), 'end', part[-1])
                                eid += 1

                    total_endpoints = len(endpoint_map)
                    report.append(f"Layer: {layer.name()}")
                    report.append(f"Features: {layer.featureCount()}")
                    report.append(f"Endpoints collected: {total_endpoints}")
                    if is_geo:
                        report.append(f"Snap radius: {radius_m:.1f} m ({radius:.6f} CRS units)")
                    else:
                        report.append(f"Snap radius: {radius_m:.1f} m")
                    report.append("")

                    if total_endpoints == 0:
                        report.append("No endpoints found — check layer geometry.")
                        self.finished.emit(0, 0, report, {})
                        return

                    # ----------------------------------------------------------
                    # STEP 2: Build spatial index over endpoint points
                    # ----------------------------------------------------------
                    idx = QgsSpatialIndex()
                    for eid2, (fid, role, pt) in endpoint_map.items():
                        f = QgsFeature()
                        f.setId(eid2)
                        f.setGeometry(QgsGeometry.fromPointXY(pt))
                        idx.insertFeature(f)

                    # ----------------------------------------------------------
                    # STEP 2b: Identify eligible (non-terminal) endpoints
                    # An endpoint is eligible for snapping ONLY if the OTHER end
                    # of its own feature is already connected to the network
                    # (i.e., touches another feature within connect_threshold).
                    # This prevents true dead-end branch tips from being snapped.
                    # ----------------------------------------------------------
                    from qgis.core import QgsRectangle
                    connect_threshold = min(0.5, radius / 4.0)

                    # Build fid → {role: eid} lookup
                    fid_to_eids = {}
                    for eid2, (fid2, role2, pt2) in endpoint_map.items():
                        fid_to_eids.setdefault(fid2, {})[role2] = eid2

                    def _is_connected(pt, own_fid):
                        """True if pt touches any endpoint from a different feature."""
                        nearby = idx.intersects(QgsRectangle(
                            pt.x()-connect_threshold, pt.y()-connect_threshold,
                            pt.x()+connect_threshold, pt.y()+connect_threshold))
                        for nid in nearby:
                            nfid, _, npt = endpoint_map[nid]
                            if nfid == own_fid:
                                continue
                            if math.sqrt((pt.x()-npt.x())**2 +
                                         (pt.y()-npt.y())**2) <= connect_threshold:
                                return True
                        return False

                    # An endpoint is eligible if the OTHER end of its feature is connected
                    eligible_eids = set()
                    for fid2, roles in fid_to_eids.items():
                        s_eid = roles.get('start')
                        e_eid = roles.get('end')
                        if s_eid is None or e_eid is None:
                            continue
                        _, _, s_pt = endpoint_map[s_eid]
                        _, _, e_pt = endpoint_map[e_eid]
                        if _is_connected(e_pt, fid2):
                            eligible_eids.add(s_eid)   # start is eligible (end is anchored)
                        if _is_connected(s_pt, fid2):
                            eligible_eids.add(e_eid)   # end is eligible (start is anchored)

                    report.append(f"Eligible (non-terminal) endpoints: {len(eligible_eids)}")

                    # ----------------------------------------------------------
                    # STEP 3: Find dangling endpoints (no neighbour within radius
                    #         from a DIFFERENT feature) — terminals excluded
                    # ----------------------------------------------------------
                    # We'll build a list of snap pairs (each endpoint used once)
                    snap_pairs = []   # [(eid_a, eid_b, midpoint)]
                    used = set()

                    for eid_a, (fid_a, role_a, pt_a) in endpoint_map.items():
                        if eid_a in used:
                            continue
                        # Skip true terminal ends — only snap network-interior gaps
                        if eid_a not in eligible_eids:
                            continue
                        nearby_ids = idx.intersects(QgsRectangle(
                            pt_a.x()-radius, pt_a.y()-radius,
                            pt_a.x()+radius, pt_a.y()+radius))

                        best_dist = radius + 1.0
                        best_eid  = None
                        for eid_b in nearby_ids:
                            if eid_b == eid_a or eid_b in used:
                                continue
                            if eid_b not in eligible_eids:
                                continue   # also skip terminal partner endpoints
                            fid_b, role_b, pt_b = endpoint_map[eid_b]
                            if fid_b == fid_a:
                                continue   # same feature — skip
                            dist = math.sqrt((pt_a.x()-pt_b.x())**2 +
                                             (pt_a.y()-pt_b.y())**2)
                            if dist <= radius and dist < best_dist:
                                best_dist = dist
                                best_eid  = eid_b

                        if best_eid is not None:
                            fid_b, role_b, pt_b = endpoint_map[best_eid]
                            mid = QgsPointXY(
                                (pt_a.x()+pt_b.x())/2.0,
                                (pt_a.y()+pt_b.y())/2.0)
                            snap_pairs.append((eid_a, fid_a, role_a, pt_a,
                                               best_eid, fid_b, role_b, pt_b,
                                               mid, best_dist))
                            used.add(eid_a)
                            used.add(best_eid)

                    report.append(f"Snap pairs found: {len(snap_pairs)}")

                    # How many endpoints are still dangling (no partner found)?
                    paired_eids = used
                    dangling = [eid2 for eid2, (fid2, r2, pt2) in endpoint_map.items()
                                if eid2 not in paired_eids]
                    report.append(f"Still-dangling endpoints after snap: {len(dangling)}")
                    report.append("")

                    if dry or not snap_pairs:
                        for sp in snap_pairs:
                            eid_a2, fid_a2, role_a2, pt_a2, eid_b2, fid_b2, role_b2, pt_b2, mid2, dist2 = sp
                            report.append(
                                f"  SNAP fid={fid_a2}({role_a2}) ↔ fid={fid_b2}({role_b2})  "
                                f"dist={dist2:.3f}m → midpoint({mid2.x():.2f},{mid2.y():.2f})")
                        if not snap_pairs:
                            report.append(
                                f"  No snap pairs found within {radius} m.\n"
                                f"  The network may already be connected, or try increasing the radius.")
                        self.finished.emit(0, 0, report, {})
                        return

                    # ----------------------------------------------------------
                    # BACKUP: Capture all geometries before any edits
                    # ----------------------------------------------------------
                    backup_geoms = {}
                    backup_full = []   # [(wkt_or_None, [attr values])] — faithful,
                                       # MERGE-PROOF rebuild (FIDs change after dissolve)
                    for feat in layer.getFeatures():
                        g = feat.geometry()
                        _wkt = g.asWkt() if g and not g.isEmpty() else None
                        backup_geoms[feat.id()] = _wkt
                        backup_full.append((_wkt, list(feat.attributes())))
                    backup = {
                        'layer_id':   layer.id(),
                        'layer_name': layer.name(),
                        'features':   backup_geoms,
                        'full':       backup_full,
                    }

                    # ----------------------------------------------------------
                    # STEP 4: Apply snaps — move endpoints to midpoints
                    # Build a dict of {fid: {'start': new_pt, 'end': new_pt}}
                    # ----------------------------------------------------------
                    snap_updates = {}   # fid -> {role: new QgsPointXY}
                    for sp in snap_pairs:
                        eid_a2, fid_a2, role_a2, pt_a2, eid_b2, fid_b2, role_b2, pt_b2, mid2, dist2 = sp
                        snap_updates.setdefault(fid_a2, {})[role_a2] = mid2
                        snap_updates.setdefault(fid_b2, {})[role_b2] = mid2

                    layer.startEditing()
                    snaps_applied = 0
                    for fid_edit, roles in snap_updates.items():
                        feat = layer.getFeature(fid_edit)
                        geom = feat.geometry()
                        if not geom or geom.isEmpty():
                            continue
                        if geom.isMultipart():
                            parts = geom.asMultiPolyline()
                            changed = False
                            new_parts = []
                            for part in parts:
                                if len(part) < 2:
                                    new_parts.append(part)
                                    continue
                                pl = list(part)
                                if 'start' in roles:
                                    pl[0] = roles['start']
                                    changed = True
                                if 'end' in roles:
                                    pl[-1] = roles['end']
                                    changed = True
                                new_parts.append(pl)
                            if changed:
                                new_geom = QgsGeometry.fromMultiPolylineXY(new_parts)
                                layer.changeGeometry(fid_edit, new_geom)
                                snaps_applied += 1
                        else:
                            pts = list(geom.asPolyline())
                            if len(pts) < 2:
                                continue
                            changed = False
                            if 'start' in roles:
                                pts[0] = roles['start']
                                changed = True
                            if 'end' in roles:
                                pts[-1] = roles['end']
                                changed = True
                            if changed:
                                new_geom = QgsGeometry.fromPolylineXY(pts)
                                layer.changeGeometry(fid_edit, new_geom)
                                snaps_applied += 1

                    _safe_commit(layer)
                    layer.triggerRepaint()

                    report.append(f"✅ Snaps applied: {snaps_applied} feature(s) updated.")
                    report.append("")

                    # ----------------------------------------------------------
                    # STEP 5: Merge connected lines using QGIS dissolve
                    # After snapping, features whose endpoints now touch can be
                    # dissolved into single polylines using the processing framework
                    # ----------------------------------------------------------
                    merges = 0
                    try:
                        import processing
                        result = processing.run("native:dissolve", {
                            'INPUT': layer,
                            'FIELD': [],
                            'SEPARATE_DISJOINT': False,
                            'OUTPUT': 'TEMPORARY_OUTPUT'
                        })
                        merged_layer = result['OUTPUT']
                        orig_count = layer.featureCount()
                        merged_count = merged_layer.featureCount()
                        merges = orig_count - merged_count

                        if merges > 0:
                            report.append(
                                f"🔗 Merge: {orig_count} lines → {merged_count} "
                                f"(reduced by {merges})")
                            # Replace features with the merged result — Batch C:
                            # ADD-verify-THEN-delete. The old order (delete-all then
                            # provider add with the return ignored) WIPED the layer if
                            # the add failed on a disk-backed/schema-mismatched span
                            # layer. Now we add first, confirm it landed, and only then
                            # remove the originals; on failure we roll back and keep
                            # the data intact (recoverable via Restore Span Backup too).
                            _prov = layer.dataProvider()
                            _old_ids = layer.allFeatureIds()
                            merged_feats = [f for f in merged_layer.getFeatures()]
                            _before = layer.featureCount()
                            _res = _prov.addFeatures(merged_feats)
                            _ok = _res[0] if isinstance(_res, tuple) else bool(_res)
                            _added = _res[1] if (isinstance(_res, tuple) and len(_res) > 1) else []
                            if not _ok or layer.featureCount() <= _before:
                                try:
                                    if _added:
                                        _prov.deleteFeatures([f.id() for f in _added])
                                except Exception:
                                    _swallowed_note()
                                report.append("⚠ Merge write FAILED — layer left INTACT (nothing deleted).")
                            else:
                                _prov.deleteFeatures(_old_ids)
                                layer.triggerRepaint()
                                report.append("✅ Merged features written back to layer.")
                        else:
                            report.append(
                                "ℹ️  No further line merges possible after snapping.")
                    except Exception as me:
                        report.append(f"ℹ️  Merge step skipped: {me}")

                    report.append("")
                    report.append("Done. Reload the layer in QGIS if display looks stale.")
                    self.finished.emit(snaps_applied, merges, report, backup)

                except Exception as exc:
                    import traceback
                    self.error.emit(str(exc) + "\n" + traceback.format_exc())

        # ── Wait dialog ───────────────────────────────────────────────────
        wait_dlg = QDialog(None)
        wait_dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        wait_dlg.setWindowTitle("Span Evaluate — Running…")
        wait_dlg.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint | Qt.WindowType.CustomizeWindowHint)
        wait_dlg.setFixedWidth(340)
        wl = QVBoxLayout(wait_dlg)
        wl.addWidget(QLabel(
            f"<b>Evaluating span layer…</b><br>"
            f"Layer: <i>{span_layer.name()}</i><br>"
            f"Snap radius: {snap_radius_m:.1f} m"))
        wait_dlg.show()
        QApplication.processEvents()

        def _show_result(snaps, merges, report, backup):
            wait_dlg.close()
            # Store backup on widget so the restore button can use it
            if backup and snaps > 0:
                self._span_snap_backup = backup
                self.pushButton_restore_span_backup.setEnabled(True)
                self.pushButton_restore_span_backup.setToolTip(
                    f"Restore '{backup.get('layer_name', '')}' to its state before the last snap "
                    f"({len(backup.get('features', {}))} features backed up)")
            res_dlg = QDialog(None)
            res_dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
            title = ("Span Evaluate — Dry Run" if dry_run else
                     f"Span Evaluate — {snaps} snap(s), {merges} merge(s)")
            res_dlg.setWindowTitle(title)
            res_dlg.setWindowFlags(
                Qt.WindowType.Dialog | Qt.WindowType.WindowTitleHint |
                Qt.WindowType.WindowCloseButtonHint | Qt.WindowType.CustomizeWindowHint)
            res_dlg.setMinimumWidth(500)
            res_dlg.setMinimumHeight(360)
            r_lay = QVBoxLayout(res_dlg)
            r_lay.setContentsMargins(18, 18, 18, 18)

            hdr2 = QLabel(f"🔗  {title}")
            hf2 = QFont(); hf2.setBold(True); hf2.setPointSize(10)
            hdr2.setFont(hf2); hdr2.setAlignment(Qt.AlignmentFlag.AlignCenter)
            r_lay.addWidget(hdr2)

            if backup and snaps > 0:
                note = QLabel("💾  A backup of the original layer was saved.\n"
                              "    Use '↩ Restore Span Backup' to undo these changes.")
                note.setStyleSheet(f'color:{theme_safe.colors()["muted"]};font-style:italic;')
                r_lay.addWidget(note)

            txt = QTextEdit()
            txt.setReadOnly(True)
            txt.setPlainText("\n".join(report))
            txt.setStyleSheet("font-family: monospace; font-size: 9pt;")
            r_lay.addWidget(txt)

            close_btn = QPushButton("Close")
            close_btn.setStyleSheet(
                "QPushButton { background-color: #2e4057; color: white; "
                "font-weight: bold; padding: 5px 20px; border-radius: 4px; }"
                "QPushButton:hover { background-color: #3d5270; }")
            close_btn.clicked.connect(res_dlg.accept)
            r_lay.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignCenter)
            res_dlg.exec()

        def _show_error(msg):
            wait_dlg.close()
            QMessageBox.critical(None, "Span Evaluate Error",
                                 f"An error occurred:\n{msg}")

        worker = _SnapWorker(span_layer, snap_radius, dry_run,
                             radius_m=snap_radius_m, is_geo=_span_is_geo)
        worker.finished.connect(_show_result)
        worker.error.connect(_show_error)
        self._snap_worker = worker
        # Run SYNCHRONOUSLY on the main thread (run(), not start()): this op reads
        # getFeatures(), edits the layer (startEditing/changeGeometry/commitChanges)
        # and calls processing.run() — none of which are thread-safe off the GUI
        # thread (intermittent crash / edit-buffer corruption). The brief UI block is
        # behind the "Running…" dialog; finished/error fire to the same-thread
        # callbacks exactly as before, so behaviour is identical. (A future
        # responsiveness upgrade = split compute-plan/apply; not needed for safety.)
        worker.run()

    def on_create_enclosure_clicked(self):
        """Open enclosure type chooser, then let user click map to place enclosure point."""
        from qgis.PyQt.QtWidgets import (QDialog, QVBoxLayout, QLabel,
                                          QPushButton)
        from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsField, QgsProject, QgsMarkerSymbol, QgsSingleSymbolRenderer,
                                QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                                QgsVectorLayerSimpleLabeling)
        from qgis.PyQt.QtCore import QMetaType
        from qgis.PyQt.QtGui import QColor, QFont

        # If button is unchecked, cancel any active placement
        if not self._btn_create_enclosure.isChecked():
            if self._create_enclosure_tool:
                self.iface.mapCanvas().unsetMapTool(self._create_enclosure_tool)
                self._create_enclosure_tool = None
            self._create_enclosure_type = None
            self.log_message("Create Enclosure: placement cancelled.")
            return

        # ── Step 1: Ask user what type of enclosure ──────────────────────────
        dlg = QDialog(self.iface.mainWindow())
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)   # don't leak hidden windows
        dlg.setWindowTitle("Create Enclosure — Select Type")
        dlg.setMinimumWidth(320)
        layout = QVBoxLayout(dlg)

        lbl = QLabel("Select the enclosure type to place on the map:")
        lbl.setWordWrap(True)
        layout.addWidget(lbl)

        btn_fs = QPushButton("📦  Feeder Splice  (FS)")
        btn_fs.setStyleSheet(
            "QPushButton { background-color: #1a5276; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #2471a3; }"
        )
        btn_fts = QPushButton("📦  First Tier Splitter Splice  (FTS)")
        btn_fts.setStyleSheet(
            "QPushButton { background-color: #145a32; color: white; font-weight: bold; "
            "padding: 10px; border-radius: 4px; font-size: 10pt; }"
            "QPushButton:hover { background-color: #1e8449; }"
        )
        btn_cancel = QPushButton("Cancel")

        layout.addWidget(btn_fs)
        layout.addWidget(btn_fts)
        layout.addSpacing(6)
        layout.addWidget(btn_cancel)

        chosen_type = [None]

        def _pick(enc_type):
            chosen_type[0] = enc_type
            dlg.accept()

        btn_fs.clicked.connect(lambda: _pick('FS'))
        btn_fts.clicked.connect(lambda: _pick('FTS'))
        btn_cancel.clicked.connect(dlg.reject)

        if dlg.exec() != QDialog.DialogCode.Accepted or not chosen_type[0]:
            self._btn_create_enclosure.setChecked(False)
            return

        enc_type = chosen_type[0]
        self._create_enclosure_type = enc_type
        self.log_message(f"Create Enclosure: type={enc_type} — click on the map to place. Right-click to finish.")

        # ── Step 2: Activate map click tool ──────────────────────────────────
        canvas = self.iface.mapCanvas()
        crs = canvas.mapSettings().destinationCrs().authid()
        layer_name = f"Manual Enclosures ({enc_type})"

        # Get or create the enclosure layer for this type
        enc_layer = None
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == layer_name:
                enc_layer = lyr
                break

        if enc_layer is None:
            color = '30,82,172,255' if enc_type == 'FS' else '21,128,50,255'
            enc_layer = QgsVectorLayer(f"Point?crs={crs}", layer_name, "memory")
            provider = enc_layer.dataProvider()
            provider.addAttributes([
                QgsField('enclosure_id', QMetaType.Type.Int),
                QgsField('enclosure_name', QMetaType.Type.QString),
                QgsField('enclosure_type', QMetaType.Type.QString),
            ])
            enc_layer.updateFields()

            symbol = QgsMarkerSymbol.createSimple({
                'name': 'square',
                'color': color,
                'outline_color': '255,255,255,255',
                'outline_width': '0.6',
                'size': '7',
            })
            enc_layer.setRenderer(QgsSingleSymbolRenderer(symbol))

            # Labels
            lbl_s = QgsPalLayerSettings()
            lbl_s.fieldName = 'enclosure_name'
            lbl_s.enabled = True
            fmt = QgsTextFormat()
            fmt.setFont(QFont("Arial", 7))
            fmt.setColor(QColor(255, 255, 255))
            buf = QgsTextBufferSettings()
            buf.setEnabled(True)
            buf.setSize(1.0)
            buf.setColor(QColor(0, 0, 0))
            fmt.setBuffer(buf)
            lbl_s.setFormat(fmt)
            enc_layer.setLabeling(QgsVectorLayerSimpleLabeling(lbl_s))
            enc_layer.setLabelsEnabled(True)

            QgsProject.instance().addMapLayer(enc_layer)
            self.log_message(f"  Created new layer: '{layer_name}'")

        # Track next ID for this layer
        existing_ids = [f['enclosure_id'] for f in enc_layer.getFeatures() if f['enclosure_id']]
        next_id = [max(existing_ids) + 1 if existing_ids else 1]

        # ── Snap-to-cable placement tool (JJ, live request): the enclosure must land
        # ON the cable, not floating beside it. As the cursor moves we snap to the
        # nearest cable (feeder / distribution / span — never roads/boundaries) and show
        # a live marker; the click places the enclosure exactly on that snapped point.
        from qgis.gui import QgsMapTool as _EncMapTool, QgsVertexMarker
        from qgis.core import (QgsSpatialIndex, QgsCoordinateTransform,
                               QgsPointXY as _EncPXY, QgsVectorLayer as _EncVL)

        _enc_root = QgsProject.instance().layerTreeRoot()

        def _is_cable_lyr(_l):
            try:
                if not isinstance(_l, _EncVL) or _l.geometryType() != 1:  # 1 = line
                    return False
                if _l.featureCount() == 0:
                    return False
            except Exception:
                return False
            _n = _l.name().lower()
            # Backbone cables only — NEVER snap enclosures to drops, scratch/temp/sandbox
            # layers, roads, boundaries or non-cable layers.
            if any(_k in _n for _k in
                   ('road', 'erven', 'erf', 'zone', 'boundary', 'aoi', 'pon ', 'demand',
                    'drop', 'spare', 'temp', 'exp_', 'core', 'ont', 'splitter', 'pole')):
                return False
            if not any(_k in _n for _k in
                       ('feeder', 'distribution', 'primary', 'secondary', 'span',
                        'spur', 'link', 'cable', 'adss', 'blown', 'mini',
                        '144f', '48f', '24f', '12f')):
                return False
            # Only snap to cables the user can actually SEE (checked in the layer tree),
            # so the enclosure lands on a visible line, not a hidden sandbox duplicate.
            try:
                _node = _enc_root.findLayer(_l.id())
                if _node is not None and not _node.itemVisibilityChecked():
                    return False
            except Exception:
                pass
            return True

        _cable_layers = [l for l in QgsProject.instance().mapLayers().values() if _is_cable_lyr(l)]
        _enc_canvas_crs = canvas.mapSettings().destinationCrs()
        self.log_message(f"  Snapping enclosures to {len(_cable_layers)} cable layer(s): "
                         f"{', '.join(l.name() for l in _cable_layers) or '(none found)'}")

        def _do_place(_pt):
            # claude:intent MUTATE — user asked (live): enclosure "just needs to snap on
            # the cables". Plan: place the manual enclosure on the snapped-to-cable point.
            # claude:approved-destructive — adds one point to the manual-enclosures memory
            # layer (the same write the original tool performed, now snapped).
            if sip.isdeleted(enc_layer):
                return
            feat = QgsFeature(enc_layer.fields())
            feat.setGeometry(QgsGeometry.fromPointXY(_EncPXY(_pt.x(), _pt.y())))
            enc_name = f"{enc_type}_{next_id[0]:03d}"
            feat.setAttributes([next_id[0], enc_name, enc_type])
            enc_layer.dataProvider().addFeatures([feat])
            enc_layer.updateExtents()
            enc_layer.triggerRepaint()
            self.log_message(f"  Placed: {enc_name} at ({_pt.x():.5f}, {_pt.y():.5f}) [snapped to cable]")
            next_id[0] += 1

        def _finish_placement():
            try:
                canvas.unsetMapTool(self._create_enclosure_tool)
            except Exception:
                pass
            self._btn_create_enclosure.setChecked(False)
            self._create_enclosure_tool = None
            self.log_message(f"Create Enclosure: placement finished. {next_id[0]-1} enclosure(s) placed.")
            if not sip.isdeleted(enc_layer):
                enc_layer.triggerRepaint()

        class _EncSnapTool(_EncMapTool):
            def __init__(self, cvs):
                super().__init__(cvs)
                self._cvs = cvs
                self._proj = QgsProject.instance()
                # We do NOT change the project/canvas snapping config. Instead _snap()
                # reads the global "Enable Snapping (S)" flag and only snaps when it is
                # ON — so the S button is a true whole-plugin on/off. When ON we snap via
                # the native engine (your targets) and, failing that, to the nearest
                # backbone cable so an enclosure still lands on a cable.
                # Geometric fallback index so it snaps to a cable even past the native radius.
                self._idx = []
                for _l in _cable_layers:
                    try:
                        _xf = QgsCoordinateTransform(_enc_canvas_crs, _l.crs(), QgsProject.instance())
                        _bxf = QgsCoordinateTransform(_l.crs(), _enc_canvas_crs, QgsProject.instance())
                        self._idx.append((_l, QgsSpatialIndex(_l.getFeatures()), _xf, _bxf))
                    except Exception:
                        pass
                self._mk = QgsVertexMarker(cvs)
                self._mk.setColor(QColor(255, 60, 0))
                self._mk.setIconType(QgsVertexMarker.ICON_CIRCLE)
                self._mk.setPenWidth(3)
                self._mk.setIconSize(16)
                self._mk.hide()
                self._snapped = None

            def _native_snap(self, map_pt):
                try:
                    _m = self._cvs.snappingUtils().snapToMap(map_pt)
                    if _m.isValid():
                        _p = _m.point()
                        return _EncPXY(_p.x(), _p.y())
                except Exception:
                    pass
                return None

            def _geom_snap(self, map_pt):
                best_pt, best_d = None, float('inf')
                for _l, _ix, _xf, _bxf in self._idx:
                    try:
                        _lp = _xf.transform(map_pt)
                    except Exception:
                        _lp = map_pt
                    try:
                        _near = _ix.nearestNeighbor(_lp, 3)
                    except Exception:
                        _near = []
                    for _fid in _near:
                        try:
                            _g = _l.getFeature(_fid).geometry()
                        except Exception:
                            continue
                        if not _g or _g.isEmpty():
                            continue
                        try:
                            _res = _g.closestSegmentWithContext(_lp)
                            _sq, _cp = _res[0], _res[1]
                        except Exception:
                            continue
                        if _sq < best_d:
                            best_d = _sq
                            try:
                                best_pt = _bxf.transform(_EncPXY(_cp))
                            except Exception:
                                best_pt = _EncPXY(_cp)
                return best_pt

            def _snap(self, map_pt):
                # Respect the global Enable Snapping (S) toggle: snapping OFF → no snap
                # anywhere (raw placement). Snapping ON → native engine first, then the
                # geometric nearest backbone cable so the enclosure still lands on a cable.
                try:
                    if not self._proj.snappingConfig().enabled():
                        return None
                except Exception:
                    pass
                return self._native_snap(map_pt) or self._geom_snap(map_pt)

            def canvasMoveEvent(self, e):
                # #100 (#65 class): bail if the layer OR the marker was torn down (a
                # reload while the tool is active still delivers canvas events to a dead
                # tool) — touching a deleted C/C++ object would crash.
                try:
                    if sip.isdeleted(enc_layer) or sip.isdeleted(self._mk):
                        return
                except Exception:
                    return
                _mp = self.toMapCoordinates(e.pos())
                _pt = self._snap(_mp)
                try:
                    if _pt is not None:
                        self._snapped = _pt
                        self._mk.setCenter(_pt)
                        self._mk.show()
                    else:
                        self._snapped = None
                        self._mk.hide()
                except RuntimeError:
                    pass

            def canvasReleaseEvent(self, e):
                from qgis.PyQt.QtCore import Qt as _Qt
                if sip.isdeleted(enc_layer):
                    _finish_placement()
                    return
                if e.button() == _Qt.MouseButton.RightButton:   # Qt6: fully-scoped enum (#110)
                    _finish_placement()
                    return
                _mp = self.toMapCoordinates(e.pos())
                _place_pt = self._snapped if self._snapped is not None else (self._snap(_mp) or _mp)
                _do_place(_place_pt)

            def deactivate(self):
                try:
                    self._mk.hide()
                    self._cvs.scene().removeItem(self._mk)
                except Exception:
                    pass
                super().deactivate()

        map_tool = _EncSnapTool(canvas)
        self._create_enclosure_tool = map_tool
        canvas.setMapTool(map_tool)
        self.log_message("  With Enable Snapping (S) ON, move over a cable — the enclosure "
                         "snaps onto it (red marker). With snapping OFF it places at the "
                         "click. Click to place, right-click when done.")

    def on_autonet_clicked(self, _zone_offset=0, _group_offset=0, _batch_label=None):
        """AutoNet: auto-detect layers and run the full PON pipeline in one click.
        Steps: 1. PONs  2. Demand Points  3. PON Boundaries
               4. Splitter Points  5. Drops PTP
        Shows a floating progress dialog with scrolling log and elapsed timer.

        _zone_offset / _group_offset / _batch_label — forwarded to Step 1 so that
        PON-per-PON runs produce globally sequential zone and group IDs.
        """
        from qgis.core import QgsProject, QgsVectorLayer

        # ── Create and show progress dialog ───────────────────────────
        dlg = AutoNetProgressDialog(self)
        dlg.show()
        QApplication.processEvents()

        # Helper: write to BOTH the dock log AND the popup dialog
        def _log(msg):
            self.log_message(msg)
            dlg.append_log(msg)

        def _autonet_progress(step, label):
            pct = int((step - 1) / 5 * 100)
            self._prog_bar.setValue(pct)
            self._prog_op_lbl.setText(f"AutoNet {step}/5: {label}")
            self._prog_strip.setVisible(True)
            dlg.set_step(step, f"Step {step}/5 — {label}")
            QApplication.processEvents()

        _log("\n══════════════════════════════════════════")
        _log("  ⚡ AutoNet — Full Pipeline Started")
        _log("══════════════════════════════════════════")
        self._prog_strip.setVisible(True)
        self._prog_bar.setValue(0)
        self._prog_op_lbl.setText("AutoNet — detecting layers…")
        dlg.set_step(0, "Detecting layers…")
        QApplication.processEvents()

        # ── Layer auto-detection ───────────────────────────────────────
        _excl_fragments = (
            'groups of', 'group of', 'demand points -', 'splitter point',
            'drop cable', 'drop_cable', 'pon zone', 'pon boundary',
            'zone boundary', 'group boundary', 'aggregation point',
            'feeder route', 'poles_', 'autonet', 'shortest', 'routing',
        )
        _generic_exact = {'aoi', 'extent', 'bbox', 'boundary', 'mask',
                          'study area', 'project area', 'area of interest',
                          'shortest path', 'shortest_path', 'routing result'}

        def _is_output_layer(name_lower):
            if name_lower in _generic_exact:
                return True
            return any(frag in name_lower for frag in _excl_fragments)

        def _find_layer(keywords, geom_type=None):
            for lyr in QgsProject.instance().mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                if geom_type is not None and lyr.geometryType() != geom_type:
                    continue
                ln = lyr.name().lower()
                if _is_output_layer(ln):
                    continue
                if any(kw in ln for kw in keywords):
                    return lyr
            return None

        def _resolve_layer(combo, keywords, geom_type=None, fallback_geom=None):
            current = combo.currentLayer()
            # #5: in a PON-per-PON BATCH, trust the combo verbatim — the batch pipeline
            # deliberately set it to the polygon-filtered tmp copy (named like the
            # original). The _is_output_layer name check below could otherwise reject
            # that copy (e.g. an original named 'Demand Points - MOA' matches the
            # 'demand points -' fragment) and keyword-hunt a DIFFERENT full-project
            # layer — clustering the ENTIRE project instead of the selection.
            if _batch_label is not None and current and isinstance(current, QgsVectorLayer):
                return current
            if current and isinstance(current, QgsVectorLayer):
                if not _is_output_layer(current.name().lower()):
                    return current
            lyr = _find_layer(keywords, geom_type)
            if not lyr and fallback_geom is not None:
                lyr = _find_layer(keywords, fallback_geom)
            if not lyr:
                lyr = _find_layer(keywords)
            return lyr

        demand_kw = ('erf', 'parcel', 'stand', 'plot', 'property', 'premise',
                     'demand', 'subscriber', 'home', 'household')
        demand_lyr = _resolve_layer(self.comboBox_erf, demand_kw,
                                    geom_type=2, fallback_geom=0)

        span_kw = ('span', 'route', 'fibre', 'fiber', 'cable', 'duct',
                   'network', 'trunk', 'backbone')
        span_lyr = _resolve_layer(self.comboBox_span_layer, span_kw, geom_type=1)

        road_kw = ('road', 'street', 'highway', 'lane', 'avenue')
        road_lyr = _resolve_layer(self.comboBox_road_layer, road_kw, geom_type=1)

        # ── Validate ──────────────────────────────────────────────────
        if not demand_lyr:
            _log("ERROR: AutoNet could not identify a demand/parcel layer.")
            _log("  Please set the Demand Layer combo manually and retry.")
            self._prog_strip.setVisible(False)
            dlg.mark_error("No demand layer found")
            return
        if not span_lyr:
            _log("ERROR: AutoNet could not identify a span/route layer.")
            _log("  Please set the Route Layer combo manually and retry.")
            self._prog_strip.setVisible(False)
            dlg.mark_error("No span/route layer found")
            return
        if not road_lyr:
            _log("WARNING: No road layer found — road-crossing rule will be skipped.")

        # ── Apply combos ──────────────────────────────────────────────
        self.comboBox_erf.setLayer(demand_lyr)
        self.comboBox_span_layer.setLayer(span_lyr)
        if road_lyr:
            self.comboBox_road_layer.setLayer(road_lyr)

        for i in range(self.comboBox_clustering_method.count()):
            if 'tight' in self.comboBox_clustering_method.itemText(i).lower():
                self.comboBox_clustering_method.setCurrentIndex(i)
                break

        _log(f"  Demand layer : {demand_lyr.name()}")
        _log(f"  Route layer  : {span_lyr.name()}")
        _log(f"  Road layer   : {road_lyr.name() if road_lyr else '(none)'}")
        _log(f"  Method       : {self.comboBox_clustering_method.currentText()}")
        QApplication.processEvents()

        # INPUT GUARD: catch the "wrong layer" footgun BEFORE grouping. A run whose
        # Demand, Route and Road all point at the same layer — or a Route that isn't
        # lines, or a Demand that isn't points/erven — snaps splitters to the wrong
        # geometry (they float among poles, disconnected from homes). Fail LOUD with a
        # fix hint instead of silently building garbage. Correct runs (points demand +
        # line route, distinct layers) pass untouched.
        _gt_name = {0: 'points', 1: 'lines', 2: 'polygons'}
        _problems = []
        try:
            if demand_lyr.geometryType() not in (0, 2):
                _problems.append(
                    f"Demand layer '{demand_lyr.name()}' is {_gt_name.get(demand_lyr.geometryType(), '?')}, "
                    f"not homes/erven — pick the ONT/home points (or erven polygons).")
            if span_lyr.geometryType() != 1:
                _problems.append(
                    f"Route layer '{span_lyr.name()}' is {_gt_name.get(span_lyr.geometryType(), '?')}, "
                    f"not lines — splitters snap to it, so it must be the Distribution cable.")
            if span_lyr.id() == demand_lyr.id():
                _problems.append("Demand and Route are the SAME layer.")
            if road_lyr is not None and road_lyr.id() in (demand_lyr.id(), span_lyr.id()):
                _problems.append("Road is the same layer as Demand or Route.")
        except Exception:
            pass
        if _problems:
            _log("⛔ AutoNet aborted — the layer selection looks wrong:")
            for _p in _problems:
                _log("   • " + _p)
            _log("   Fix: Demand = homes/ONTs (points), Route = Distribution cable (lines), "
                 "Road = roads (lines) — three DIFFERENT layers. Then retry.")
            self._prog_strip.setVisible(False)
            dlg.mark_error("Bad layer selection — see log")
            return

        # Store batch label so steps 4 & 5 can name their output layers accordingly
        self._current_batch_label = _batch_label

        # ── Steps 1-5 — each guarded + timed, then a run report ───────────
        # Pass 2: every step runs through _run_step so (a) a raised error aborts
        # cleanly instead of propagating uncaught and leaving this dialog hanging (the
        # generation handlers self-catch, but a crash used to escape here), (b) each
        # step is timed, and (c) its output layer + count are recorded for the report.
        # The pipeline, its order and its handlers are UNCHANGED — only the progress
        # surface and failure handling around them. Step 1 keeps the existing HARD
        # fail-fast (#4: no grouped layer → abort so 2-5 don't build on stale layers);
        # steps 2-5 warn + continue so a legitimately light step never false-aborts.
        import time as _an_time
        from qgis.PyQt import sip as _an_sip
        _report = []
        _an_t0 = _an_time.time()

        def _run_step(n, label, fn, output_getter, hard=False):
            _autonet_progress(n, label)
            _log(f"\n── Step {n}/5: {label} ──")
            _s0 = _an_time.time()
            try:
                fn()
            except Exception as _se:
                _log(f"⛔ Step {n} crashed: {_se} — pipeline stopped.")
                self._prog_strip.setVisible(False)
                dlg.mark_error(f"Step {n} crashed")
                return False
            QApplication.processEvents()
            try:
                _out = output_getter()
            except Exception:
                _out = None
            _alive = _out is not None and not _an_sip.isdeleted(_out)
            _name = _out.name() if _alive else None
            _cnt = _out.featureCount() if _alive else None
            _report.append({"step": n, "label": label, "layer": _name,
                            "count": _cnt, "seconds": _an_time.time() - _s0,
                            "ok": bool(_name)})
            if not _name:
                if hard:
                    _log(f"⛔ AutoNet aborted: Step {n} produced no PONs — check the "
                         "demand selection. Later steps skipped (nothing to build on).")
                    self._prog_strip.setVisible(False)
                    dlg.mark_error(f"Step {n} produced no output")
                    return False
                _log(f"⚠ Step {n} produced no detectable output layer — continuing.")
            return True

        if not _run_step(
                1, "Generate PONs",
                lambda: self.on_cluster_erven_clicked(
                    _zone_offset=_zone_offset, _group_offset=_group_offset,
                    _batch_label=_batch_label),
                lambda: getattr(self, 'grouped_layer', None), hard=True):
            return
        if not _run_step(2, "Generate Demand Points",
                         self.on_generate_demand_points_clicked,
                         lambda: getattr(self, 'demand_points_layer', None)):
            return
        if not _run_step(3, "Generate PON Boundaries",
                         self.on_generate_boundaries_clicked,
                         lambda: getattr(self, 'zone_boundaries_layer', None)):
            return
        if not _run_step(4, "Generate Splitter Points",
                         self.on_generate_splitters_clicked,
                         lambda: getattr(self, 'splitter_points_layer', None)):
            return
        if not _run_step(5, "Generate Drops PTP",
                         self.on_generate_drop_ptp_clicked,
                         lambda: getattr(self, 'drop_ptp_layer', None)):
            return

        # ── Done ─────────────────────────────────────────────────────
        self._prog_bar.setValue(100)
        self._prog_op_lbl.setText("⚡ AutoNet Complete ✓")
        from qgis.PyQt.QtCore import QTimer as _QT2
        _gen = self._strip_gen
        _QT2.singleShot(4000, lambda: self._hide_prog_strip(_gen))
        _log("")
        # Pass 2: the run report — what each step built + how long it took.
        try:
            from .autonet_ux import format_run_report
        except ImportError:
            from autonet_ux import format_run_report
        try:
            for _ln in format_run_report(_report, total_seconds=_an_time.time() - _an_t0):
                _log(_ln)
        except Exception as _rep_e:
            _log(f"  (run report skipped: {_rep_e})")
        _log("══════════════════════════════════════════")
        _log("  ⚡ AutoNet — Pipeline Complete ✓")
        _log("══════════════════════════════════════════")
        dlg.mark_complete(success=True)
