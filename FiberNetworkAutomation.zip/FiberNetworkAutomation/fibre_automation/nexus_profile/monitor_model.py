"""monitor_model — the Team Monitor's data logic, with NO Qt in it.

Everything here is a pure function of rows fetched from the backend. It lives
apart from team_monitor.py so the panel's counting rules can be unit-tested
without constructing a QDockWidget — building real Qt widgets under the dev venv
mixes PyQt5 against QGIS's Qt6 and can hang the test run behind a hidden modal.

The rule these functions exist to enforce:

    every number the panel shows is len() of the very list it renders.

The panel used to derive its counters and its lists separately — the KPI strip
from one query, each tab from another — so they were free to tell different
stories, and did: a card reading "40 open errors" above a list showing something
else entirely. Compute the row list ONCE here, render exactly that, and count it
with len(). Then the two cannot drift apart, because there is only one of them.
"""
import time

from . import config


def age(iso):
    """Human 'x min ago' from an ISO timestamp; '?' if unparseable."""
    try:
        import datetime
        dt = datetime.datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
        secs = time.time() - dt.timestamp()
        if secs < 90:
            return "just now"
        if secs < 3600:
            return f"{int(secs // 60)} min ago"
        if secs < 86400:
            return f"{int(secs // 3600)} h ago"
        return f"{int(secs // 86400)} d ago"
    except Exception:
        return "?"


def is_online(iso):
    """True if this heartbeat lands inside the online window."""
    try:
        import datetime
        dt = datetime.datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
        return (time.time() - dt.timestamp()) < config.ONLINE_WINDOW_S
    except Exception:
        return False


class Fetch:
    """The outcome of ONE admin query: the rows, and whether it actually worked.

    ``ok=False`` (the request failed) is NOT the same as "there are no rows",
    and the panel must never draw them the same way. backend.admin_get calls
    back ``None`` on any network error, and the old ``rows = rows or []``
    flattened that into an empty list — so an offline monitor rendered
    "0 open errors" and "No errors reported"; being unable to ask looked
    exactly like good news.
    """

    __slots__ = ("ok", "reason", "rows")

    DEFAULT_REASON = ("Could not reach the team database — showing nothing "
                      "rather than guessing. Check your connection.")

    def __init__(self, rows=(), ok=True, reason=""):
        self.rows = list(rows or [])
        self.ok = bool(ok)
        self.reason = reason

    @classmethod
    def of(cls, rows, reason=None):
        """Wrap a raw admin callback payload: a list, or None when it failed."""
        if rows is None:
            return cls([], ok=False, reason=reason or cls.DEFAULT_REASON)
        return cls(rows, ok=True)

    def replace(self, rows):
        """Same outcome, different row list (after grouping/filtering)."""
        return Fetch(rows, self.ok, self.reason)

    def __repr__(self):
        return (f"Fetch(rows={len(self.rows)}, ok={self.ok}, "
                f"reason={self.reason!r})")


# ── row builders — each returns EXACTLY the list its table renders ───────────

def group_errors(rows):
    """Collapse identical messages into one row each, preserving input order.

    Every input row lands in exactly one group, so the group sizes always sum
    back to len(rows) — the "×N" column can never over- or under-count.
    """
    groups = {}
    for r in rows:
        key = (r.get("error_message") or "")[:160]
        g = groups.get(key)
        if g is None:
            g = groups[key] = {"rows": [], "users": set()}
        g["rows"].append(r)
        if r.get("username"):
            g["users"].add(r.get("username"))
    return list(groups.values())


def count_open_errors(rows):
    """Unresolved errors among `rows`. Mirrors the server-side filter used by
    admin.open_errors_total (`resolved` false OR null) — a row with no
    `resolved` value counts as open."""
    return sum(1 for r in rows if not r.get("resolved"))


def is_open_ticket(row):
    """A ticket is open unless it carries a terminal status.

    The old test was ``status != "done"``, which counted tickets parked at
    'resolved' or 'duplicate' as open forever. One definition now lives in
    config.CLOSED_TICKET_STATUSES and is shared with admin.archive_resolved,
    so the counter and the bulk-archive can never disagree about what closed
    means.
    """
    return (row.get("status") or "new") not in config.CLOSED_TICKET_STATUSES


def open_tickets(rows):
    return [r for r in rows if is_open_ticket(r)]


def closed_tickets(rows):
    return [r for r in rows if not is_open_ticket(r)]


def online_users(rows):
    """Newest heartbeat per user, keeping only those inside the online window.

    `rows` arrives inserted_at-descending, so the first sighting of a username
    is its newest heartbeat.
    """
    seen = {}
    for r in rows:
        u = r.get("username")
        if u and u not in seen:
            seen[u] = r
    return [r for r in seen.values() if is_online(r.get("inserted_at", ""))]


def errors_card(kpi):
    """What the OPEN ERRORS card should read: (text, is_known).

    Returns "—" when the fetch failed, "N / total" once the server has given a
    true total, and a bare "N" while the total is still unknown. It never prints
    a bare number that could be mistaken for a total — that was the original
    bug: the card counted a list capped at the fetch limit, so it read a flat
    "40" while the table actually held thousands of rows.
    """
    if not kpi.get("errors_ok"):
        return "—", False
    n = kpi.get("errors_open", 0)
    total = kpi.get("errors_total")
    return (f"{n} / {total}" if total is not None else str(n)), True


def tickets_tab_label(rows, base="Tickets"):
    """Tab text for the tickets list. Shows both numbers whenever the list
    contains closed tickets too, so an open-count is never displayed beside a
    longer list."""
    n = len(rows)
    n_open = len(open_tickets(rows))
    if not n:
        return base
    if n_open == n:
        return f"{base} ({n})"
    return f"{base} ({n_open} open / {n})"
