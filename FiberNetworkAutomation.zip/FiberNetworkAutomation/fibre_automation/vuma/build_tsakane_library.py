#!/usr/bin/env python
"""Build comprehensive Tsakane pattern + road-crossing library.

Extracts from Tsakane ground-truth spans:

BLOCK PATTERNS (saved per block):
  '1_centreline_straight'  — Voronoi spine, regularity>0.8, straightness>0.92
  '1_centreline_curved'    — Voronoi spine with bends (irregular block)
  'frontage'               — spine runs near road frontage (single-row block)
  'frontage_corner'        — frontage block at road corner (2+ road-facing sides)
  '2_parallel'             — two parallel spines (wide block, 4+ rows)
  'dog_leg'                — spine makes significant L/Z bend
  'dog_leg_L'              — dog_leg with single bend < 90 deg
  'dog_leg_Z'              — dog_leg with reversal (bend > 90 deg or 2+ bends)
  'stub'                   — short block, single best-edge spine
  'no_span'                — no Tsakane span found for this block

ROAD CROSSING STATS (global, saved once):
  Distribution of: gap_length_m, crossing_angle_deg, distance_to_nearest_junction_m
  Per-percentile values used to tune MAX_GAP_M and crossing-angle preference in worker

k-NN features (7):
  erven_count, regularity, aspect_ratio, median_erf_depth_m,
  short_side_m, erven_depth_cv, n_road_sides

Run with:
    C:/Users/jjsch/.qgis-venv/Scripts/python.exe build_tsakane_library.py

Outputs (both in same directory as this script):
  tsakane_pattern_library.json   — per-block patterns (replaces previous version)
  tsakane_crossings.json         — road-crossing statistics
"""
import os
import json
import math
from pathlib import Path

import numpy as np
import geopandas as gpd
from shapely.geometry import LineString, MultiLineString, Point, Polygon
from shapely.ops import linemerge
from shapely.strtree import STRtree

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

TSAKANE_ERVEN = os.environ.get("TSAKANE_ERVEN", r"C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/tsakane TEST/Shapefiles/Tsakane Erven.shp")
TSAKANE_SPAN  = os.environ.get("TSAKANE_SPAN",  r"C:/Users/jjsch/OneDrive/ON LAPTOP FIBRE/tsakane TEST/Shapefiles/Span.shp")

_HERE = Path(__file__).parent
LIBRARY_JSON   = _HERE / "tsakane_pattern_library.json"
CROSSINGS_JSON = _HERE / "tsakane_crossings.json"

BLOCK_BUF_M    = 2.0
MIN_BLOCK_AREA = 500.0
UTM_EPSG       = 32735

# ── geometry helpers ──────────────────────────────────────────────────────────

def to_poly_list(geom):
    if geom is None or geom.is_empty:
        return []
    if isinstance(geom, Polygon):
        return [geom]
    if hasattr(geom, 'geoms'):
        return [g for g in geom.geoms if isinstance(g, Polygon)]
    return []


def line_list(geom):
    if geom is None or geom.is_empty:
        return []
    if isinstance(geom, LineString):
        return [geom] if geom.length > 0.5 else []
    if isinstance(geom, MultiLineString):
        return [g for g in geom.geoms if g.length > 0.5]
    if hasattr(geom, 'geoms'):
        result = []
        for g in geom.geoms:
            result.extend(line_list(g))
        return result
    return []


def line_angle_deg(line):
    """Direction of line in degrees [0, 180)."""
    coords = list(line.coords)
    dx = coords[-1][0] - coords[0][0]
    dy = coords[-1][1] - coords[0][1]
    return math.degrees(math.atan2(dy, dx)) % 180


def angle_diff(a, b):
    """Smallest angular difference between two directions in [0, 180)."""
    d = abs(a - b) % 180
    return min(d, 180 - d)


def straightness(line):
    """Ratio of chord length to total arc length. 1.0 = perfectly straight."""
    if line.length < 1.0:
        return 1.0
    coords = list(line.coords)
    chord = ((coords[-1][0]-coords[0][0])**2 + (coords[-1][1]-coords[0][1])**2)**0.5
    return chord / line.length


def spine_max_bend_deg(line, sample_n=20):
    """Maximum interior bend angle along the spine (0=straight, 90=right-angle)."""
    if line.length < 5.0:
        return 0.0
    pts = [line.interpolate(i * line.length / sample_n) for i in range(sample_n + 1)]
    max_bend = 0.0
    for i in range(1, len(pts) - 1):
        ax = pts[i].x - pts[i-1].x; ay = pts[i].y - pts[i-1].y
        bx = pts[i+1].x - pts[i].x; by = pts[i+1].y - pts[i].y
        la = (ax*ax+ay*ay)**0.5; lb = (bx*bx+by*by)**0.5
        if la < 1e-9 or lb < 1e-9:
            continue
        dot = max(-1.0, min(1.0, (ax*bx+ay*by) / (la*lb)))
        bend = math.degrees(math.acos(dot))
        if bend > max_bend:
            max_bend = bend
    return max_bend


def count_road_facing_sides(block, block_strtree, all_blocks, buffer_m=6.0):
    """Count how many MRR sides face open space (roads/parks) vs adjacent blocks.

    Uses block adjacency: a side is road-facing if no other block is present
    within buffer_m of the side's outward probe point.  Fast because block_strtree
    returns only nearby candidates rather than testing the full erven_union.
    """
    mrr    = block.minimum_rotated_rectangle
    coords = list(mrr.exterior.coords)[:4]
    cx, cy = block.centroid.x, block.centroid.y
    n_road = 0
    for i in range(4):
        a = coords[i]; b = coords[(i + 1) % 4]
        mx = (a[0] + b[0]) / 2; my = (a[1] + b[1]) / 2
        dx = b[0] - a[0]; dy = b[1] - a[1]
        L  = (dx * dx + dy * dy) ** 0.5
        if L < 1e-9:
            continue
        nx = -dy / L; ny = dx / L
        # flip normal to point away from centroid
        if (mx - cx) * nx + (my - cy) * ny < 0:
            nx = -nx; ny = -ny
        probe = Point(mx + nx * buffer_m, my + ny * buffer_m)
        nearby = block_strtree.query(probe.buffer(buffer_m))
        has_neighbour = any(
            all_blocks[j] is not block and all_blocks[j].distance(probe) < buffer_m
            for j in nearby
        )
        if not has_neighbour:
            n_road += 1
    return n_road


# ── block features ────────────────────────────────────────────────────────────

def block_features(block, block_erven, block_strtree, all_blocks):
    """Compute 7 k-NN features (must match worker feature vector exactly)."""
    mrr = block.minimum_rotated_rectangle
    mrr_coords = list(mrr.exterior.coords)[:4]
    sides = sorted(
        ((mrr_coords[(i+1)%4][0]-mrr_coords[i][0])**2 +
         (mrr_coords[(i+1)%4][1]-mrr_coords[i][1])**2)**0.5
        for i in range(4)
    )
    short_side   = sides[0]
    long_side    = sides[-1]
    regularity   = block.area / (mrr.area + 1e-9)
    aspect_ratio = long_side / (short_side + 1e-9)

    depths = sorted(g.area**0.5 for g in block_erven if g.area > 10)
    median_depth = depths[len(depths)//2] if depths else 0.0

    # Erf-depth coefficient of variation: high = irregular depths, low = uniform grid
    depth_cv = 0.0
    if len(depths) > 2:
        arr = np.array(depths, dtype=float)
        depth_cv = float(np.std(arr) / (np.mean(arr) + 1e-9))

    n_road_sides = count_road_facing_sides(block, block_strtree, all_blocks)

    # NOTE: keep these keys exactly in sync with the worker feature vector in
    # step_02_spans.py (_knn_pattern / library load). long_side is intentionally
    # NOT stored — it is already captured by aspect_ratio (long/short) and the
    # worker never reads it, so emitting it would create a phantom 8th feature.
    return {
        'erven_count':        len(block_erven),
        'regularity':         round(regularity, 4),
        'aspect_ratio':       round(aspect_ratio, 3),
        'median_erf_depth_m': round(median_depth, 2),
        'short_side_m':       round(short_side, 2),
        'erven_depth_cv':     round(depth_cv, 3),
        'n_road_sides':       n_road_sides,
    }


# ── spine-within-block extraction ────────────────────────────────────────────

def spines_for_block(block, span_geoms, span_tree, min_clip_m=10.0):
    """Return list of clipped spine segments significantly inside block."""
    results = []
    for idx in span_tree.query(block.buffer(3.0)):
        span = span_geoms[idx]
        if span is None or span.is_empty:
            continue
        try:
            clipped = span.intersection(block.buffer(3.0))
        except Exception:
            _swallowed_note(); continue
        for seg in line_list(clipped):
            if seg.length >= min_clip_m:
                results.append(seg)
    return results


# ── pattern classification ────────────────────────────────────────────────────

def classify_pattern(block, spines, feats):
    """Classify block into a fine-grained pattern label.

    Uses both geometry of the block and properties of the matched spine segments.
    Sub-patterns:
      frontage_corner — frontage + 2+ road-facing sides (corner block)
      dog_leg_L       — single moderate bend (45-90 deg)
      dog_leg_Z       — sharp reversal (bend > 90 deg, or multiple bends)
    """
    if not spines:
        return 'no_span'

    merged = line_list(linemerge(MultiLineString([s for s in spines if isinstance(s, LineString)])))
    if not merged:
        merged = spines

    boundary     = block.boundary
    interior_thr = max(feats['short_side_m'] * 0.25, 8.0)

    centreline_segs = []
    frontage_segs   = []
    for seg in merged:
        pts = [seg.interpolate(seg.length * t / 20) for t in range(21)]
        median_dist = sorted(boundary.distance(pt) for pt in pts)[10]
        if median_dist > interior_thr:
            centreline_segs.append(seg)
        else:
            frontage_segs.append(seg)

    n_centre = len(centreline_segs)
    n_front  = len(frontage_segs)

    # Stub: very short or few erven
    if feats['erven_count'] < 4 or feats['short_side_m'] < 25:
        return 'stub'

    # Frontage — spine runs near road edge
    if n_front > n_centre:
        n_road = feats.get('n_road_sides', 2)
        return 'frontage_corner' if n_road >= 2 else 'frontage'

    if n_centre == 0:
        return 'no_span'

    # Two parallel centreline spines
    if n_centre >= 2:
        angles  = [line_angle_deg(s) for s in centreline_segs[:4]]
        mean_a  = sum(angles) / len(angles)
        if all(angle_diff(a, mean_a) < 30 for a in angles):
            return '2_parallel'
        return '1_centreline_curved'

    # Single centreline spine
    spine = centreline_segs[0]
    s     = straightness(spine)
    b     = spine_max_bend_deg(spine)

    if b > 45:
        # dog_leg: classify into L (single moderate bend) vs Z (reversal)
        if b > 90:
            return 'dog_leg_Z'
        return 'dog_leg_L'
    if b > 20 and s < 0.92:
        # mild dog_leg — fits dog_leg_L classification
        return 'dog_leg_L'
    if s > 0.92:
        return '1_centreline_straight'
    return '1_centreline_curved'


# ── road crossing analysis ────────────────────────────────────────────────────

def _gap_class(gap_m):
    """Classify crossing gap by width."""
    if gap_m < 10.0:
        return 'narrow'     # alley / footpath
    if gap_m < 22.0:
        return 'medium'     # residential road
    return 'wide'           # collector / arterial


def _exit_side(gap, block):
    """Classify which side of block the crossing exits from (long/short)."""
    mrr    = block.minimum_rotated_rectangle
    coords = list(mrr.exterior.coords)[:4]
    sides  = []
    for i in range(4):
        a = coords[i]; b = coords[(i+1)%4]
        L = ((b[0]-a[0])**2 + (b[1]-a[1])**2)**0.5
        sides.append((L, a, b))
    sides.sort(key=lambda x: x[0], reverse=True)
    long_a, long_b = sides[0][1], sides[0][2]
    # Angle of the crossing
    gap_angle = line_angle_deg(gap)
    # Angle of long axis of block
    dx = long_b[0] - long_a[0]; dy = long_b[1] - long_a[1]
    long_angle = math.degrees(math.atan2(dy, dx)) % 180
    diff = angle_diff(gap_angle, long_angle)
    # If connector is roughly perpendicular to long axis → exits short end
    return 'short_end' if diff > 60 else 'long_side'


def extract_road_crossings(span_geoms, erven_union, blocks, block_centroids):
    """Find all inter-block road crossings in Tsakane spans.

    A crossing is a segment of a span that lies OUTSIDE the erven corridor
    (erven buffered 5m) and connects two different blocks.

    Returns list of dicts with gap geometry, stats, and block context.
    """
    tight         = erven_union.buffer(5.0)
    block_geoms   = blocks
    block_tree    = STRtree(block_geoms)
    centroid_tree = STRtree([Point(c) for c in block_centroids])
    crossings     = []

    for span in span_geoms:
        if span is None or span.is_empty:
            continue
        try:
            outside = span.difference(tight)
        except Exception:
            _swallowed_note(); continue
        for gap in line_list(outside):
            gap_len = gap.length
            if gap_len < 5.0 or gap_len > 100.0:
                continue

            crossing_angle = line_angle_deg(gap)

            # Near-junction detection: 3+ blocks within 80m of gap midpoint
            mid          = gap.interpolate(0.5, normalized=True)
            nearby_cidxs = centroid_tree.query(mid.buffer(80.0))
            near_junction = len(nearby_cidxs) >= 3

            gap_cls = _gap_class(gap_len)

            # Find which block the gap exits from (source block = nearest to gap start)
            p_start  = Point(list(gap.coords)[0])
            src_idxs = block_tree.query(p_start.buffer(15.0))
            src_block = None
            best_d = float('inf')
            for idx in src_idxs:
                d = block_geoms[idx].distance(p_start)
                if d < best_d:
                    best_d = d; src_block = block_geoms[idx]

            exit_side = _exit_side(gap, src_block) if src_block is not None else 'unknown'

            # Angle relative to perpendicular (45 = ideal perpendicular crossing)
            perp_quality = 90.0 - abs(crossing_angle % 90 - 45)

            crossings.append({
                'gap_length_m':       round(gap_len, 1),
                'crossing_angle_deg': round(crossing_angle, 1),
                'perp_quality':       round(perp_quality, 1),
                'near_junction':      near_junction,
                'gap_class':          gap_cls,
                'exit_side':          exit_side,
            })

    return crossings


def crossing_stats(crossings):
    """Compute percentile stats for crossing lengths and angles, grouped by gap class."""
    if not crossings:
        return {}
    lengths  = sorted(c['gap_length_m'] for c in crossings)
    perp     = sorted(c['perp_quality'] for c in crossings)
    near_j   = sum(1 for c in crossings if c['near_junction'])

    def pct(lst, p):
        i = int(len(lst) * p / 100)
        return round(lst[min(i, len(lst)-1)], 1)

    # Per-gap-class breakdown
    by_class = {}
    for cls in ('narrow', 'medium', 'wide'):
        sub = [c['gap_length_m'] for c in crossings if c['gap_class'] == cls]
        if sub:
            sub.sort()
            by_class[cls] = {
                'count':    len(sub),
                'p50':      pct(sub, 50),
                'p90':      pct(sub, 90),
                'exit_short_pct': round(
                    100 * sum(1 for c in crossings if c['gap_class'] == cls and c['exit_side'] == 'short_end')
                    / len(sub), 1),
            }

    return {
        'n_crossings':       len(crossings),
        'near_junction_pct': round(100 * near_j / len(crossings), 1),
        'gap_length': {
            'p10': pct(lengths, 10), 'p25': pct(lengths, 25),
            'p50': pct(lengths, 50), 'p75': pct(lengths, 75),
            'p90': pct(lengths, 90), 'p95': pct(lengths, 95),
        },
        'perp_quality': {
            'p25': pct(perp, 25), 'p50': pct(perp, 50), 'p75': pct(perp, 75),
        },
        'by_gap_class':             by_class,
        'recommended_max_gap_m':    pct(lengths, 90),
        'all_crossings':            crossings,
    }


# ── junction approximation ───────────────────────────────────────────────────

def find_approximate_junctions(blocks):
    """Approximate road junctions as points where 3+ block corners cluster."""
    all_pts = []
    for block in blocks:
        for c in list(block.exterior.coords)[:-1]:
            all_pts.append(c)
    if not all_pts:
        return []
    pts = np.array(all_pts)
    from scipy.spatial import cKDTree
    tree     = cKDTree(pts)
    junctions = []
    visited  = set()
    for i, pt in enumerate(all_pts):
        if i in visited:
            continue
        idxs = tree.query_ball_point(pt, 20.0)
        if len(idxs) >= 3:
            cluster = pts[idxs]
            cx, cy  = cluster[:, 0].mean(), cluster[:, 1].mean()
            junctions.append((cx, cy))
            for j in idxs:
                visited.add(j)
    return junctions


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    print("Loading Tsakane erven...")
    erven = gpd.read_file(TSAKANE_ERVEN)
    if erven.crs is None or erven.crs.to_epsg() != UTM_EPSG:
        erven = erven.to_crs(UTM_EPSG)
    erven['geometry'] = erven.geometry.buffer(0)
    print(f"  {len(erven):,} erven")

    if not Path(TSAKANE_SPAN).exists():
        print(f"ERROR: Span file not found at {TSAKANE_SPAN}")
        return
    spans = gpd.read_file(TSAKANE_SPAN)
    if spans.crs is None or spans.crs.to_epsg() != UTM_EPSG:
        spans = spans.to_crs(UTM_EPSG)
    span_geoms = list(spans.geometry)
    span_tree  = STRtree(span_geoms)
    print(f"  {len(span_geoms):,} spans")

    print("Building blocks...")
    erven_geoms  = list(erven.geometry)
    erven_union  = erven.geometry.union_all()
    blocks_raw   = erven_union.buffer(BLOCK_BUF_M).buffer(-BLOCK_BUF_M)
    blocks       = to_poly_list(blocks_raw)
    erven_tree   = STRtree(erven_geoms)
    print(f"  {len(blocks):,} blocks")

    block_centroids = [(b.centroid.x, b.centroid.y) for b in blocks]
    block_strtree   = STRtree(blocks)  # for fast road-side detection

    # ── per-block pattern extraction ──────────────────────────────────────────
    library       = []
    pattern_counts = {}
    print("\nExtracting block patterns...")

    for bi, block in enumerate(blocks):
        if block.area < MIN_BLOCK_AREA:
            continue
        idxs = erven_tree.query(block)
        block_erven = [erven_geoms[i] for i in idxs
                       if erven_geoms[i] is not None
                       and not erven_geoms[i].is_empty
                       and block.intersects(erven_geoms[i])]
        if len(block_erven) < 2:
            continue

        feats  = block_features(block, block_erven, block_strtree, blocks)
        spines = spines_for_block(block, span_geoms, span_tree)
        pat    = classify_pattern(block, spines, feats)
        pattern_counts[pat] = pattern_counts.get(pat, 0) + 1

        entry = dict(feats)
        entry['pattern'] = pat

        # Diagnostic fields — NOT used in k-NN but saved for debugging / analysis
        if spines:
            merged = line_list(linemerge(MultiLineString([s for s in spines if isinstance(s, LineString)])))
            if merged:
                best = max(merged, key=lambda s: s.length)
                entry['spine_length_m']    = round(best.length, 1)
                entry['spine_straightness'] = round(straightness(best), 3)
                entry['spine_max_bend']    = round(spine_max_bend_deg(best), 1)
                # How far does the spine sit from the block boundary?
                # Low = runs near edge (frontage/on-boundary type)
                # High = runs through interior (centreline type)
                bnd = block.boundary
                sample_pts = [best.interpolate(i * best.length / 20) for i in range(21)]
                dists = sorted(bnd.distance(pt) for pt in sample_pts)
                entry['spine_boundary_dist_p50'] = round(dists[10], 1)
                entry['spine_boundary_dist_p25'] = round(dists[5], 1)

        library.append(entry)

        if bi % 200 == 0:
            print(f"  [{bi}/{len(blocks)}] {pattern_counts}")

    print("\nBlock pattern counts:")
    for pat, cnt in sorted(pattern_counts.items(), key=lambda x: -x[1]):
        print(f"  {pat:30s}: {cnt:5d}  ({100*cnt/len(library):.1f}%)")

    # ── road crossing analysis ────────────────────────────────────────────────
    print("\nExtracting road crossings...")
    crossings = extract_road_crossings(span_geoms, erven_union, blocks, block_centroids)
    stats     = crossing_stats(crossings)
    print(f"  {stats.get('n_crossings', 0)} crossings found")
    g = stats.get('gap_length', {})
    print(f"  Gap length: p50={g.get('p50')}m  p90={g.get('p90')}m  p95={g.get('p95')}m")
    print(f"  Near junction: {stats.get('near_junction_pct', '?')}%")
    print(f"  Recommended MAX_GAP_M: {stats.get('recommended_max_gap_m', '?')}m")

    by_cls = stats.get('by_gap_class', {})
    for cls in ('narrow', 'medium', 'wide'):
        if cls in by_cls:
            bc = by_cls[cls]
            print(f"  {cls:8s}: n={bc['count']}  p50={bc['p50']}m  p90={bc['p90']}m  "
                  f"exit_short={bc['exit_short_pct']}%")

    # ── save outputs ─────────────────────────────────────────────────────────
    LIBRARY_JSON.write_text(json.dumps(library, indent=2), encoding='utf-8')
    sz = LIBRARY_JSON.stat().st_size // 1024
    print(f"\nSaved pattern library: {LIBRARY_JSON}  ({len(library)} entries, {sz} KB)")

    stats_out = {k: v for k, v in stats.items() if k != 'all_crossings'}
    stats_out['all_crossings'] = crossings
    CROSSINGS_JSON.write_text(json.dumps(stats_out, indent=2), encoding='utf-8')
    print(f"Saved crossing stats:   {CROSSINGS_JSON}")

    # ── tuning summary ────────────────────────────────────────────────────────
    import statistics as _s
    print("\n=== TUNING RECOMMENDATIONS ===")
    print(f"MAX_GAP_M  = {stats.get('recommended_max_gap_m', 30)}m  "
          "(covers 90% of Tsakane crossings — use as reference for formal townships)")
    print("MAX_CONN_M = 250m  (unchanged)")

    if library:
        ecs  = [e['erven_count'] for e in library]
        ss   = [e['short_side_m'] for e in library]
        ars  = [e['aspect_ratio'] for e in library]
        dcvs = [e.get('erven_depth_cv', 0) for e in library]
        nrs  = [e.get('n_road_sides', 0) for e in library]
        print(f"\nerven_count:     min={min(ecs)}  p25={sorted(ecs)[len(ecs)//4]}  "
              f"median={int(_s.median(ecs))}  p75={sorted(ecs)[3*len(ecs)//4]}  max={max(ecs)}")
        print(f"short_side_m:    min={min(ss):.0f}m  median={_s.median(ss):.0f}m  max={max(ss):.0f}m")
        print(f"aspect_ratio:    min={min(ars):.1f}  median={_s.median(ars):.1f}  max={max(ars):.1f}")
        print(f"erven_depth_cv:  mean={_s.mean(dcvs):.3f}  max={max(dcvs):.3f}  "
              f"(low=uniform grid, high=irregular depths)")
        from collections import Counter
        rs_counts = Counter(int(x) for x in nrs)
        print(f"n_road_sides:    {dict(sorted(rs_counts.items()))}  "
              f"(1=interior, 2=corner or end-block)")

        # Report sub-pattern breakdown
        sub_pats = [e['pattern'] for e in library]
        sub_counts = Counter(sub_pats)
        print("\nSub-pattern breakdown:")
        for pat, cnt in sub_counts.most_common():
            print(f"  {pat:35s}: {cnt:5d}  ({100*cnt/len(library):.1f}%)")

        # Report spine boundary distance by pattern
        print("\nSpine boundary distance by pattern (p50):")
        pat_dists = {}
        for e in library:
            p = e['pattern']
            d = e.get('spine_boundary_dist_p50')
            if d is not None:
                pat_dists.setdefault(p, []).append(d)
        for pat in sorted(pat_dists):
            ds = sorted(pat_dists[pat])
            med = ds[len(ds)//2]
            print(f"  {pat:35s}: median={med:.1f}m  n={len(ds)}")


if __name__ == '__main__':
    main()
