"""geometry_guardian — a black-box flight recorder + auto-restore for layer data.

Why: teammates hit cases where geometry mass-vanishes from a project and nobody
can explain what happened. This watches every vector layer and, when a MASSIVE
number of features disappears WITHOUT the operator deleting them (a bug, a rogue
regen, a provider wipe), it (1) AUTO-RESTORES the lost features from a rolling
"last healthy" backup, and (2) records a full incident centrally so the team
never has to reconstruct what went wrong.

Design (safe to ship to everyone — must never lose data or crash QGIS):
  * A QTimer on the MAIN thread ticks every ~12 s and reads featureCount() per
    layer (cheap). No background thread touches QGIS objects.
  * Per layer it keeps the LAST HEALTHY full snapshot (geometry WKT + attrs),
    refreshed only when the count is STABLE or GROWING — a snapshot is never
    overwritten by a shrunken state, so the backup always holds the most data we
    ever saw. Memory is bounded (per-layer + global caps); huge layers are
    count-only-watched (still detected, restore skipped if no snapshot).
  * Anomaly = a feature count drop ≥ a MASSIVE threshold (default: the larger of
    150 features or 40 % of the layer) between ticks, that is NOT whitelisted by
    an operator action. Small deletes are ignored (operators delete intentionally).
  * Operator-intent: our own delete handlers call note_operator_delete(); plus a
    drop inside an active edit session is treated as operator intent. Everything
    else big = a bug → restore + report.
  * Restore is by CONTENT (re-add backup features whose WKT isn't currently
    present) so it can't create duplicates and only ever ADDS back what vanished.
  * Degrade-not-crash everywhere; fail-silent; clean stop on unload.
"""
import os
import time
import traceback

try:
    from fibre_automation.shared.swallowed import note as _swallowed_note
except Exception:  # helper unavailable: keep the old silent behaviour
    def _swallowed_note(context=''):
        pass

# ── Activity breadcrumb (the "what was happening when it broke" black box) ──────
# Like a console crash report: when geometry mass-vanishes we attach the last
# things the plugin was doing so the ROOT CAUSE can be fixed centrally, not just
# the symptom restored. The dock's log_message feeds this (one line); cheap ring.
_ACTIVITY = []


def record_activity(text, _cap=50):
    """Push a breadcrumb of what the plugin is doing. Best-effort, never raises."""
    try:
        _ACTIVITY.append((time.time(), str(text)[:240]))
        if len(_ACTIVITY) > _cap:
            del _ACTIVITY[:-_cap]
    except Exception:
        _swallowed_note()


def recent_activity(n=20, within_s=180):
    """The last n breadcrumbs within the window — 'what led up to the loss'."""
    try:
        now = time.time()
        return [t for (ts, t) in _ACTIVITY[-n:] if now - ts <= within_s]
    except Exception:
        return []


# ── Operator-delete whitelist (module-level so any handler can flag intent) ─────
_OP_DELETES = {}        # layer_id -> expiry_ts
# _OP_DELETE_WINDOW is defined once with the other tunables below.


def note_operator_delete(layer_id, n_deleted=0):
    """Call RIGHT BEFORE an intentional bulk delete so the guardian treats the
    resulting drop as operator intent, not an anomaly. Best-effort; never raises."""
    try:
        _OP_DELETES[str(layer_id)] = time.time() + _OP_DELETE_WINDOW
    except Exception:
        _swallowed_note()


def _op_delete_active(layer_id):
    try:
        exp = _OP_DELETES.get(str(layer_id))
        return exp is not None and exp >= time.time()
    except Exception:
        return False

# Tunables (conservative — only catastrophic, clearly-not-operator losses act)
_TICK_MS = 12000
_MASSIVE_ABS = 150          # a drop this big (abs) is always "massive"
_MASSIVE_FRAC = 0.40        # ...or this fraction of the layer
_MAX_BACKUP_FEATURES = 15000   # full-snapshot only modest layers; bigger layers are
                               # count-only-watched (mass-loss still DETECTED, just no
                               # WKT snapshot) so a giant reference layer (e.g. a 22k
                               # Phase-1 layer) can't freeze the UI thread.
_MAX_TOTAL_BACKUP = 400000     # global cap on total backed-up features
# Per-tick wall-clock budget for WKT-snapshotting. The guardian must never block the
# Qt main thread: once a tick has spent this long taking NEW snapshots it stops and
# the remaining layers are snapshotted on later ticks. featureCount() checks +
# anomaly detection + restore (the safety-critical parts) always still run.
_MAX_TICK_SNAPSHOT_MS = 400
_SNAPSHOT_CHUNK_MS = 50        # max UI-thread time per snapshot chunk before yielding
_SNAP_STABLE_REFRESH_S = 180   # re-snapshot a merely-stable layer at most this often
_OP_DELETE_WINDOW = 8.0     # seconds a whitelisted operator-delete stays valid
_REPORT_COOLDOWN = 600      # per-layer: restore always, but REPORT/ticket at most
                            # once per this window — so a layer that keeps losing +
                            # restoring can never flood the ticket queue
_INCIDENT_FILE = os.path.join(os.path.expanduser("~"), ".velocity_nexus",
                              "guardian_incidents.json")


class GeometryGuardian:
    """Start with start(report_cb). report_cb(incident: dict) is called ON THE
    MAIN THREAD for each auto-restore incident (keys: layer, layer_id, before,
    after, restored, threshold, ts_iso, in_edit). Best-effort; never raises out."""

    def __init__(self, report_cb=None, interval_ms=_TICK_MS, parent=None):
        self._report_cb = report_cb
        self._interval = interval_ms
        self._parent = parent   # Qt owner for the timer, so teardown order is Qt's
        self._timer = None
        # per layer_id: {"count": int, "snap_count": int, "snap": {wkt: attrs},
        #                "snap_ts": float}
        self._state = {}
        self._op_deletes = {}   # layer_id -> (expiry_ts, n_expected)
        self._last_report = {}  # layer_id -> ts of last REPORT (flood guard)
        self._busy = False
        self._stopped = False
        self._jobs = []             # chunked snapshots waiting, oldest first
        self._chunk_pending = False

    # ── public API ────────────────────────────────────────────────────────────
    def start(self):
        self._stopped = False
        try:
            from qgis.PyQt.QtCore import QTimer
            self._timer = QTimer(self._parent)
            self._timer.setInterval(self._interval)
            self._timer.timeout.connect(self._safe_tick)
            self._timer.start()
            # seed initial snapshots immediately so the first real tick has a baseline
            self._safe_tick()
        except Exception:
            self._timer = None

    def stop(self):
        self._stopped = True   # ends any chunked snapshot still in flight
        try:
            from qgis.PyQt import sip
            # A parented timer can already be gone if its owner was torn down first.
            if self._timer is not None and not sip.isdeleted(self._timer):
                self._timer.stop()
                self._timer.timeout.disconnect()
                self._timer.deleteLater()   # parented: Qt would otherwise keep it until QGIS exits
        except Exception:
            _swallowed_note()
        self._timer = None
        self._state.clear()

    def note_operator_delete(self, layer_id, n_deleted=0):
        """Whitelist an intentional delete (delegates to the module-level store so
        any handler can flag intent without a guardian handle)."""
        note_operator_delete(layer_id, n_deleted)

    # ── tick ───────────────────────────────────────────────────────────────────
    def _safe_tick(self):
        if self._busy:
            return
        self._busy = True
        try:
            self._tick()
        except Exception:
            _swallowed_note()
        finally:
            self._busy = False

    def _tick(self):
        from qgis.core import QgsProject, QgsVectorLayer
        # Bound the WKT-snapshot work this tick so the guardian can never block the
        # UI thread for more than ~_MAX_TICK_SNAPSHOT_MS; overflow defers to next tick.
        self._tick_deadline = time.time() + (_MAX_TICK_SNAPSHOT_MS / 1000.0)
        live_ids = set()
        for lyr in list(QgsProject.instance().mapLayers().values()):
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                continue
            if lyr.geometryType() not in (0, 1, 2):   # point/line/poly only
                continue
            lid = lyr.id()
            live_ids.add(lid)
            # Recompute the global backup total each iteration so the cap check in
            # _maybe_snapshot reflects snapshots already taken earlier in this tick
            # (a single pre-loop value underestimates after the first layer and
            # lets the global memory cap be exceeded with many large layers).
            total_backed = sum(len(s.get("snap", {})) for s in self._state.values())
            try:
                cur = lyr.featureCount()
            except Exception:
                _swallowed_note(); continue
            if cur is None or cur < 0:
                continue
            st = self._state.get(lid)
            if st is None:
                # first sight — baseline + (best-effort) snapshot
                st = {"count": cur, "snap_count": 0, "snap": {}, "snap_ts": 0.0}
                self._state[lid] = st
                self._maybe_snapshot(lyr, st, cur, total_backed)
                continue

            prev = st["count"]
            drop = prev - cur
            threshold = max(_MASSIVE_ABS, int(prev * _MASSIVE_FRAC))

            if drop >= threshold and prev > 0:
                # Evaluate operator-intent ONCE up front: _handle_anomaly() below
                # does I/O, and the operator-delete window can expire between two
                # calls — a True/then/False split would suppress the restore AND
                # skip the re-snapshot, leaving the pre-delete snapshot to later
                # falsely restore intentionally-deleted features.
                is_op = self._is_operator(lid, lyr, drop)
                if not is_op:
                    self._handle_anomaly(lyr, st, prev, cur)
                # whichever way, re-baseline to the new reality so we don't loop
                st["count"] = lyr.featureCount()
                # operator delete → the smaller state IS the new healthy one
                if is_op:
                    self._reset_snapshot(lyr, st, st["count"], total_backed)
                continue

            # healthy: refresh snapshot when stable/growing (never on a shrink)
            st["count"] = cur
            if cur >= st["snap_count"]:
                self._maybe_snapshot(lyr, st, cur, total_backed)

        # drop state for layers no longer in the project
        for lid in list(self._state.keys()):
            if lid not in live_ids:
                self._state.pop(lid, None)

    # ── operator-intent ─────────────────────────────────────────────────────────
    def _is_operator(self, lid, lyr, drop):
        # explicit whitelist from our handlers (module-level store)
        if _op_delete_active(lid):
            return True
        # a big drop while the operator has an active edit session on this layer
        try:
            if lyr.isEditable():
                return True
        except Exception:
            _swallowed_note()
        return False

    # ── snapshot mgmt ───────────────────────────────────────────────────────────
    def _maybe_snapshot(self, lyr, st, cur, total_backed):
        if cur > _MAX_BACKUP_FEATURES:
            return                       # too big to back up — count-only watch
        if total_backed + cur > _MAX_TOTAL_BACKUP:
            return                       # global memory cap
        # avoid re-snapshotting too often when merely stable
        if st["snap"] and cur == st["snap_count"] and (time.time() - st["snap_ts"]) < _SNAP_STABLE_REFRESH_S:
            return
        # a chunked snapshot of this layer is already in flight
        if st.get("_job") is not None:
            return
        # per-tick time budget: if this tick has already spent its snapshot budget,
        # defer this layer to a later tick rather than block the UI thread.
        if time.time() > getattr(self, "_tick_deadline", 0):
            return
        self._start_chunked_snapshot(lyr, st, cur)

    # A 15k-feature layer takes ~0.75 s to snapshot in one go (measured on a PH2
    # copy), which froze the UI every re-snapshot. Build it in short chunks that
    # yield to the event loop, and swap it in only when complete, so a restore
    # always works from a whole snapshot (the previous one until then).
    def _start_chunked_snapshot(self, lyr, st, cur):
        try:
            # the feature iterator is opened only when this job reaches the front of
            # the queue: many open OGR iterators at once evict each other from the
            # connection pool, and a resumed one then stalls (594 ms seen on PH2 poles)
            st["_job"] = {"layer": lyr, "count": cur, "it": None, "snap": {},
                          "fields": [f.name() for f in lyr.fields()]}
        except Exception:
            st.pop("_job", None)
            return
        # Jobs run one at a time, one chunk per event-loop turn, all from the event
        # loop - so a tick only counts features, and many layers starting a snapshot
        # at once cannot add their chunks up into one long freeze.
        self._jobs.append(st)
        self._schedule_chunk()

    def _schedule_chunk(self):
        if self._chunk_pending or not self._jobs or self._stopped:
            return
        from qgis.PyQt.QtCore import QTimer
        self._chunk_pending = True
        QTimer.singleShot(1, self._run_chunk)

    def _run_chunk(self):
        self._chunk_pending = False
        while self._jobs and self._jobs[0].get("_job") is None:
            self._jobs.pop(0)          # superseded by a synchronous re-baseline
        if self._stopped or not self._jobs:
            self._jobs = []
            return
        st = self._jobs[0]
        if self._snapshot_chunk(st):
            self._jobs.pop(0)
        self._schedule_chunk()

    def _snapshot_chunk(self, st):
        """Advance one job by at most _SNAPSHOT_CHUNK_MS. True when the job is over
        (completed or abandoned), False when it needs another chunk."""
        job = st.get("_job")
        if job is None:
            return True
        lyr = job["layer"]
        try:
            from qgis.PyQt import sip
            # Abandon if the layer went away, entered an edit session, or changed size
            # between chunks - a later tick starts a fresh snapshot.
            if sip.isdeleted(lyr) or lyr.isEditable() or lyr.featureCount() != job["count"]:
                st.pop("_job", None)
                return True
            deadline = time.time() + _SNAPSHOT_CHUNK_MS / 1000.0
            if job["it"] is None:
                job["it"] = lyr.getFeatures()
            snap = job["snap"]
            n = 0
            for f in job["it"]:
                g = f.geometry()
                if g and not g.isEmpty():
                    wkt = g.asWkt(7)
                    if wkt and wkt not in snap:
                        snap[wkt] = list(f.attributes())
                n += 1
                if n % 20 == 0 and time.time() > deadline:
                    return False
            st["snap"] = snap
            st["snap_count"] = job["count"]
            st["snap_ts"] = time.time()
            st["_fields"] = job["fields"]
        except Exception:
            _swallowed_note()
        st.pop("_job", None)
        return True

    def _reset_snapshot(self, lyr, st, cur, total_backed):
        st.pop("_job", None)   # a synchronous re-baseline supersedes any chunked one
        try:
            snap = {}
            fields = [f.name() for f in lyr.fields()]
            for f in lyr.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                wkt = g.asWkt(7)
                if wkt and wkt not in snap:
                    snap[wkt] = list(f.attributes())
            st["snap"] = snap
            st["snap_count"] = cur
            st["snap_ts"] = time.time()
            st["_fields"] = fields
        except Exception:
            _swallowed_note()

    # ── anomaly → restore + report ──────────────────────────────────────────────
    def _handle_anomaly(self, lyr, st, before, after):
        # ALWAYS restore (protect the data) — every tick, no matter what.
        snap = st.get("snap") or {}
        restored = 0
        if snap:
            try:
                restored = self._restore(lyr, snap)
            except Exception:
                restored = 0
        # FLOOD GUARD: a layer that keeps losing + restoring would re-trigger every
        # ~12 s. Restore each time, but REPORT/ticket at most once per cooldown per
        # layer — so the ticket queue can never be flooded by one misbehaving layer.
        lid = lyr.id()
        if (time.time() - self._last_report.get(lid, 0)) < _REPORT_COOLDOWN:
            return
        self._last_report[lid] = time.time()
        incident = {
            "layer": lyr.name(),
            "layer_id": lyr.id(),
            "before": before,
            "after": after,
            "lost": before - after,
            "restored": restored,
            "in_edit": bool(self._safe(lambda: lyr.isEditable())),
            "ts_iso": _now_iso(),
            # The "what caused it" black box — like a console crash report. The
            # breadcrumb is the last things the plugin did before the loss; the
            # stack is the live call stack at detection. Together they let the
            # ROOT CAUSE be fixed centrally, not just the symptom restored.
            "project": self._safe(_project_name),
            "context": recent_activity(),
            "stack": _capture_stack(),
        }
        self._write_local(incident)
        # surface it (best-effort)
        try:
            if self._report_cb:
                self._report_cb(incident)
        except Exception:
            _swallowed_note()

    def _restore(self, lyr, snap):
        """Re-add backup features whose geometry WKT is no longer present. Content
        match → never duplicates; only ever ADDS back what vanished."""
        from qgis.core import QgsFeature, QgsGeometry
        present = set()
        for f in lyr.getFeatures():
            g = f.geometry()
            if g and not g.isEmpty():
                present.add(g.asWkt(7))
        fields = lyr.fields()
        to_add = []
        for wkt, attrs in snap.items():
            if wkt in present:
                continue
            nf = QgsFeature(fields)
            try:
                nf.setAttributes(list(attrs))
            except Exception:
                _swallowed_note()
            geom = QgsGeometry.fromWkt(wkt)
            if geom and not geom.isEmpty():
                nf.setGeometry(geom)
                to_add.append(nf)
        if not to_add:
            return 0
        prov = lyr.dataProvider()
        before = lyr.featureCount()
        res = prov.addFeatures(to_add)
        ok = res[0] if isinstance(res, tuple) else bool(res)
        if not ok:
            return 0
        try:
            lyr.updateExtents()
            lyr.triggerRepaint()
        except Exception:
            _swallowed_note()
        return max(0, lyr.featureCount() - before)

    # ── helpers ──────────────────────────────────────────────────────────────────
    @staticmethod
    def _safe(fn):
        try:
            return fn()
        except Exception:
            return None

    @staticmethod
    def _write_local(incident):
        try:
            import json
            os.makedirs(os.path.dirname(_INCIDENT_FILE), exist_ok=True)
            rows = []
            if os.path.exists(_INCIDENT_FILE):
                try:
                    with open(_INCIDENT_FILE, encoding="utf-8") as f:
                        rows = json.load(f)
                except Exception:
                    rows = []
            rows.append(incident)
            with open(_INCIDENT_FILE, "w", encoding="utf-8") as f:
                json.dump(rows[-200:], f, indent=1)
        except Exception:
            _swallowed_note()


def _now_iso():
    try:
        from datetime import datetime, timezone
        return datetime.now(timezone.utc).isoformat()
    except Exception:
        return ""


def _capture_stack():
    """Best-effort live call stack at detection (paths trimmed). Helps pinpoint
    the operation in flight when the loss was caught."""
    try:
        frames = traceback.format_stack(limit=18)
        home = os.path.expanduser("~")
        return "".join(frames).replace(home, "~")[-2500:]
    except Exception:
        return ""


def _project_name():
    try:
        from qgis.core import QgsProject
        return QgsProject.instance().baseName() or "(unsaved)"
    except Exception:
        return ""
