"""Velocity Fibre — branded home dock panel (themeable).

A clean, friendly control panel that fronts the plugin's tools so QGIS feels like a
product, not raw QGIS. Header shows a wordmark (or logo.png if present) + live bridge
status + a theme switcher; below are numbered workflow step buttons and a tools row.
Each button just triggers the plugin's existing actions/callbacks — no logic here.

Two built-in themes:
  • velocity  — VF identity: navy #14213D, blue #3B6FE0 → magenta #C2255C, teal #2ABFCC
  • fibertime — client identity: deep blue #081634, electric blue #1463FF + yellow #FFD400

Everything is styled by objectName via QSS, so switching theme = one stylesheet swap.
"""
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QPixmap
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
)

# ── theme palettes ───────────────────────────────────────────────────────────
THEMES = {
    "velocity": {
        "name": "Velocity Fibre",
        "bg":            "#0F1A30",
        "header":        "qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #14213D, stop:0.7 #1A2440, stop:1 #3A1733)",
        "accent":        "qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #3B6FE0, stop:1 #C2255C)",
        "word_top":      "#FFFFFF",
        "word_bot":      "#9FB0D0",
        "tagline":       "#7E8DB0",
        "section":       "#5E6E92",
        "step_bg":       "#18233E",
        "step_hover":    "#1F2C4C",
        "step_border":   "#222F4E",
        "step_hi":       "#3B6FE0",
        "title":         "#EAF0FF",
        "sub":           "#8294B8",
        "chev":          "#5E6E92",
        "tool_bg":       "#141E36",
        "tool_text":     "#B8C6E6",
        "tool_hover":    "#1D2949",
        "tool_hi":       "#2ABFCC",
        "status_on":     "#2ABFCC",
        "status_off":    "#E0607A",
        "badge_text":    "#FFFFFF",
    },
    "fibertime": {
        "name": "fibertime",
        "bg":            "#081634",
        "header":        "qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #0B2A6B, stop:0.6 #103A8E, stop:1 #155FD0)",
        "accent":        "qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #1463FF, stop:1 #FFD400)",
        "word_top":      "#FFFFFF",
        "word_bot":      "#FFD400",
        "tagline":       "#9FB6E8",
        "section":       "#5C77B8",
        "step_bg":       "#0E2356",
        "step_hover":    "#143071",
        "step_border":   "#1E3C82",
        "step_hi":       "#FFD400",
        "title":         "#EAF1FF",
        "sub":           "#9FB6E8",
        "chev":          "#5C77B8",
        "tool_bg":       "#0C1F4C",
        "tool_text":     "#BCD0F5",
        "tool_hover":    "#143071",
        "tool_hi":       "#FFD400",
        "status_on":     "#FFD400",
        "status_off":    "#FF6B6B",
        "badge_text":    "#08183A",
    },
}

# step title keyword → leading emoji icon (quick visual scanning)
_ICONS = [
    ("detect", "🛰"), ("erven", "📐"), ("planner", "🗺"), ("network", "🗺"),
    ("label", "🏷"), ("audit", "✅"), ("check", "✅"), ("splice", "🧵"),
]


def _icon_for(title):
    t = title.lower()
    for key, emo in _ICONS:
        if key in t:
            return emo
    return "▸"


def _build_qss(c):
    """Build the full panel stylesheet from a theme colour dict."""
    return f"""
#vfRoot {{ background:{c['bg']}; }}
#vfHeader {{ background:{c['header']}; }}
#vfWordTop   {{ color:{c['word_top']}; font-size:20px; font-weight:800; letter-spacing:3px; }}
#vfWordBot   {{ color:{c['word_bot']}; font-size:11px; font-weight:700; letter-spacing:6px; }}
#vfTagline   {{ color:{c['tagline']}; font-size:10px; }}
#vfStatus    {{ color:{c['word_bot']}; font-size:10px; }}
#vfSection   {{ color:{c['section']}; font-size:10px; font-weight:700; letter-spacing:2px; }}

#vfVmark {{ background:{c['accent']}; border-radius:9px; }}
#vfVmark QLabel {{ color:#FFFFFF; font-size:20px; font-weight:900; }}

QPushButton#vfThemeBtn {{
    color:{c['word_bot']}; background:rgba(255,255,255,0.06);
    border:1px solid rgba(255,255,255,0.12); border-radius:9px;
    padding:3px 9px; font-size:10px; font-weight:700;
}}
QPushButton#vfThemeBtn:hover {{ color:#FFFFFF; border:1px solid {c['step_hi']}; }}
QPushButton#vfThemeBtn[active="true"] {{
    color:{c['badge_text']}; background:{c['accent']};
    border:1px solid {c['step_hi']};
}}

/* step cards */
QFrame#vfStep {{
    border:1px solid {c['step_border']}; border-radius:12px; background:{c['step_bg']};
}}
QFrame#vfStep:hover {{ border:1px solid {c['step_hi']}; background:{c['step_hover']}; }}
QFrame#vfStripe {{ background:{c['accent']}; border-top-left-radius:12px; border-bottom-left-radius:12px; }}
QLabel#vfStepNum {{
    background:{c['accent']}; color:{c['badge_text']};
    font-weight:900; font-size:14px; border-radius:14px;
}}
QLabel#vfStepTitle {{ color:{c['title']}; font-size:14px; font-weight:700; }}
QLabel#vfStepSub   {{ color:{c['sub']};   font-size:10px; }}
QLabel#vfStepChev  {{ color:{c['chev']};  font-size:20px; font-weight:800; }}

/* tools */
QPushButton#vfTool {{
    padding:9px 6px; border:1px solid {c['step_border']}; border-radius:10px;
    background:{c['tool_bg']}; color:{c['tool_text']}; font-size:11px; font-weight:700;
}}
QPushButton#vfTool:hover {{ background:{c['tool_hover']}; border:1px solid {c['tool_hi']}; color:#FFFFFF; }}
"""


class VelocityHomePanel(QDockWidget):
    """Branded dock. steps = [(title, subtitle, callable)], tools = [(label, callable)]."""

    def __init__(self, iface, steps, tools, logo_path=None, theme="velocity", parent=None):
        super().__init__("Velocity Fibre", parent or iface.mainWindow())
        self.setObjectName("VelocityHomePanel")
        self.iface = iface
        self._theme = theme if theme in THEMES else "velocity"
        self._status = None
        self._theme_btns = {}
        self._last_online = False
        self._last_port = None

        self._root = QWidget()
        self._root.setObjectName("vfRoot")
        v = QVBoxLayout(self._root)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        v.addWidget(self._build_header(logo_path))

        body = QVBoxLayout()
        body.setContentsMargins(12, 12, 12, 12)
        body.setSpacing(9)
        body.addWidget(self._label("WORKFLOW", "vfSection"))
        for i, (title, sub, cb) in enumerate(steps, 1):
            body.addWidget(self._step_card(i, title, sub, cb))
        body.addSpacing(6)
        body.addWidget(self._label("TOOLS", "vfSection"))
        trow = QHBoxLayout()
        trow.setSpacing(6)
        for label, cb in tools:
            trow.addWidget(self._tool_button(label, cb))
        body.addLayout(trow)
        body.addStretch(1)
        v.addLayout(body)

        self.setWidget(self._root)
        self.setMinimumWidth(258)
        self._apply_theme()

    # ── header ──
    def _build_header(self, logo_path):
        h = QWidget()
        h.setObjectName("vfHeader")
        lay = QVBoxLayout(h)
        lay.setContentsMargins(14, 12, 14, 11)
        lay.setSpacing(3)

        top = QHBoxLayout()
        top.setSpacing(10)
        if logo_path and os.path.exists(logo_path):
            mark = QLabel()
            mark.setPixmap(QPixmap(logo_path).scaledToHeight(34, Qt.SmoothTransformation))
            top.addWidget(mark)
        else:
            mark = QWidget()
            mark.setObjectName("vfVmark")
            mark.setFixedSize(34, 34)
            ml = QVBoxLayout(mark)
            ml.setContentsMargins(0, 0, 0, 0)
            vlab = QLabel("V")
            vlab.setAlignment(Qt.AlignCenter)
            ml.addWidget(vlab)
            top.addWidget(mark)
        words = QVBoxLayout()
        words.setSpacing(0)
        words.addWidget(self._label("VELOCITY", "vfWordTop"))
        words.addWidget(self._label("FIBRE", "vfWordBot"))
        top.addLayout(words)
        top.addStretch(1)
        lay.addLayout(top)
        lay.addWidget(self._label("FTTH Network Planner", "vfTagline"))

        # theme switch + status row
        row = QHBoxLayout()
        row.setSpacing(6)
        self._status = self._label("●  Bridge: checking…", "vfStatus")
        row.addWidget(self._status)
        row.addStretch(1)
        for key in ("velocity", "fibertime"):
            b = QPushButton("VF" if key == "velocity" else "fibertime")
            b.setObjectName("vfThemeBtn")
            b.setCursor(Qt.PointingHandCursor)
            b.setToolTip(f"Switch to the {THEMES[key]['name']} colour theme")
            b.clicked.connect(lambda _=False, k=key: self.set_theme(k))
            self._theme_btns[key] = b
            row.addWidget(b)
        lay.addLayout(row)
        return h

    # ── widgets ──
    def _label(self, text, obj):
        lab = QLabel(text)
        lab.setObjectName(obj)
        return lab

    def _step_card(self, n, title, sub, cb):
        card = QFrame()
        card.setObjectName("vfStep")
        card.setCursor(Qt.PointingHandCursor)
        lay = QHBoxLayout(card)
        lay.setContentsMargins(0, 0, 10, 0)
        lay.setSpacing(0)

        stripe = QFrame()
        stripe.setObjectName("vfStripe")
        stripe.setFixedWidth(5)
        lay.addWidget(stripe)

        inner = QHBoxLayout()
        inner.setContentsMargins(9, 8, 0, 8)
        inner.setSpacing(11)
        num = QLabel(str(n))
        num.setObjectName("vfStepNum")
        num.setFixedSize(28, 28)
        num.setAlignment(Qt.AlignCenter)
        inner.addWidget(num)

        txt = QVBoxLayout()
        txt.setSpacing(1)
        t = QLabel(f"{_icon_for(title)}  {title}")
        t.setObjectName("vfStepTitle")
        s = QLabel(sub)
        s.setObjectName("vfStepSub")
        txt.addWidget(t)
        txt.addWidget(s)
        inner.addLayout(txt)
        inner.addStretch(1)
        lay.addLayout(inner)

        chev = QLabel("›")
        chev.setObjectName("vfStepChev")
        lay.addWidget(chev)

        if cb:
            card.mousePressEvent = lambda _e, f=cb: self._safe(f)
        return card

    def _tool_button(self, label, cb):
        b = QPushButton(label)
        b.setObjectName("vfTool")
        b.setCursor(Qt.PointingHandCursor)
        if cb:
            b.clicked.connect(lambda _=False, f=cb: self._safe(f))
        return b

    def _safe(self, fn):
        try:
            fn()
        except Exception as e:  # never let a panel click raise into the UI
            try:
                self.iface.messageBar().pushWarning("Velocity Fibre", str(e)[:200])
            except Exception:
                pass

    # ── theming ──
    def _apply_theme(self):
        c = THEMES[self._theme]
        self._root.setStyleSheet(_build_qss(c))
        for key, btn in self._theme_btns.items():
            btn.setProperty("active", "true" if key == self._theme else "false")
            btn.style().unpolish(btn)
            btn.style().polish(btn)
        # re-apply status colour (it's set inline) for the new palette
        self.set_bridge(self._last_online, self._last_port)

    def set_theme(self, name):
        if name in THEMES and name != self._theme:
            self._theme = name
            self._apply_theme()

    # ── public ──
    def set_bridge(self, online, port=None):
        self._last_online, self._last_port = online, port
        if not self._status:
            return
        c = THEMES[self._theme]
        if online:
            self._status.setText("●  Bridge online" + (f" · {port}" if port else ""))
            self._status.setStyleSheet(f"color:{c['status_on']}; font-size:10px;")
        else:
            self._status.setText("●  Bridge offline")
            self._status.setStyleSheet(f"color:{c['status_off']}; font-size:10px;")
