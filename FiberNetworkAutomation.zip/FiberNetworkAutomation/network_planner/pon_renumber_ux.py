"""Pass 6b (Renumber) — pure, unit-testable validation + live-status for the
interactive 🔢 Renumber dialog.

The renumber ENGINE (``_pon_renumber_apply`` / ``_pon_renumber_apply_label`` in the
dock) and the Finalize block/allow decision are NOT touched — Finalize stays the
authority. ``renumber_facts`` mirrors Finalize's exact duplicate/gap/unclicked
computation so the LIVE panel this drives can never disagree with the confirm dialog.
No QGIS objects.
"""

import re
from collections import Counter


def _as_num(v):
    """First run of digits in a PON value as an int (mirrors the finalize path)."""
    m = re.search(r"\d+", str(v))
    return int(m.group()) if m else None


def renumber_facts(order, base, all_pons):
    """order: clicked old PON values, in click order. base: number the first gets.
    all_pons: every PON value in the layer. Returns the same duplicate/gap/unclicked
    facts Finalize computes, plus the old→new mapping. Never raises."""
    order = [str(o) for o in (order or [])]
    all_pons = [str(a) for a in (all_pons or [])]
    try:
        base = int(base)
    except (TypeError, ValueError):
        base = 1

    clicked_new = {o: base + i for i, o in enumerate(order)}
    mapping = [(o, base + i) for i, o in enumerate(order)]

    # result number per PON: a clicked one takes its new number, an un-clicked one
    # keeps its own (exactly as Finalize builds `result`).
    result = []
    for cur in all_pons:
        if cur in clicked_new:
            result.append(clicked_new[cur])
        else:
            n = _as_num(cur)
            if n is not None:
                result.append(n)

    dups = sorted({v for v, k in Counter(result).items() if k > 1})
    gaps = []
    if result:
        lo, hi = min(result), max(result)
        present = set(result)
        gaps = [n for n in range(lo, hi + 1) if n not in present]
    unclicked = sorted({_as_num(a) for a in all_pons
                        if a not in clicked_new and _as_num(a) is not None})

    return {
        "mapping": mapping,
        "clicked": len(order),
        "total": len(all_pons),
        "base": base,
        "dups": dups,
        "gaps": gaps,
        "unclicked": unclicked,
    }


def _short(nums, cap=12):
    """Comma list, truncated so a long run doesn't fill the panel."""
    nums = list(nums)
    if len(nums) <= cap:
        return ", ".join(str(n) for n in nums)
    return ", ".join(str(n) for n in nums[:cap]) + f", … +{len(nums) - cap} more"


def renumber_status_html(facts):
    """Live-status line(s) for the panel under the OLD→NEW table."""
    clicked = int(facts.get("clicked", 0) or 0)
    total = int(facts.get("total", 0) or 0)
    if clicked == 0:
        return ("<b>Renumber preview</b><br>Click PONs on the map in the order you "
                "want them numbered.")
    lines = [f"<b>Renumber preview</b> — {clicked} of {total} clicked · "
             f"start at {facts.get('base')}"]
    problems = []
    if facts.get("dups"):
        problems.append("&#9888; would create DUPLICATE number(s): "
                        + _short(facts["dups"]) + " — blocked at Finalize")
    if facts.get("gaps"):
        problems.append("&#9888; gap(s) — missing number(s): "
                        + _short(facts["gaps"]))
    if facts.get("unclicked"):
        u = facts["unclicked"]
        problems.append("&bull; %d not clicked (keep their number): %s"
                        % (len(u), _short(u)))
    if problems:
        lines.extend(problems)
    else:
        lines.append("&#10003; no gaps, no duplicates — clean run")
    return "<br>".join(lines)
