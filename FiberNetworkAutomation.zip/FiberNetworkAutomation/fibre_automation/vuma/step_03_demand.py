"""Vuma Step 3 — Generate demand points from cleaned buildings.

STATUS: [x] BUILT
"""

from qgis.core import (
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
)



def _get(name):
    layers = QgsProject.instance().mapLayersByName(name)
    return layers[0] if layers else None


def vuma_step_03_demand():
    """Generate demand points from cleaned Buildings layer.

    STATUS: [x] BUILT
    Safe to re-run — skips demand points that already have a dr_number.

    Requires:
      - 'Buildings' layer tagged by Step 2 (building_t field)
      - 'Demand Points' layer (created by Step 1)
    """
    print(f"\n{'═' * 50}")
    print("  VUMA STEP 3 — Demand Points")
    print(f"{'═' * 50}")

    bld_layer = _get("Buildings")
    dp_layer = _get("Demand Points")

    if bld_layer is None:
        print("  ✗ 'Buildings' layer not found.")
        return
    if dp_layer is None:
        print("  ✗ 'Demand Points' layer not found — run Step 1 first.")
        return

    bld_type_idx = bld_layer.fields().indexOf("building_t")
    if bld_type_idx < 0:
        print("  ✗ 'Buildings' layer not tagged yet — run Step 2 first.")
        return

    # Find existing max DR number to avoid gaps
    existing_dr = set()
    name_idx = dp_layer.fields().indexOf("Name")
    for feat in dp_layer.getFeatures():
        val = str(feat[name_idx] or "")
        if val.startswith("DR"):
            try:
                existing_dr.add(int(val[2:]))
            except ValueError:
                pass

    next_dr = (max(existing_dr) + 1) if existing_dr else 1

    # Collect buildings to convert (SDU, BY, MDU — not already converted)
    # Build set of building centroids already in demand points layer
    existing_pts = set()
    lat_idx = dp_layer.fields().indexOf("Geo Latitu")
    lon_idx = dp_layer.fields().indexOf("Geo Longit")
    for feat in dp_layer.getFeatures():
        lat = feat[lat_idx]
        lon = feat[lon_idx]
        if lat is not None and lon is not None:
            existing_pts.add((round(float(lon), 5), round(float(lat), 5)))

    # Sort buildings geographically (top-left → bottom-right)
    buildings_to_add = []
    for feat in bld_layer.getFeatures():
        btype = str(feat[bld_type_idx] or "")
        if btype not in ("SDU", "BY", "MDU"):
            continue
        if not feat.hasGeometry():
            continue
        centroid = feat.geometry().centroid().asPoint()
        key = (round(centroid.x(), 5), round(centroid.y(), 5))
        if key in existing_pts:
            continue
        buildings_to_add.append((feat, centroid, btype))

    # Sort: descending Y (north first), then ascending X (west first)
    buildings_to_add.sort(key=lambda x: (-x[1].y(), x[1].x()))

    # Field indices in Demand Points
    dp_fields = dp_layer.fields()
    f_name     = dp_fields.indexOf("Name")
    f_type     = dp_fields.indexOf("Type")
    f_lat      = dp_fields.indexOf("Geo Latitu")
    f_lon      = dp_fields.indexOf("Geo Longit")
    f_status   = dp_fields.indexOf("Status")
    f_ntwk     = dp_fields.indexOf("Network Ty")
    f_build    = dp_fields.indexOf("Build Meth")
    f_premises = dp_fields.indexOf("Premises T")
    f_zone     = dp_fields.indexOf("Zone")
    f_conn     = dp_fields.indexOf("Connectabl")

    new_features = []
    sdu_count = mdu_count = by_count = 0

    for feat, centroid, btype in buildings_to_add:
        dr_label = f"DR{next_dr:04d}"
        next_dr += 1

        new_feat = QgsFeature(dp_layer.fields())
        new_feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(centroid.x(), centroid.y())))

        attrs = {}
        if f_name >= 0:
            attrs[f_name] = dr_label
        if f_type >= 0:
            attrs[f_type] = "SDU" if btype in ("SDU", "BY") else "MDU"
        if f_lat >= 0:
            attrs[f_lat] = round(centroid.y(), 8)
        if f_lon >= 0:
            attrs[f_lon] = round(centroid.x(), 8)
        if f_status >= 0:
            attrs[f_status] = "planned"
        if f_ntwk >= 0:
            attrs[f_ntwk] = "GPON"
        if f_build >= 0:
            attrs[f_build] = "Aerial"
        if f_premises >= 0:
            attrs[f_premises] = "Residentia"
        if f_zone >= 0:
            attrs[f_zone] = 1
        if f_conn >= 0:
            attrs[f_conn] = "Yes"

        for k, v in attrs.items():
            new_feat.setAttribute(k, v)
        new_features.append(new_feat)

        if btype == "SDU":
            sdu_count += 1
        elif btype == "BY":
            by_count += 1
        else:
            mdu_count += 1

    if new_features:
        dp_layer.dataProvider().addFeatures(new_features)
        dp_layer.triggerRepaint()

    total = sdu_count + by_count + mdu_count
    end_dr = next_dr - 1

    print("\n  ══ DEMAND POINTS ══")
    print(f"  SDU points:  {sdu_count:>6,}")
    print(f"  BY points:   {by_count:>6,}")
    print(f"  MDU points:  {mdu_count:>6,}")
    print(f"  Total added: {total:>6,}")
    if new_features:
        start_dr = end_dr - total + 1
        print(f"  DR range:    DR{start_dr:04d} → DR{end_dr:04d}")
    else:
        print("  (no new points — layer already populated)")
    print(f"{'═' * 50}\n")
