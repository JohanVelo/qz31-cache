import sys, os
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')

# ============================================================
# POLES V1 ATTRIBUTE AUDIT SCRIPT — READ ONLY
# Project: Potch - Mohadin PH2
# Reference: poles_potch.csv (Phase 1 Poles)
# Purpose: Check all fields against CSV reference
#          Report what is missing, wrong, or correctly NULL
#          NO CHANGES MADE TO THE LAYER
# ============================================================

LAYER_NAME = 'poles v1'

# Fields that are ALWAYS NULL in reference CSV — skip checking
ALWAYS_NULL = [
    'wkt_geom', 'cablecap1', 'connect1', 'dim2_2', 'cablecap2', 'connect2',
    'dim2_3', 'cablecap3', 'connect3', 'dim2_4', 'cablecap4', 'connect4',
    'cablecap5', 'connect5', 'dim2_6', 'cablecap6', 'connect6',
    'dim2_7', 'cablecap7', 'connect7', 'startfeat', 'endfeat',
    'sg21', 'sg26', 'address', 'date_edit', 'editby', 'comments',
]

# Fields checked separately (spatial or sequential)
SPATIAL_FIELDS = ['pon_no', 'zone_no', 'lat', 'lon']

# Expected values per Pole Type — directly from poles_potch.csv
# '' = should be NULL in QGIS
EXPECTED = {
    'Primary Feeder': {
        'type_1': 'Pole', 'subtype_1': 'Creosote', 'spec_1': 'H4SANS754',
        'dim1': '7m', 'dim2': '140-160mm',
        'status': 'Permission not granted', 'companyown': 'VelocityFibre',
        # Child 2 — NULL for Primary
        'type_2': '', 'subtype_2': '', 'spec_2': '', 'dim1_2': '', 'featno1': '',
        # Child 3 — Tangent for Primary
        'type_3': 'Tangent', 'subtype_3': 'ADSS',
        'spec_3': 'Galvanised Steel Wire/Steel Thimble',
        'dim1_3': '15,11-16,00mm', 'featno2': '2',
        # Child 4 — Hook 2Way for Primary
        'type_4': 'Hook', 'subtype_4': 'Offset Bracket',
        'spec_4': '2Way', 'dim1_4': '(R19*W12,50mm)*2', 'featno3': 'True',
        # Child 5 — NULL for Primary
        'type_5': '', 'subtype_5': '', 'spec_5': '',
        'dim1_5': '', 'dim2_5': '', 'featno4': '',
        # Child 6 & 7 — Strapping & Buckle for all
        'type_6': 'Attachment', 'subtype_6': 'Strapping',
        'spec_6': 'Grade304 BandIt', 'dim1_6': '19*0,5mm', 'featno5': '4',
        'type_7': 'Attachment', 'subtype_7': 'Buckle',
        'spec_7': 'Grade304 BandIt', 'dim1_7': '19mm', 'featno6': '2',
        # Static location & meta fields
        'subplace': '676007', 'mainplace': '676007',
        'municipal': 'JB Marks Local Municipality', 'stack': 'MOA',
        'createdby': 'Johan Scholtz',
    },
    'Secondary Feeder': {
        'type_1': 'Pole', 'subtype_1': 'Creosote', 'spec_1': 'H4SANS754',
        'dim1': '7m', 'dim2': '140-160mm',
        'status': 'Permission not granted', 'companyown': 'VelocityFibre',
        # Child 2 — Dead-End for Secondary
        'type_2': 'Dead-End', 'subtype_2': 'Mini-ADSS',
        'spec_2': 'Galvanised Steel Wire/Steel Thimble',
        'dim1_2': '4,50-6,19mm', 'featno1': '2',
        # Child 3 — NULL for Secondary
        'type_3': '', 'subtype_3': '', 'spec_3': '', 'dim1_3': '', 'featno2': '',
        # Child 4 — Hook 2Way for Secondary
        'type_4': 'Hook', 'subtype_4': 'Offset Bracket',
        'spec_4': '2Way', 'dim1_4': '(R19*W12,50mm)*2', 'featno3': 'True',
        # Child 5 — NULL for Secondary
        'type_5': '', 'subtype_5': '', 'spec_5': '',
        'dim1_5': '', 'dim2_5': '', 'featno4': '',
        # Child 6 & 7 — Strapping & Buckle for all
        'type_6': 'Attachment', 'subtype_6': 'Strapping',
        'spec_6': 'Grade304 BandIt', 'dim1_6': '19*0,5mm', 'featno5': '4',
        'type_7': 'Attachment', 'subtype_7': 'Buckle',
        'spec_7': 'Grade304 BandIt', 'dim1_7': '19mm', 'featno6': '2',
        # Static location & meta fields
        'subplace': '676007', 'mainplace': '676007',
        'municipal': 'JB Marks Local Municipality', 'stack': 'MOA',
        'createdby': 'Johan Scholtz',
    },
    'Distribution': {
        'type_1': 'Pole', 'subtype_1': 'Creosote', 'spec_1': 'H4SANS754',
        'dim1': '7m', 'dim2': '120-140mm',
        'status': 'Permission not granted', 'companyown': 'VelocityFibre',
        # Child 2 — Dead-End for Distribution
        'type_2': 'Dead-End', 'subtype_2': 'Mini-ADSS',
        'spec_2': 'Galvanised Steel Wire/Steel Thimble',
        'dim1_2': '4,50-6,19mm', 'featno1': '2',
        # Child 3 — NULL for Distribution
        'type_3': '', 'subtype_3': '', 'spec_3': '', 'dim1_3': '', 'featno2': '',
        # Child 4 — Hook 2Way for Distribution
        'type_4': 'Hook', 'subtype_4': 'Offset Bracket',
        'spec_4': '2Way', 'dim1_4': '(R19*W12,50mm)*2', 'featno3': 'True',
        # Child 5 — Slack Bracket for Distribution only
        'type_5': 'Slack Bracket', 'subtype_5': 'Bracket',
        'spec_5': 'Extreme Slack', 'dim1_5': 'D620', 'dim2_5': 'D516', 'featno4': 'True',
        # Child 6 & 7 — Strapping & Buckle for all
        'type_6': 'Attachment', 'subtype_6': 'Strapping',
        'spec_6': 'Grade304 BandIt', 'dim1_6': '19*0,5mm', 'featno5': '4',
        'type_7': 'Attachment', 'subtype_7': 'Buckle',
        'spec_7': 'Grade304 BandIt', 'dim1_7': '19mm', 'featno6': '2',
        # Static location & meta fields
        'subplace': '676007', 'mainplace': '676007',
        'municipal': 'JB Marks Local Municipality', 'stack': 'MOA',
        'createdby': 'Johan Scholtz',
    },
}

# --- GET LAYER ---
layer = None
for lyr in QgsProject.instance().mapLayers().values():
    if lyr.name() == LAYER_NAME:
        layer = lyr
        break

if not layer:
    print(f"ERROR: Layer '{LAYER_NAME}' not found.")
else:
    print(f"Auditing: {LAYER_NAME} ({layer.featureCount()} features)")
    print("Reference: poles_potch.csv")
    print("=" * 60)

    from collections import defaultdict
    errors = defaultdict(list)
    warnings = defaultdict(list)
    type_counts = defaultdict(int)
    null_pole_type = 0
    spatial_nulls = defaultdict(int)

    for feat in layer.getFeatures():
        pole_type = feat['Pole Type']

        if not pole_type or str(pole_type).strip() in ('NULL', 'None', ''):
            null_pole_type += 1
            continue

        pole_type = str(pole_type).strip()
        type_counts[pole_type] += 1

        if pole_type not in EXPECTED:
            errors['UNKNOWN'].append(
                f"  [{feat['Label']}] Unknown Pole Type: '{pole_type}'"
            )
            continue

        expected = EXPECTED[pole_type]

        # Check expected fields
        for field, exp_val in expected.items():
            try:
                actual = feat[field]
            except KeyError:
                errors[pole_type].append(
                    f"  [{feat['Label']}] Field '{field}' not found in layer"
                )
                continue

            actual_str = '' if (actual is None or str(actual).strip() in ('NULL', 'None')) else str(actual).strip()

            if exp_val == '':
                if actual_str != '':
                    errors[pole_type].append(
                        f"  [{feat['Label']}] {field}: expected NULL, got '{actual_str}'"
                    )
            else:
                if actual_str != exp_val:
                    errors[pole_type].append(
                        f"  [{feat['Label']}] {field}: expected '{exp_val}', got '{actual_str}'"
                    )

        # Check spatial fields — just warn if NULL
        for sf in SPATIAL_FIELDS:
            try:
                val = feat[sf]
                if val is None or str(val).strip() in ('NULL', 'None', ''):
                    spatial_nulls[sf] += 1
            except KeyError:
                pass

    # --- REPORT ---
    print("\nPOLE TYPE COUNTS:")
    for pt, count in sorted(type_counts.items()):
        print(f"  {pt}: {count} poles")
    if null_pole_type:
        print(f"  ⚠️  NULL Pole Type: {null_pole_type} poles (skipped)")

    print("\nSPATIAL FIELDS (checked separately):")
    total = sum(type_counts.values())
    for sf in SPATIAL_FIELDS:
        nulls = spatial_nulls.get(sf, 0)
        if nulls == 0:
            print(f"  ✅ {sf}: fully populated")
        else:
            print(f"  ⚠️  {sf}: {nulls}/{total} NULL — needs population")

    print("\nAUDIT RESULTS:")
    total_errors = sum(len(v) for v in errors.values())

    if total_errors == 0:
        print("  ✅ ALL FIELDS CORRECT — No issues found!")
    else:
        print(f"  ⚠️  {total_errors} issues found:\n")
        for pole_type, errs in sorted(errors.items()):
            # Group errors by field for cleaner output
            field_errors = defaultdict(list)
            for e in errs:
                parts = e.strip().split('] ')
                if len(parts) > 1:
                    field = parts[1].split(':')[0]
                    field_errors[field].append(e)
                else:
                    field_errors['other'].append(e)

            print(f"  [{pole_type}] — {len(errs)} issues across {len(field_errors)} fields:")
            for field, ferrs in sorted(field_errors.items()):
                print(f"    Field '{field}': {len(ferrs)} poles affected")
                # Show first example
                print(f"    Example: {ferrs[0].strip()}")
            print()

    print("=" * 60)
    print("AUDIT COMPLETE — No changes made to the layer.")
