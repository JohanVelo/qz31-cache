"""PON Boundary Reshaper — bubble-shaped PON boundaries into straight-edged ones.

Ticket #139 (Luke, 2026-07-28). His Phalaborwa project holds three networks side
by side and only one of them has neat boundaries::

    boundary layer     PONs   vertices per polygon (min / median / max)
    BF_PON's             68        7 /    14 /    26     <- straight
    LK_PON's             63       40 /   416 /  4706     <- "bubble"
    MK_PON's             55      269 /   379 /   716     <- "bubble"

Benfarm was retiled during the Merge PONs work on 2026-07-27; the two beside it
never were. So "bubble vs straight" is not a matter of taste — it is a thirty-fold
difference in vertex count, and it is measurable before and after.

WHY THIS MODULE IS SO SHORT
---------------------------
Nothing here is a new geometry algorithm. The straight-edge tiler
(``pon_tiles.voronoi_zone_polygons``), the retile planner with its AOI clip and
its cross-network refusal (``pon_merge.plan_retile``), the topology-aware
simplifier (``pon_merge.straighten_coverage``) and the AOI finder
(``pon_merge.find_aoi``) were all built and measured for Merge PONs. This module
picks the layers, chooses a mode, and reports what would change. Reusing that
engine is deliberate: a second implementation of "straighten a PON boundary"
would drift away from the first one, and the Merge path is the one with the
measurements behind it.

TWO MODES, because "straighter" can mean two things
---------------------------------------------------
``retile``    Rebuild each boundary from the demand points that PON already owns.
              Produces exactly the Benfarm look (~14 vertices, gap-free,
              overlap-free). The edges MOVE, because the tile is derived rather
              than traced.
``simplify``  Keep the outline the operator has and drop its vertex count via the
              shared-coverage simplifier. The footprint stays put; the result is
              straighter but never as crisp as a tile.

Retile is the default because it is what the ticket's screenshot asks for. Both
ship because the choice is genuinely the planner's, not ours.

WHAT IT WILL NOT DO
-------------------
* **It never changes which PON a home belongs to.** Membership is read to build
  the tiles and is never written back. A reshape that silently moved houses
  between PONs would ripple into the BoQ.
* **It never trusts a first name match.** On 2026-07-27 a first-match pairing
  wrote Benfarm's boundaries out of Lulekani's demand points — three networks,
  all EPSG:4326, all neighbours. Automatic pairing excludes equipment-like point
  layers, prefers demand-like roles, and still requires MEASURED containment.
  The operator can always choose the input explicitly.
* **It writes nothing.** ``plan()`` returns the geometries it WOULD write, so the
  dialog can show them and take a verified backup first.
"""

from . import field_names as vf_fields
from . import pon_merge

#: Vertex count at or below which a boundary layer is already "straight". The
#: three real layers measured 14, 379 and 416, so anything in this region
#: separates them with two orders of magnitude to spare. Used only to LABEL a
#: layer in the UI — never to skip work.
STRAIGHT_MEDIAN_VERTICES = 40

MODE_RETILE = "retile"
MODE_SIMPLIFY = "simplify"

#: Default PON-to-PON gap, in metres. Tickets #141/#142 (Luke, 2026-07-28):
#: "if we could work in a small gap between PON's (5-10metres) that would be
#: great". 5 m is the conservative end of the range he named and it measures as a
#: true 5 m on his own data; the dialog exposes it so a planner can widen it.
GAP_DEFAULT_M = 5.0

#: Widest gap the dialog will offer. Past this the tiles stop reading as a
#: coverage and start reading as islands.
GAP_MAX_M = 25.0

#: Arc segments used when buffering. Only ever used for INWARD buffers of a few
#: metres, where 8 is already far finer than the geometry it is cutting.
_GAP_SEGMENTS = 8

# Layer names are operator-facing evidence, not geometry truth. They are used
# only to distinguish demand/home points from equipment points AFTER both have
# passed the geometry + PON-field candidate gate. Containment below still
# decides which network an eligible demand layer belongs to.
_DEMAND_ROLE_HINTS = frozenset({
    "building", "buildings", "demand", "erf", "erven", "group", "groups",
    "home", "homes", "house", "houses", "ont", "onts", "premise",
    "premises", "unit", "units",
})
_EQUIPMENT_ROLE_HINTS = frozenset({
    "cabinet", "cabinets", "closure", "closures", "enclosure", "enclosures",
    "equipment", "fts", "joint", "joints", "olt", "pole", "poles", "pop",
    "splitter", "splitters", "sts",
})


def vertex_count(geom):
    """Total vertices in a geometry, across every part and ring. 0 if empty."""
    if geom is None or geom.isEmpty():
        return 0
    try:
        return sum(1 for _ in geom.vertices())
    except Exception:
        return 0


def _median(values):
    if not values:
        return 0
    ordered = sorted(values)
    mid = len(ordered) // 2
    if len(ordered) % 2:
        return float(ordered[mid])
    return (ordered[mid - 1] + ordered[mid]) / 2.0


def measure(layer):
    """``{'pons', 'min', 'median', 'max', 'straight'}`` for a boundary layer.

    This is the number the dialog shows before and after, and the number the
    verify harness asserts on. Computed from the geometry every time — never
    cached, never stored in a column.
    """
    counts = []
    try:
        for f in layer.getFeatures():
            n = vertex_count(f.geometry())
            if n:
                counts.append(n)
    except Exception:
        return {"pons": 0, "min": 0, "median": 0.0, "max": 0, "straight": False}
    med = _median(counts)
    return {"pons": len(counts),
            "min": min(counts) if counts else 0,
            "median": med,
            "max": max(counts) if counts else 0,
            "straight": bool(counts) and med <= STRAIGHT_MEDIAN_VERTICES}


def candidate_boundary_layers(project):
    """Polygon layers that carry a PON number column, under any spelling.

    Deliberately permissive — an operator may have boundaries we have never seen
    a naming convention for. The safety comes from the containment gate below,
    not from guessing which layer is "the" PON layer.
    """
    out = []
    try:
        from qgis.core import QgsVectorLayer
    except Exception:
        return out
    try:
        layers = list(project.mapLayers().values())
    except Exception:
        return out
    for lyr in layers:
        try:
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                continue
            if int(lyr.geometryType()) != 2:          # polygons only
                continue
            if not vf_fields.has(lyr, vf_fields.PON_NUM):
                continue
            if lyr.featureCount() < 2:               # an AOI is not a PON layer
                continue
            out.append(lyr)
        except Exception:
            continue
    return out


def candidate_demand_layers(project):
    """Point layers carrying a PON number column."""
    out = []
    try:
        from qgis.core import QgsVectorLayer
    except Exception:
        return out
    try:
        layers = list(project.mapLayers().values())
    except Exception:
        return out
    for lyr in layers:
        try:
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                continue
            if int(lyr.geometryType()) != 0:          # points only
                continue
            if not vf_fields.has(lyr, vf_fields.PON_NUM):
                continue
            out.append(lyr)
        except Exception:
            continue
    return out


def demand_role_score(layer):
    """Semantic evidence that a point layer contains homes, not equipment.

    Positive describes demand/home features, zero is generic, and negative is
    obvious network equipment. This never decides which TOWN a layer belongs to;
    measured containment does that. The dialog still lists every point candidate
    so the operator can see and override the automatic choice.
    """
    try:
        name = str(layer.name() or "").lower()
    except Exception:
        name = ""
    tokens = set()
    token = []
    for char in name:
        if char.isalnum():
            token.append(char)
        elif token:
            tokens.add("".join(token))
            token = []
    if token:
        tokens.add("".join(token))
    positive = len(tokens & _DEMAND_ROLE_HINTS)
    equipment = len(tokens & _EQUIPMENT_ROLE_HINTS)
    return positive * 2 - equipment * 20


def containment_fraction(boundary_layer, point_layer):
    """Measured fraction of sampled points inside ``boundary_layer``."""
    if boundary_layer is None or point_layer is None:
        return 0.0
    try:
        if point_layer.crs().authid() != boundary_layer.crs().authid():
            return 0.0
        inside, sampled = pon_merge._containment_sample(
            boundary_layer, point_layer)
        return inside / float(sampled) if sampled else 0.0
    except Exception:
        return 0.0


def pair_demand_layer(project, boundary_layer):
    """``(layer, containment)`` — the demand layer whose points live HERE.

    Obvious equipment layers are ineligible for the automatic choice even when
    every splitter lies inside a boundary. Among eligible demand/home layers,
    measured containment remains the cross-network safety gate. Returns
    ``(None, best)`` when no eligible candidate clears
    :data:`pon_merge.RETILE_MIN_CONTAINMENT`.
    """
    eligible = []
    best_any_frac = 0.0
    for lyr in candidate_demand_layers(project):
        frac = containment_fraction(boundary_layer, lyr)
        best_any_frac = max(best_any_frac, frac)
        if frac < pon_merge.RETILE_MIN_CONTAINMENT:
            continue
        role = demand_role_score(lyr)
        if role < 0:
            continue
        try:
            count = int(lyr.featureCount())
        except Exception:
            count = 0
        eligible.append((role, frac, count, lyr))
    if not eligible:
        return None, best_any_frac
    _role, frac, _count, layer = max(
        eligible, key=lambda item: (item[0], item[1], item[2]))
    return layer, frac


def _simplify_plan(boundary_layer, simplify_m):
    """Straighten the EXISTING outlines in place. ``({fid: geom}, stats)``."""
    stats = {"tiled": 0, "untiled": 0, "untiled_pons": [], "homes_outside": 0,
             "untiled_clipped": 0, "untiled_kept_whole": 0, "aoi_clipped": 0,
             "aoi_refused": 0, "reason": "", "mode": MODE_SIMPLIFY}
    geoms = {}
    try:
        for f in boundary_layer.getFeatures():
            g = f.geometry()
            if g and not g.isEmpty():
                geoms[f.id()] = g
    except Exception as exc:
        stats["reason"] = f"could not read the boundary layer: {exc}"
        return {}, stats
    if not geoms:
        stats["reason"] = "the boundary layer has no polygons"
        return {}, stats

    out = pon_merge.straighten_coverage(geoms, boundary_layer, simplify_m)

    # straighten_coverage returns the ORIGINALS unchanged when shapely is too old
    # or a result failed its own area sanity check. Reporting "0 changed" is
    # honest; reporting the untouched originals as a plan would not be.
    changed = {}
    for fid, g in out.items():
        old = geoms.get(fid)
        if old is None or g is None or g.isEmpty():
            continue
        if vertex_count(g) < vertex_count(old):
            changed[fid] = g
        else:
            stats["untiled"] += 1
    stats["tiled"] = len(changed)
    if not changed:
        stats["reason"] = ("nothing to simplify — shapely has no coverage_simplify, "
                           "or these outlines are already at their minimum")
    return changed, stats


def _metric_transforms(layer, sample):
    """``(fwd, rev)`` into ONE metre-based CRS for the whole layer, or (None, None).

    One transform for every tile, not one per tile: the tiles have to be buffered
    and unioned against each other, and mixing two UTM zones inside that would
    compare coordinates that do not belong in the same plane.
    """
    try:
        from qgis.core import QgsCoordinateTransform, QgsProject
        target = pon_merge._metric_crs_for(sample, layer)
        if target is None:
            return None, None                 # already metric — buffer directly
        proj = QgsProject.instance()
        return (QgsCoordinateTransform(layer.crs(), target, proj),
                QgsCoordinateTransform(target, layer.crs(), proj))
    except Exception:
        return None, None


def apply_gap(changes, boundary_layer, gap_m):
    """Open a gap of ``gap_m`` metres BETWEEN neighbouring tiles. ``(changes, stats)``.

    Tickets #141 + #142. Luke's tiles come out flush — every PON shares its edge
    with the next one — and he wants a visible 5-10 m separation.

    Each tile is buffered inward by HALF the gap, so two neighbours that used to
    share an edge end up ``gap_m`` apart. Measured on Luke's project the result is
    exact: asking for 5 / 8 / 10 m measures back as 5.0 / 8.0 / 10.0 m between the
    closest pair of tiles.

    THE COST, measured, not guessed: a home sitting within half a gap of a SHARED
    edge ends up in the new gutter, inside no tile at all. On his three networks
    that is 8 / 7 / 5 homes at 5 m and 28 / 17 / 11 at 10 m, out of ~5-6k each
    (under 0.5%). This is intrinsic — a visible gap and every home inside a
    polygon cannot both be true — so the dialog REPORTS the number rather than
    pretending it is free. Nothing about PON membership changes: that lives in the
    attribute and this function never touches it.

    An attempt to spare those homes by preserving the outer perimeter was built
    and MEASURED FIRST: it saved none of them (they are on interior edges, not the
    rim) and it broke the gap itself, pinning Benfarm at 2.7 m however wide a gap
    was asked for. It was removed rather than kept as a plausible-looking no-op.

    Distances are metres, so the work is done in a local UTM zone and transformed
    back -- buffering by "5" on this EPSG:4326 layer would be 5 DEGREES.
    """
    from qgis.core import QgsGeometry

    stats = {"gap_m": float(gap_m or 0.0), "gapped": 0, "too_thin": 0}
    if not changes or not gap_m or gap_m <= 0:
        return changes, stats

    half = float(gap_m) / 2.0
    sample = next(iter(changes.values()))
    fwd, rev = _metric_transforms(boundary_layer, sample)

    out = {}
    for fid, geom in changes.items():
        g = QgsGeometry(geom)
        if fwd is not None and g.transform(fwd) != 0:
            out[fid] = changes[fid]
            stats["too_thin"] += 1
            continue
        try:
            shrunk = g.buffer(-half, _GAP_SEGMENTS)
        except Exception:
            shrunk = None
        # A tile too thin to survive the cut keeps its original shape rather than
        # vanishing. A disappearing PON is far worse than a missing gap.
        if shrunk is None or shrunk.isEmpty():
            out[fid] = changes[fid]
            stats["too_thin"] += 1
            continue
        if rev is not None and shrunk.transform(rev) != 0:
            out[fid] = changes[fid]
            stats["too_thin"] += 1
            continue
        out[fid] = shrunk
        stats["gapped"] += 1
    return out, stats


def homes_in_gap(changes, demand_layer):
    """How many homes end up inside NO tile. ``(count, checked)``.

    The honest price of a gap, shown in the preview before anything is written.
    Index-backed so it stays instant on 6,000 homes.
    """
    if not changes or demand_layer is None:
        return 0, 0
    try:
        from qgis.core import QgsFeature, QgsSpatialIndex
    except Exception:
        return 0, 0
    idx = QgsSpatialIndex()
    tiles = {}
    for i, (_fid, g) in enumerate(changes.items()):
        ft = QgsFeature(i)
        ft.setGeometry(g)
        idx.addFeature(ft)
        tiles[i] = g
    outside = checked = 0
    try:
        for f in demand_layer.getFeatures():
            g = f.geometry()
            if not g or g.isEmpty():
                continue
            checked += 1
            if not any(tiles[i].intersects(g)
                       for i in idx.intersects(g.boundingBox())):
                outside += 1
    except Exception:
        return outside, checked
    return outside, checked


def plan(project, boundary_layer, demand_layer=None, mode=MODE_RETILE,
         simplify_m=pon_merge.DEFAULT_SIMPLIFY_M, clip_to_aoi=True,
         gap_m=0.0):
    """What the reshape WOULD write. ``({fid: QgsGeometry}, stats)``. Writes nothing.

    ``stats`` always carries a human-readable ``reason`` when the result is empty,
    because an empty plan and "the boundaries were already neat" look identical on
    screen and must not be confused.
    """
    if boundary_layer is None:
        return {}, {"reason": "no boundary layer chosen", "tiled": 0, "untiled": 0,
                    "mode": mode}

    if mode == MODE_SIMPLIFY:
        changes, stats = _simplify_plan(boundary_layer, simplify_m)
        stats["demand_layer"] = None
        stats["containment"] = None
        # THE GAP IS DELIBERATELY NOT APPLIED IN SIMPLIFY MODE, and this was
        # measured rather than reasoned. Simplify keeps the operator's OWN
        # outlines, which on Lulekani already overlap each other; buffering each
        # of them inward does not open a uniform gap, it just eats into shapes
        # that were never a clean coverage. Measured on LK, the closest approach
        # between two tiles went the WRONG WAY as the gap widened -- 1.63 m at
        # 0 m, 1.21 m at 5 m, 0.42 m at 10 m -- because shrinking merely peeled
        # apart pairs that had been overlapping. A gap that reads as a gap needs
        # tiles that share edges, which is what retiling produces.
        stats["gap_m"] = 0.0
        stats["gap_ignored"] = bool(gap_m and gap_m > 0)
        return changes, stats

    if demand_layer is None:
        demand_layer, frac = pair_demand_layer(project, boundary_layer)
        if demand_layer is None:
            return {}, {
                "tiled": 0, "untiled": 0, "mode": mode, "containment": frac,
                "demand_layer": None,
                "reason": (
                    "no demand-point layer belongs to "
                    f"{boundary_layer.name().strip()} — the best match had only "
                    f"{frac:.1%} of its points inside these boundaries, so "
                    "reshaping from it would rebuild this network out of another "
                    "one's homes")}

    aoi_geom = None
    if clip_to_aoi:
        try:
            _aoi_layer, aoi_geom = pon_merge.find_aoi(project, boundary_layer)
        except Exception:
            aoi_geom = None

    changes, stats = pon_merge.plan_retile(boundary_layer, demand_layer, aoi_geom)
    stats["mode"] = MODE_RETILE
    stats["demand_layer"] = demand_layer.name() if demand_layer else None
    stats["aoi_found"] = aoi_geom is not None
    changes, gstats = apply_gap(changes, boundary_layer, gap_m)
    stats.update(gstats)
    return changes, stats


def preview_rows(boundary_layer, changes):
    """Per-PON ``(pon, vertices_before, vertices_after, area_change_pct)``.

    Sorted by how much the polygon moves, worst first — the row most worth
    looking at before pressing Apply is the one that changes most.
    """
    rows = []
    pon_field = vf_fields.resolve(boundary_layer, vf_fields.PON_NUM)
    try:
        feats = list(boundary_layer.getFeatures())
    except Exception:
        return rows
    for f in feats:
        g_new = changes.get(f.id())
        if g_new is None:
            continue
        g_old = f.geometry()
        a_old = g_old.area() if g_old and not g_old.isEmpty() else 0.0
        a_new = g_new.area()
        delta = ((a_new - a_old) / a_old * 100.0) if a_old > 0 else 0.0
        pon = f[pon_field] if pon_field else f.id()
        rows.append((pon, vertex_count(g_old), vertex_count(g_new), delta))
    rows.sort(key=lambda r: abs(r[3]), reverse=True)
    return rows


def overlapping_pairs(geoms):
    """How many pairs of boundaries overlap. The tiler's promise is zero.

    ``geoms`` is any iterable of ``QgsGeometry``. Pure geometry — no attribute is
    consulted, because the attribute is exactly what cannot be trusted here.
    """
    items = [g for g in geoms if g is not None and not g.isEmpty()]
    hits = 0
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            try:
                if not items[i].boundingBoxIntersects(items[j]):
                    continue
                inter = items[i].intersection(items[j])
                if inter is None or inter.isEmpty():
                    continue
                # A shared EDGE intersects to a line, not an area. Only real
                # overlapping ground counts.
                if inter.area() > 0:
                    hits += 1
            except Exception:
                continue
    return hits
