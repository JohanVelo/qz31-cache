"""Span-constrained PON grouping, balancing and boundary drawing.

Public surface:

    from fibre_automation.pon_wayleave import group_pons, utm_epsg_for
    from fibre_automation.pon_wayleave import balance_pons, build_boundaries

Three stages, each usable on its own:

* ``group_pons`` decides which stands belong to which PON, following the fibre
  route so every PON is one continuous run of span and the feeder walks one
  path.
* ``balance_pons`` fixes the size distribution afterwards without breaking that
  property -- the grouper packs to the cap and leaves runts.
* ``build_boundaries`` draws the polygons on street blocks, which is what makes
  them read like a planner drew them.

``network_planner.pon_tiles`` remains the demand-tiled boundary builder and is
untouched: it is shipped and has four callers.

Nothing in this package imports QGIS, on purpose -- the acceptance gate runs
headless in about a second instead of needing a live QGIS session.
"""

from .balance import (
    BAND_HI,
    BAND_LO,
    HARD_MAX,
    SEEDS,
    WORKING_CAP,
    balance_pons,
    band_stats,
    build_run_graph,
)
from .blockplan import balance_blocks, block_graph, pon_of_stands, seed_from_stands
from .blocks import block_adjacency, street_blocks, subdivide_blocks
from .boundaries import boundary_stats, build_block_boundaries, build_boundaries
from .core import (
    DEFAULT_SNAP_M,
    MAX_STANDS,
    RESTART_SEEDS,
    TARGET_STANDS,
    PonWayleaveError,
    SpanGraph,
    check_zone_fit,
    utm_epsg_for,
)
from .grouping import GroupingResult, group_pons, renumber_from_dc
from .plan import (SUBDIVIDE_MAX, BalancedGrouping, PonPlan, balanced_grouping,
                   blocks_of_stands, plan_pons)

__all__ = [
    # grouping
    "TARGET_STANDS", "MAX_STANDS", "DEFAULT_SNAP_M", "RESTART_SEEDS",
    "utm_epsg_for", "check_zone_fit", "SpanGraph", "PonWayleaveError",
    "GroupingResult", "group_pons", "renumber_from_dc",
    # balancing
    "BAND_LO", "BAND_HI", "HARD_MAX", "WORKING_CAP", "SEEDS",
    "balance_pons", "band_stats", "build_run_graph",
    # boundaries
    "street_blocks", "block_adjacency", "subdivide_blocks", "build_boundaries", "boundary_stats",
    # whole-block plan (islands impossible by construction)
    "block_graph", "seed_from_stands", "balance_blocks", "pon_of_stands",
    "build_block_boundaries",
    # the whole pipeline, so the gate and the plugin run ONE code path
    "PonPlan", "plan_pons", "blocks_of_stands", "SUBDIVIDE_MAX",
    # span-following + size-balanced grouping: what HT 2 calls
    "BalancedGrouping", "balanced_grouping",
]
