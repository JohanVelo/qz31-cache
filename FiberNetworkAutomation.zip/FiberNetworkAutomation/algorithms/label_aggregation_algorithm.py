# Label Aggregation Polygons Algorithm

from qgis.core import (
    QgsProcessingParameterVectorLayer,
    QgsProcessing
)

from .base_algorithm import BaseFiberAlgorithm


class LabelAggregationAlgorithm(BaseFiberAlgorithm):
    """Algorithm to label Aggregation Polygon layers"""

    def name(self):
        return 'labelaggregation'

    def displayName(self):
        return '1. Label Aggregation Polygons'

    def shortHelpString(self):
        return """
        Auto-populate Aggregation Polygon fields.

        Fields updated:
        - Label: PRAK-Z1-AG01, AG02, AG03...
        - fid: 1, 2, 3...

        ⚠️ Run this FIRST before other layers!
        """

    def initAlgorithm(self, config=None):
        # Input layer
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                self.INPUT,
                'Aggregation Polygon Layer',
                [QgsProcessing.TypeVectorPolygon]
            )
        )

        # Project selection
        self.add_common_parameters()

    def processAlgorithm(self, parameters, context, feedback):
        # Get parameters
        layer = self.parameterAsVectorLayer(parameters, self.INPUT, context)
        project = self.get_project_code(parameters, context)

        feedback.pushInfo(f"Labeling Aggregation Polygons for {project}...")

        # Update fid
        feedback.pushInfo("Updating fid...")
        self.calculate_field(layer, "fid", "@row_number", feedback)

        # Update Label
        feedback.pushInfo("Updating Label...")
        formula = f"'{project}-Z1-AG' || lpad(to_string(\"fid\"), 2, '0')"
        self.calculate_field(layer, "Label", formula, feedback)

        layer.triggerRepaint()
        feedback.pushInfo("✅ Aggregation Polygons labeled successfully!")

        return {self.INPUT: layer.id()}
